package com.dynamicpill.module;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import de.robv.android.xposed.XposedBridge;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.WeakHashMap;

/**
 * "Card / sliders swap" (3.4.2): the card (tile card, or the media player card when the tile card is off) and the
 * two vertical sliders (brightness, volume) swap sides in their row of the Control Center.
 *
 * Default row (left to right):   [ CARD ] [ brightness ] [ volume ]
 * Swapped row (left to right):   [ brightness ] [ volume ] [ CARD ]
 *
 * Nothing in the layout is changed (no dimen, no span, no adapter order). The system lays the row out as always;
 * every frame (pre-draw) the items of that row only get a translationX so they are DRAWN (and touched) in the new
 * places. The widths and the gaps are kept exactly, so the row occupies the same space and nothing can overlap.
 * Switch off = translationX goes back to 0 at once. Same approach as CcScale.
 */
final class CcSwap {
    private static final WeakHashMap<View, State> STATES = new WeakHashMap<>();

    private CcSwap() { }

    /** Called from MainHook for every MainPanelRecyclerView that attaches. */
    static void attach(View v) {
        try {
            if (!(v instanceof ViewGroup)) return;
            State s = STATES.get(v);
            if (s == null) { s = new State((ViewGroup) v); STATES.put(v, s); }
            s.start();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CcSwap attach failed: " + t);
        }
    }

    private static final class State implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
        final ViewGroup rv;
        boolean started = false, loggedOnce = false;
        Method getHolder;
        boolean holderLookedUp = false;
        /** Views whose translationX was set by us (so they can be put back). */
        final WeakHashMap<View, Boolean> moved = new WeakHashMap<>();

        State(ViewGroup rv) { this.rv = rv; }

        void start() {
            if (started) return;
            started = true;
            rv.addOnAttachStateChangeListener(this);
            rv.getViewTreeObserver().addOnPreDrawListener(this);
        }

        @Override public void onViewAttachedToWindow(View v) {
            if (!started) { started = true; v.getViewTreeObserver().addOnPreDrawListener(this); }
        }

        @Override public void onViewDetachedFromWindow(View v) {
            try { v.getViewTreeObserver().removeOnPreDrawListener(this); } catch (Throwable ignored) { }
            started = false;
            resetAll();
        }

        @Override public boolean onPreDraw() {
            try { tick(); } catch (Throwable t) { /* never break drawing */ }
            return true;
        }

        private String holderName(View child) {
            try {
                if (!holderLookedUp) {
                    holderLookedUp = true;
                    for (Class<?> c = rv.getClass(); c != null && getHolder == null; c = c.getSuperclass()) {
                        for (Method m : c.getDeclaredMethods()) {
                            if (m.getName().equals("getChildViewHolder") && m.getParameterTypes().length == 1
                                    && m.getParameterTypes()[0] == View.class) {
                                m.setAccessible(true);
                                getHolder = m;
                                break;
                            }
                        }
                    }
                }
                if (getHolder == null) return "";
                Object h = getHolder.invoke(rv, child);
                return h == null ? "" : h.getClass().getName();
            } catch (Throwable t) {
                return "";
            }
        }

        private void resetAll() {
            try {
                for (View v : new ArrayList<>(moved.keySet())) {
                    if (v != null && v.getTranslationX() != 0f) v.setTranslationX(0f);
                }
                moved.clear();
            } catch (Throwable ignored) { }
        }

        private void put(View v, float tx) {
            if (Math.abs(v.getTranslationX() - tx) > 0.5f) v.setTranslationX(tx);
            moved.put(v, Boolean.TRUE);
        }

        private void tick() {
            int n = rv.getChildCount();
            if (!ControlCenterSize.cardSwapOn() || n == 0 || rv.getWidth() <= 0) {
                if (!moved.isEmpty()) resetAll();
                return;
            }
            // 1) the card = the media player item (the tile card lives inside it)
            View media = null;
            for (int i = 0; i < n; i++) {
                View c = rv.getChildAt(i);
                if (c == null || c.getVisibility() == View.GONE || c.getWidth() <= 0 || c.getHeight() <= 0) continue;
                if (holderName(c).contains("MediaPlayerViewHolder")) { media = c; break; }
            }
            if (media == null) { if (!moved.isEmpty()) resetAll(); return; }

            // 2) the other items of the same row: their centre lies inside the card's top..bottom
            ArrayList<View> others = new ArrayList<>();
            boolean ok = true;
            for (int i = 0; i < n; i++) {
                View c = rv.getChildAt(i);
                if (c == null || c == media || c.getVisibility() == View.GONE || c.getWidth() <= 0 || c.getHeight() <= 0) continue;
                int cy = (c.getTop() + c.getBottom()) / 2;
                if (cy < media.getTop() || cy > media.getBottom()) continue;
                if (c.getLeft() < media.getRight() - 2) { ok = false; break; }   // something left of / over the card: not the usual row
                others.add(c);
            }
            if (!ok || others.isEmpty()) { if (!moved.isEmpty()) resetAll(); return; }
            Collections.sort(others, new Comparator<View>() {
                @Override public int compare(View a, View b) { return a.getLeft() - b.getLeft(); }
            });

            // 3) new places: others first (same widths and gaps), the card last, row start and end stay the same
            int x = media.getLeft();
            int gapCard = others.get(0).getLeft() - media.getRight();
            for (int i = 0; i < others.size(); i++) {
                View o = others.get(i);
                put(o, x - o.getLeft());
                x += o.getWidth();
                if (i + 1 < others.size()) x += others.get(i + 1).getLeft() - o.getRight();
            }
            x += gapCard;
            put(media, x - media.getLeft());
            if (!loggedOnce) {
                loggedOnce = true;
                XposedBridge.log("DynamicPill: CcSwap: card moved right, " + others.size() + " item(s) moved left");
            }
        }
    }
}

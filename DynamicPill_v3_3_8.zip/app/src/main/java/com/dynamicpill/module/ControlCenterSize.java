package com.dynamicpill.module;

import android.content.res.Resources;

import de.robv.android.xposed.XSharedPreferences;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Control Center sizes, taken from the MIUI System UI dimens (MiuiSystemUI.apk, qs_control_* / qs_*).
 * Each slider scales a whole family of dimens by a percentage (100 = system value), so it works for every
 * screen density / layout variant. Header top offset adds dp.
 * Read again when the Control Center is rebuilt (reopen it, or restart System UI).
 */
final class ControlCenterSize {
    static final String K_SPACE = "cc_s_space", K_HEADER = "cc_s_header", K_HEADER_TOP = "cc_header_top_dp",
            K_MEDIA = "cc_s_media", K_FOOT = "cc_s_foot", K_PAGE = "cc_s_page", K_VOLUME = "cc_s_volume",
            K_UNIV = "cc_s_univ", K_POWER = "cc_s_power", K_TILE_CARD = "cc_tile_card", K_TILE_COLOR = "cc_tile_color", K_TILE_SCALE = "cc_tile_scale", K_GRID_SCALE = "cc_grid_scale";

    private static final String[] KEYS = {null, null, null, null, K_SPACE, null, null, null,
            K_HEADER, null, null, K_HEADER_TOP, K_MEDIA, K_FOOT, K_PAGE, null, null,
            K_VOLUME, null, null, null, null, K_UNIV, K_POWER};
    private static final int G_NONE = 0, G_SPACE = 4, G_HEADER = 8, G_HEADER_TOP = 11, G_MEDIA = 12, G_FOOT = 13, G_PAGE = 14,
            G_VOLUME = 17, G_UNIV = 22, G_POWER = 23;
    private static final int GROUPS = 24;

    /** Every other control center dimen is sorted into a family by its name (MIUI qs_* naming). */
    private static int prefixGroup(String n) {
        if (n == null) return G_NONE;
        if (n.contains("seekbar_progress") || n.contains("falsing") || n.contains("elevation")
                || n.contains("stroke_width") || n.contains("overfling") || n.contains("alpha")) return G_NONE;
        // MIUISystemUIPlugin.apk (the real Control Center / volume panel / MiPlay live in this plugin)
        if (n.contains("thresh") || n.contains("velocity")) return G_NONE;
        if (n.startsWith("miui_volume_")) return G_VOLUME;
        if (n.startsWith("miplay_") || n.startsWith("window_card_")) return G_NONE;
        if (n.startsWith("miui_controls_") || n.startsWith("device_controls_") || n.startsWith("controls_app")
                || n.startsWith("controls_management") || n.startsWith("device_center_") || n.startsWith("external_entry_")
                || n.startsWith("control_center_device_controls")) return G_NONE;
        if (n.startsWith("notification_panel_")) return G_NONE;
        if (n.startsWith("focus_notify_")) return G_NONE;
        if (n.startsWith("control_center_universal_") || n.startsWith("qs_card_") || n.startsWith("control_center_qs_item")) return G_UNIV;
        if (n.startsWith("reboot_shutdown_")) return G_NONE;   // slider removed in 3.3.3: stays at the system size
        if (n.startsWith("media_player_")) return G_MEDIA;
        if (n.startsWith("header_privacy_") || n.startsWith("control_center_status_bar_padding")
                || n.startsWith("control_center_toggle_slider")) return G_HEADER;
        if (n.startsWith("control_center_detail_max_height")) return G_NONE;
        if (n.startsWith("control_center_panel_width") || n.startsWith("control_center_horizontal_margin")
                || n.startsWith("control_center_force_vertical") || n.startsWith("control_center_align_end")) return G_NONE;
        if (n.startsWith("qs_media_")) return G_MEDIA;
        if (n.startsWith("qs_page_indicator_") || n.startsWith("qs_control_tiles_indicator_")) return G_NONE;   // slider removed in 3.3.3: stays at the system size
        if (n.startsWith("qs_footer") || n.startsWith("qs_control_footer") || n.startsWith("qs_security_footer")
                || n.startsWith("qs_control_foot_panel") || n.startsWith("qs_control_bottom_")
                || n.equals("control_center_bottom_area_height")) return G_FOOT;
        if (n.startsWith("qs_control_expand_") || n.startsWith("qs_control_content_view")) return G_NONE;
        if (n.startsWith("qs_customize") || n.startsWith("qs_control_customizer_")
                || n.startsWith("qs_customer_added")) return G_NONE;
        if (n.contains("corner_radius") || n.endsWith("_radius")) return G_NONE;
        if (n.startsWith("qs_control_detail_") || n.startsWith("qs_detail_") || n.contains("_detail_height")
                || n.startsWith("qs_control_mi_play_detail")) return G_NONE;
        if (n.startsWith("qs_control_brightness_") || n.startsWith("qs_brightness_")) return G_NONE;
        if (n.startsWith("qs_control_header_") || n.startsWith("qs_header_") || n.startsWith("notch_expanded_header")
                || n.startsWith("qs_time_")) return G_HEADER;
        if (n.startsWith("qs_control_big_tile") || n.startsWith("qs_control_smart")) return G_NONE;
        if (n.startsWith("qs_control_center_tile") || n.startsWith("qs_control_tile_") || n.startsWith("qs_control_custom_tile")
                || n.startsWith("qs_quick_tile")) return G_NONE;
        if (n.startsWith("qs_control_tiles_") || n.startsWith("qs_control_land_") || n.startsWith("qs_tile_")
                || n.startsWith("qs_quick_panel_") || n.startsWith("qs_dual_tile")) return G_SPACE;
        if (n.startsWith("qs_control_panel") || n.startsWith("qs_panel_") || n.startsWith("qs_tiles_page")
                || n.startsWith("qs_control_center_horizontal")) return G_NONE;
        return G_NONE;
    }

    private static final HashMap<String, Integer> NAMES = new HashMap<>();
    private static void add(int g, String... names) { for (String n : names) NAMES.put(n, g); }
    static {
        add(G_SPACE, "qs_control_center_tile_margin_start", "qs_control_center_tile_margin_top",
                "qs_control_tiles_container_margin_top", "qs_control_tiles_container_margin_bottom",
                "qs_control_big_tiles_interval_vertical", "qs_control_big_tiles_margin_bottom",
                "qs_control_big_tiles_padding_top", "qs_tile_margin_horizontal", "qs_tile_margin_vertical",
                "qs_control_tile_label_padding_top");
        add(G_HEADER, "qs_control_header_clock_size", "qs_control_header_date_size", "qs_control_header_button_size",
                "qs_control_header_tiles_height", "qs_header_row_min_height");
        add(G_HEADER_TOP, "qs_control_center_header_paddingTop", "qs_header_top_padding");
    }

    private static final ConcurrentHashMap<Long, Integer> GROUP = new ConcurrentHashMap<>();
    private static XSharedPreferences xsp;
    private static volatile int[] vals = new int[GROUPS];
    private static volatile boolean tileCard = false;
    private static volatile int tileColor = 0;
    private static volatile int tileScale = 100;
    private static volatile int gridScale = 100;
    private static volatile long lastLoad = 0;

    private static void load() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastLoad < 700) return;
        lastLoad = now;
        try {
            if (xsp == null) xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
            if (xsp.hasFileChanged()) xsp.reload();
            // 3.3.5: only the card size (K_MEDIA) is a setting any more; the other sliders were removed, so an old
            // saved value of them must not change anything (everything else stays at the system size).
            int[] v = new int[GROUPS];
            java.util.Arrays.fill(v, 100);
            v[G_HEADER_TOP] = 0;
            v[G_MEDIA] = xsp.getInt(K_MEDIA, 100);
            vals = v;
            tileCard = xsp.getBoolean(K_TILE_CARD, false);
            tileColor = xsp.getInt(K_TILE_COLOR, 0);
            tileScale = xsp.getInt(K_TILE_SCALE, 100);
            gridScale = Math.max(60, Math.min(150, xsp.getInt(K_GRID_SCALE, 100)));
        } catch (Throwable ignored) { }
    }

    private static int group(Resources r, int id) {
        if (id == 0) return G_NONE;
        long key = DimenHook.key(r, id);
        Integer g = GROUP.get(key);
        if (g != null) return g;
        int gr = G_NONE;
        try {
            String nm = r.getResourceEntryName(id);
            Integer x = NAMES.get(nm);
            gr = x != null ? x : prefixGroup(nm);
        } catch (Throwable ignored) { }
        GROUP.put(key, gr);
        return gr;
    }

    /** New px value for a dimen, or Float.NaN when it stays unchanged. */
    static float adjust(Resources r, int id, float original) {
        int g = group(r, id);
        if (g == G_NONE) return Float.NaN;
        load();
        int v = vals[g];
        if (g == G_HEADER_TOP) {
            if (v <= 0) return Float.NaN;
            return original + v * r.getDisplayMetrics().density;
        }
        if (v == 100) return Float.NaN;
        return original * v / 100f;
    }

    /** True when the tile card replaces the media player card (settings switch). */
    static boolean tileCardOn() {
        load();
        return tileCard;
    }

    /** Size of the icons in the tile card in percent (100 = default). */
    static int tileScale() {
        load();
        return tileScale;
    }

    /** Size of the round tiles of the Control Center grid in percent (100 = default). */
    static int gridScale() {
        load();
        return gridScale;
    }

    /** Theme colour of the tile card (0 = default yellow). */
    static int tileColor() {
        load();
        return tileColor;
    }
}

package com.dynamicpill.module;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/** Adds the pill as an always-on overlay window inside the System UI process. */
public class PillController {
    static final String MODULE_PKG = "com.dynamicpill.module";
    static final String PREF_FILE = "pill_prefs";
    static final String K_ENABLED = "enabled";
    static final String K_WIDTH = "width_mm10";     // 0.1 mm units
    static final String K_HEIGHT = "height_mm10";   // 0.1 mm units
    static final String K_YOFF = "yoff_mm10";       // 0.1 mm units, can be negative
    static final String K_ALPHA = "alpha_pct";
    // iOS style line (grabber) under the status bar
    static final String K_LINE_ON = "line_on";
    static final String K_LINE_W = "line_w2_mm10";
    static final String K_LINE_H = "line_h_mm10";
    static final String K_LINE_X = "line_right_mm10"; // distance from right edge to line CENTER
    static final String K_LINE_Y = "line_top_mm10";   // distance from top of screen
    static final String K_LINE_ALPHA = "line_alpha_pct";
    static final int D_LINE_W = 160, D_LINE_X = 125, D_LINE_Y = 69;
    static final String K_BORDER = "border_mm10"; // 0 = off
    static final String K_SMOOTH = "smooth_pct";  // 0 = circular ends, 100 = softest iOS-style curve
    static final String K_LOCK = "show_lock";
    // indicators inside the pill
    static final String K_IND_DOT = "ind_dot";
    static final String K_IND_WA = "ind_whatsapp";
    static final String K_IND_CALL = "ind_call";
    static final String K_IND_CHARGE = "ind_charge";
    static final String K_IND_NOTIF = "ind_notif";
    /** Fallback only (if notification tracking is unavailable): blink time after a notification arrives. */
    static final long NOTIF_BLINK_MS = 15000;
    /** While an unread notification is in the panel the dot blinks for NOTIF_BURST_MS, then again every NOTIF_REPEAT_MS. */
    static final long NOTIF_BURST_MS = 3000;
    static final long NOTIF_REPEAT_MS = 15000;
    static final int D_WIDTH = 135;                  // 13.5 mm
    static final int D_HEIGHT = 40;                  // 4.0 mm
    static final int D_YOFF = 0;
    // expanding pill animations
    static final String K_ANIM = "anim_on";
    static final String K_ANIM_CHARGE = "anim_charge";
    static final String K_ANIM_RINGER = "anim_ringer";
    static final String K_ANIM_CALL = "anim_call";
    static final String K_ANIM_LOCK = "anim_lock";
    static final String K_ANIM_UNLOCK = "anim_unlock";
    static final String K_ANIM_INCOMING = "anim_incoming";
    static final String K_DOT_PCT = "dot_size_pct";    // size of the dot inside the pill, percent
    static final String K_ANIM_TORCH = "anim_torch";
    static final String K_ANIM_FLIGHT = "anim_flight";
    static final String K_ANIM_HOTSPOT = "anim_hotspot";
    static final String K_ANIM_LOC = "anim_location";
    static final String K_WA_NEON = "wa_neon";
    static final String K_SB_HIDE = "anim_hide_statusbar";   // fade the status bar out while a scene is shown
    static final String K_EXP_W = "exp_w_mm10";     // expanded width, 0.1 mm units
    static final String K_HOLD = "hold_s10";        // how long a scene stays, 0.1 s units
    static final String K_PREVIEW = "preview_req";  // "name:timestamp" written by the settings screen
    static final String K_TXT_PCT = "anim_text_pct";   // scene text size, percent
    static final String K_ICO_PCT = "anim_icon_pct";   // scene icon size, percent
    static final int D_EXP_W = 240, D_HOLD = 25;
    static final int COLOR_NEON = 0xFF32FF6A;
    static final String K_XOFF = "xoff_mm10";       // 0.1 mm units, can be negative (horizontal fine tune)
    static final String K_AUTOX = "auto_center_x";  // centre the pill on the camera cut-out automatically
    static final int D_XOFF = 0;


    private static java.lang.ref.WeakReference<Object> kgManager;

    /** Captures the keyguard view manager so we can ask whether the PIN/pattern screen is showing. */
    static void hookKeyguardManager(ClassLoader cl) {
        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.phone.StatusBarKeyguardViewManager", cl);
        if (c == null) return;
        XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                kgManager = new java.lang.ref.WeakReference<>(param.thisObject);
            }
        });
    }

    private static java.lang.ref.WeakReference<Object> sbState;

    static void hookStatusBarState(ClassLoader cl) {
        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.StatusBarStateControllerImpl", cl);
        if (c == null) return;
        XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                sbState = new java.lang.ref.WeakReference<>(param.thisObject);
            }
        });
    }

    /** AOSP states: 0 = shade (unlocked), 1 = keyguard, 2 = shade over keyguard. */
    private int barState() {
        Object o = sbState == null ? null : sbState.get();
        if (o == null) return -1;
        try {
            Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, "getState");
            if (r instanceof Integer) return (Integer) r;
        } catch (Throwable ignored) { }
        return -1;
    }

    private static java.lang.ref.WeakReference<Object> shadeWin;

    static void hookShadeWindow(ClassLoader cl) {
        String[] names = {
                "com.android.systemui.statusbar.NotificationShadeWindowControllerImpl",
                "com.android.systemui.statusbar.phone.NotificationShadeWindowControllerImpl"
        };
        for (String n : names) {
            Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(n, cl);
            if (c == null) continue;
            XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    shadeWin = new java.lang.ref.WeakReference<>(param.thisObject);
                }
            });
        }
    }

    private Boolean pollBool(java.lang.ref.WeakReference<Object> ref, String name) {
        Object o = ref == null ? null : ref.get();
        if (o == null) return null;
        try {
            Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, name);
            if (r instanceof Boolean) return (Boolean) r;
        } catch (Throwable ignored) { }
        return null;
    }

    private static final java.util.ArrayList<java.lang.ref.WeakReference<View>> ccViews = new java.util.ArrayList<>();
    private static final java.util.ArrayList<java.lang.ref.WeakReference<View>> bouncerViews = new java.util.ArrayList<>();

    private static void track(java.util.ArrayList<java.lang.ref.WeakReference<View>> list, View v) {
        synchronized (list) {
            for (int i = list.size() - 1; i >= 0; i--) {
                View o = list.get(i).get();
                if (o == null) list.remove(i);
                else if (o == v) return;
            }
            if (list.size() < 24) list.add(new java.lang.ref.WeakReference<>(v));
        }
    }

    /** Remembers Control Center views (class name contains "ControlCenter"). */
    static void registerControlCenter(View v) { track(ccViews, v); }

    /** Remembers PIN / pattern (bouncer) views. */
    static void registerBouncer(View v) { track(bouncerViews, v); }

    private float effectiveAlpha(View v) {
        float a = 1f;
        View c = v;
        for (int i = 0; i < 12 && c != null; i++) {
            a *= c.getAlpha();
            c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
        }
        return a;
    }

    /** True while one of the tracked views is really visible and covers at least minFraction of the screen height. */
    private boolean anyVisible(java.util.ArrayList<java.lang.ref.WeakReference<View>> list,
                               float minFraction, float minAlpha) {
        int screenH = screenH();
        android.graphics.Rect r = tmpRect;
        synchronized (list) {
            for (int i = list.size() - 1; i >= 0; i--) {
                View v = list.get(i).get();
                if (v == null) { list.remove(i); continue; }
                try {
                    if (!v.isAttachedToWindow() || !v.isShown()
                            || v.getWindowVisibility() != View.VISIBLE) continue;
                    if (effectiveAlpha(v) < minAlpha) continue;
                    if (!v.getGlobalVisibleRect(r)) continue;
                    if (r.height() > screenH * minFraction) return true;
                } catch (Throwable ignored) { }
            }
        }
        return false;
    }

    private boolean controlCenterOpen() { return anyVisible(ccViews, 0.3f, 0.05f); }

    /** PIN / pattern screen showing or being swiped up. */
    private boolean pinScreenOpen() {
        boolean b = false;
        try { b = bouncerShowing(); } catch (Throwable ignored) { }
        return b || anyVisible(bouncerViews, 0.08f, 0.02f);
    }

    /** True while the notification shade / Control Center is pulled down (best effort). */
    private boolean panelExpanded() {
        Boolean a = pollBool(sbState, "isExpanded");
        Boolean b = pollBool(shadeWin, "getPanelExpanded");
        Boolean c = pollBool(shadeWin, "isPanelExpanded");
        return (a != null && a) || (b != null && b) || (c != null && c);
    }

    private String lastLineLog = "";

    private boolean bouncerShowing() {
        Object o = kgManager == null ? null : kgManager.get();
        if (o == null) return false;
        String[] names = {"isBouncerShowing", "primaryBouncerIsShowing",
                "isPrimaryBouncerShowing", "bouncerIsShowing"};
        for (String n : names) {
            try {
                Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, n);
                if (r instanceof Boolean) return (Boolean) r;
            } catch (Throwable ignored) { }
        }
        return false;
    }

    // ---- live list of notifications that are sitting in the panel (added when posted, removed when dismissed)
    private static final java.util.concurrent.ConcurrentHashMap<String, Boolean> activeNotifs =
            new java.util.concurrent.ConcurrentHashMap<>();
    private static volatile boolean notifTracking = false;   // true once real notification events were seen
    private static volatile boolean notifKick = false;       // a new notification arrived: blink right away
    private static String lastKickKey = "";
    private static long lastKickAt = 0;

    /** Only notifications the user can swipe away count (no ongoing / foreground service / group summary). */
    private static boolean countsAsNotif(android.service.notification.StatusBarNotification sbn) {
        try {
            android.app.Notification n = sbn.getNotification();
            if (n == null || sbn.getKey() == null) return false;
            int skip = android.app.Notification.FLAG_ONGOING_EVENT
                    | android.app.Notification.FLAG_FOREGROUND_SERVICE
                    | android.app.Notification.FLAG_GROUP_SUMMARY;
            if ((n.flags & skip) != 0) return false;
            return sbn.isClearable();
        } catch (Throwable t) {
            return false;
        }
    }

    static void hookNotificationList() {
        // 1) posted / removed events delivered to System UI's notification listener
        try {
            Class<?> h = Class.forName("android.service.notification.NotificationListenerService$MyHandler");
            int p = 1, r = 2;
            try { p = de.robv.android.xposed.XposedHelpers.getStaticIntField(h, "MSG_ON_NOTIFICATION_POSTED"); } catch (Throwable ignored) { }
            try { r = de.robv.android.xposed.XposedHelpers.getStaticIntField(h, "MSG_ON_NOTIFICATION_REMOVED"); } catch (Throwable ignored) { }
            final int postedWhat = p, removedWhat = r;
            XposedBridge.hookAllMethods(h, "handleMessage", new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        if (param.args.length == 0 || !(param.args[0] instanceof android.os.Message)) return;
                        android.os.Message m = (android.os.Message) param.args[0];
                        if (m.what != postedWhat && m.what != removedWhat) return;
                        if (m.obj == null) return;
                        Object o = de.robv.android.xposed.XposedHelpers.getObjectField(m.obj, "arg1");
                        if (!(o instanceof android.service.notification.StatusBarNotification)) return;
                        android.service.notification.StatusBarNotification sbn =
                                (android.service.notification.StatusBarNotification) o;
                        String key = sbn.getKey();
                        if (key == null) return;
                        notifTracking = true;
                        if (m.what == removedWhat) {
                            activeNotifs.remove(key);
                        } else if (countsAsNotif(sbn)) {
                            activeNotifs.put(key, Boolean.TRUE);
                            long now = android.os.SystemClock.uptimeMillis();
                            if (!(key.equals(lastKickKey) && now - lastKickAt < 2000)) {
                                lastKickKey = key;
                                lastKickAt = now;
                                notifKick = true;
                            }
                        } else {
                            activeNotifs.remove(key);
                        }
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: notification event hook failed: " + t);
        }
        // 2) the full list System UI asks for (boot, System UI restart): keeps the set correct
        try {
            XposedBridge.hookAllMethods(android.service.notification.NotificationListenerService.class,
                    "getActiveNotifications", new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Object res = param.getResult();
                        if (!(res instanceof android.service.notification.StatusBarNotification[])) return;
                        android.service.notification.StatusBarNotification[] arr =
                                (android.service.notification.StatusBarNotification[]) res;
                        boolean all = param.args.length == 0
                                || (param.args.length == 1 && param.args[0] instanceof Integer);
                        java.util.HashSet<String> keep = new java.util.HashSet<>();
                        for (android.service.notification.StatusBarNotification sbn : arr) {
                            if (sbn != null && countsAsNotif(sbn)) keep.add(sbn.getKey());
                        }
                        if (all) activeNotifs.keySet().retainAll(keep);
                        for (String k : keep) activeNotifs.put(k, Boolean.TRUE);
                        notifTracking = true;
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: notification list hook failed: " + t);
        }
    }

    // blink schedule (main thread only)
    private long burstEnd = 0, nextBurst = 0;

    /** True while the dot should be blinking right now. */
    private boolean notifBlinkWanted(boolean locked) {
        long now = android.os.SystemClock.uptimeMillis();
        if (notifTracking) {
            if (activeNotifs.isEmpty()) {          // everything dismissed: stop and reset
                burstEnd = 0; nextBurst = 0; notifKick = false;
                return false;
            }
            if (notifKick) { notifKick = false; nextBurst = 0; }
            if (nextBurst == 0 || now >= nextBurst) {
                burstEnd = now + NOTIF_BURST_MS;
                nextBurst = now + NOTIF_REPEAT_MS;
            }
            return now < burstEnd;
        }
        // fallback (tracking hooks not available on this ROM): old behaviour
        boolean b = now < notifBlinkUntil;
        if (b && (locked ? barState() == 2 : panelExpanded())) {
            notifBlinkUntil = 0;
            b = false;
        }
        return b;
    }

    // ---- notification blink: every StatusBarNotification System UI receives passes through here
    private static volatile long notifBlinkUntil = 0;
    private static String lastNotifKey = "";
    private static long lastNotifAt = 0;

    static void hookNotifications() {
        XposedBridge.hookAllConstructors(android.service.notification.StatusBarNotification.class,
                new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    android.service.notification.StatusBarNotification sbn =
                            (android.service.notification.StatusBarNotification) param.thisObject;
                    android.app.Notification n = sbn.getNotification();
                    if (n == null) return;
                    int skip = android.app.Notification.FLAG_ONGOING_EVENT
                            | android.app.Notification.FLAG_FOREGROUND_SERVICE
                            | android.app.Notification.FLAG_GROUP_SUMMARY;
                    if ((n.flags & skip) != 0) return;
                    // only fresh notifications (not the old list System UI receives at boot / on removal)
                    if (System.currentTimeMillis() - sbn.getPostTime() > 5000) return;
                    String key = sbn.getKey();
                    long now = android.os.SystemClock.uptimeMillis();
                    if (key != null && key.equals(lastNotifKey) && now - lastNotifAt < 2000) return;
                    lastNotifKey = key == null ? "" : key;
                    lastNotifAt = now;
                    notifBlinkUntil = now + NOTIF_BLINK_MS;
                } catch (Throwable ignored) { }
            }
        });
    }

    /** Phone call ringing / ongoing, or a VoIP call (WhatsApp etc.) using the call audio mode. */
    @SuppressWarnings("deprecation")
    private boolean callActive() {
        try {
            android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager)
                    ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null && tm.getCallState() != android.telephony.TelephonyManager.CALL_STATE_IDLE) return true;
        } catch (Throwable ignored) { }
        try {
            android.media.AudioManager am = (android.media.AudioManager)
                    ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int m = am.getMode();
                return m == android.media.AudioManager.MODE_IN_CALL
                        || m == android.media.AudioManager.MODE_IN_COMMUNICATION
                        || m == android.media.AudioManager.MODE_RINGTONE;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private long lastWaCheck = 0;
    private boolean cachedWa = false;

    /** True while WhatsApp (or WhatsApp Business) is the top app. */
    @SuppressWarnings("deprecation")
    private boolean isWhatsAppForeground() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastWaCheck < 700) return cachedWa;
        lastWaCheck = now;
        try {
            android.app.ActivityManager am = (android.app.ActivityManager)
                    ctx.getSystemService(Context.ACTIVITY_SERVICE);
            java.util.List<android.app.ActivityManager.RunningTaskInfo> t = am.getRunningTasks(1);
            if (t != null && !t.isEmpty() && t.get(0).topActivity != null) {
                String pkg = t.get(0).topActivity.getPackageName();
                cachedWa = "com.whatsapp".equals(pkg) || "com.whatsapp.w4b".equals(pkg);
            } else {
                cachedWa = false;
            }
        } catch (Throwable e) {
            cachedWa = false;
        }
        return cachedWa;
    }

    private final Context ctx;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final android.graphics.Rect tmpRect = new android.graphics.Rect();
    private int cachedScreenH = 0;
    private long screenHStamp = 0;

    /** Screen height in px. WindowMetrics is rebuilt on every call, so it is cached for 1 s (rotation / fold still follows). */
    private int screenH() {
        long now = android.os.SystemClock.uptimeMillis();
        if (cachedScreenH <= 0 || now - screenHStamp > 1000) {
            screenHStamp = now;
            try { cachedScreenH = wm.getCurrentWindowMetrics().getBounds().height(); } catch (Throwable ignored) { }
        }
        return cachedScreenH;
    }
    private final WindowManager wm;
    private XSharedPreferences xsp;
    private PillView view;
    private LineView lineView;
    private boolean lineAdded = false;
    private boolean lastLineVisible = true;
    private int lastLW = -1, lastLH = -1, lastLX = Integer.MIN_VALUE, lastLY = Integer.MIN_VALUE;
    private boolean added = false;
    private int lastW = -1, lastH = -1, lastY = Integer.MIN_VALUE, lastX = Integer.MIN_VALUE;
    private int curX = 0;
    private boolean lastVisible = true;
    private int winType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    // lockscreen ke upar dikhne wale system window types (pehle wala chalega jo allow ho)
    private static final int[] TYPES = {
            2017, // TYPE_STATUS_BAR_SUB_PANEL
            2024, // TYPE_NAVIGATION_BAR_PANEL
            2038  // TYPE_APPLICATION_OVERLAY (fallback)
    };

    // ---- expanding pill scenes (charging, silent / vibrate / ring, call, lock, unlock)
    // ---- status bar fades out (blur + alpha) while a scene is shown, like the iOS Dynamic Island
    private static final java.util.ArrayList<java.lang.ref.WeakReference<View>> sbViews = new java.util.ArrayList<>();
    static void registerStatusBar(View v) { track(sbViews, v); }
    private float sbF = 0f;
    private boolean sbWant = false, sbTouched = false;
    private android.animation.ValueAnimator sbAnim;
    private final Runnable sbEnforce = new Runnable() {
        @Override
        public void run() {
            if (!sbWant) return;
            if (panelExpanded()) { statusBarHide(false); return; }   // panel pulled down: give the bar back
            applySb(sbF);                                             // the system may reset the alpha: apply again
            handler.postDelayed(this, 40);                            // smooth: re-assert every ~2 frames
        }
    };
    private final PillView.SceneListener sbListener = new PillView.SceneListener() {
        @Override
        public void onScene(int s) { statusBarHide(s != PillView.SC_NONE); }
    };

    private final java.util.WeakHashMap<View, Float> sbApplied = new java.util.WeakHashMap<>();

    private void applySb(float f) {
        synchronized (sbViews) {
            for (int i = sbViews.size() - 1; i >= 0; i--) {
                View v = sbViews.get(i).get();
                if (v == null) { sbViews.remove(i); continue; }
                try {
                    if (!v.isAttachedToWindow()) continue;
                    if (f > 0.001f) {
                        sbTouched = true;
                        float al = 1f - f;
                        if (v.getAlpha() != al) v.setAlpha(al);                  // the system may reset it: cheap re-check
                        if (android.os.Build.VERSION.SDK_INT >= 31) {
                            Float prev = sbApplied.get(v);
                            if (prev == null || prev.floatValue() != f) {        // blur only when the value changed
                                float r = f * 12f * ctx.getResources().getDisplayMetrics().density;
                                v.setRenderEffect(f > 0.03f ? android.graphics.RenderEffect.createBlurEffect(
                                        r, r, android.graphics.Shader.TileMode.CLAMP) : null);
                                sbApplied.put(v, f);
                            }
                        }
                    } else if (sbTouched) {
                        v.setAlpha(1f);
                        if (android.os.Build.VERSION.SDK_INT >= 31) { v.setRenderEffect(null); sbApplied.remove(v); }
                    }
                } catch (Throwable ignored) { }
            }
        }
        if (f <= 0.001f) sbTouched = false;
    }

    private long lastSbCheck = 0;

    /** The status bar follows the scene state all the time (not only at the moment a scene starts / ends):
     *  e.g. a call pill that started while the shade was still moving, or after the shade was closed again. */
    private void sbReconcile() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastSbCheck < 100) return;
        lastSbCheck = now;
        boolean scene = sceneCur != PillView.SC_NONE;
        if (scene == sbWant) return;
        statusBarHide(scene);
    }

    private void statusBarHide(boolean hide) {
        boolean want = hide && prefBool(K_SB_HIDE, true) && !panelExpanded();
        if (want == sbWant && (sbAnim != null || (want ? sbF >= 1f : sbF <= 0f))) return;
        try {
            int nv = 0;
            synchronized (sbViews) {
                for (java.lang.ref.WeakReference<View> r : sbViews) { View v = r.get(); if (v != null && v.isAttachedToWindow()) nv++; }
            }
            XposedBridge.log("DP-SB hide=" + hide + " want=" + want + " scene=" + sceneCur + " statusBarViews=" + nv);
        } catch (Throwable ignored) { }
        sbWant = want;
        if (sbAnim != null) sbAnim.cancel();
        sbAnim = android.animation.ValueAnimator.ofFloat(sbF, want ? 1f : 0f);
        sbAnim.setDuration(want ? 380 : 520);
        sbAnim.setStartDelay(want ? 0 : 200);
        sbAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                sbF = (Float) a.getAnimatedValue();
                applySb(sbF);
            }
        });
        sbAnim.start();
        handler.removeCallbacks(sbEnforce);
        if (want) handler.postDelayed(sbEnforce, 40);
    }

    private int sceneCur = PillView.SC_NONE;
    private long sceneUntil = 0;            // 0 = stays until its own source ends it (a real call)
    private int lastRinger = -1;
    private String lastPreview = null;
    private boolean previewInit = false;
    private int battLevel = 50;
    private long callStart = 0;
    private boolean callWasRinging = false;

    // ---- toggles: torch, flight mode, hotspot, location
    private int lastAir = -1, lastHot = -1, lastLoc = -1;
    private Boolean lastTorch = null;
    private long torchIgnoreUntil = 0;

    private static int toggleScene(int kind, boolean on) {
        return PillView.SC_TORCH_ON + kind * 2 + (on ? 0 : 1);
    }

    private void fireToggle(int kind, boolean on, String key) {
        if (!isInteractive() || !prefBool(key, true)) return;
        showScene(toggleScene(kind, on), holdMs(), false);
    }

    private boolean locationOn() {
        try {
            android.location.LocationManager lm = (android.location.LocationManager)
                    ctx.getSystemService(Context.LOCATION_SERVICE);
            return lm != null && lm.isLocationEnabled();
        } catch (Throwable t) {
            return false;
        }
    }

    private void registerTorch() {
        try {
            android.hardware.camera2.CameraManager cm = (android.hardware.camera2.CameraManager)
                    ctx.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return;
            torchIgnoreUntil = android.os.SystemClock.uptimeMillis() + 2000;   // first callbacks only report the current state
            cm.registerTorchCallback(new android.hardware.camera2.CameraManager.TorchCallback() {
                @Override
                public void onTorchModeChanged(String cameraId, boolean enabled) {
                    try {
                        boolean init = android.os.SystemClock.uptimeMillis() < torchIgnoreUntil;
                        if (lastTorch != null && lastTorch == enabled) return;
                        lastTorch = enabled;
                        if (!init) fireToggle(0, enabled, K_ANIM_TORCH);
                    } catch (Throwable ignored) { }
                }
            }, handler);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: torch callback failed: " + t);
        }
    }

    private final Runnable sceneEnd = new Runnable() {
        @Override
        public void run() {
            if (sceneCur != PillView.SC_NONE && sceneUntil != 0
                    && android.os.SystemClock.uptimeMillis() + 30 >= sceneUntil) {
                sceneCur = PillView.SC_NONE;
                sceneUntil = 0;
                if (view != null) view.setScene(PillView.SC_NONE);
                lastLockCheck = 0;
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() { syncLockScene(); }
                }, 700);                       // let the pill finish closing, then show the lock icon again
            }
        }
    };

    private long lastLockCheck = 0;

    private boolean keyguardLockedNow() {
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
            return km != null && km.isKeyguardLocked();
        } catch (Throwable t) {
            return false;
        }
    }

    /** The lock icon stays on the pill for as long as the screen is on and still locked. */
    private void syncLockScene() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastLockCheck < 300) return;
        lastLockCheck = now;
        boolean want = prefBool(K_ANIM, true) && prefBool(K_ANIM_LOCK, true) && isInteractive() && keyguardLockedNow();
        if (want && sceneCur == PillView.SC_NONE) {
            showScene(PillView.SC_LOCK, 0, false);                       // stays until unlocked / screen off
        } else if (!want && sceneCur == PillView.SC_LOCK && sceneUntil == 0) {
            sceneCur = PillView.SC_NONE;
            sceneUntil = 0;
            handler.removeCallbacks(sceneEnd);
            if (view != null) view.setScene(PillView.SC_NONE);
        }
    }

    /** A real call (incoming or active) keeps the pill until it ends. */
    private boolean realCallScene() {
        return (sceneCur == PillView.SC_CALL || sceneCur == PillView.SC_INCOMING) && sceneUntil == 0;
    }

    private String incomingName = null;

    /** Looks the caller up in the contacts (background) and shows the name, or the number when unknown. */
    private void lookupCaller(final String number) {
        if (number == null || number.length() == 0) return;
        incomingName = number;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = null;
                try {
                    android.net.Uri u = android.net.Uri.withAppendedPath(
                            android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI, android.net.Uri.encode(number));
                    android.database.Cursor cur = ctx.getContentResolver().query(u,
                            new String[]{android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
                    if (cur != null) {
                        try { if (cur.moveToFirst()) name = cur.getString(0); } finally { cur.close(); }
                    }
                } catch (Throwable ignored) { }
                final String shown = (name != null && name.length() > 0) ? name : number;
                handler.post(new Runnable() {
                    @Override
                    public void run() { incomingName = shown; }
                });
            }
        }).start();
    }

    private long holdMs() {
        return Math.max(800L, pref(K_HOLD, D_HOLD) * 100L);
    }

    private void showScene(int s, long holdMs, boolean force) {
        if (view == null || !added) return;
        if (!force && !prefBool(K_ANIM, true)) return;
        // a real call keeps the pill, nothing interrupts it
        if (realCallScene() && s != PillView.SC_CALL && s != PillView.SC_INCOMING) return;
        sceneCur = s;
        sceneUntil = holdMs > 0 ? android.os.SystemClock.uptimeMillis() + holdMs : 0;
        handler.removeCallbacks(sceneEnd);
        if (holdMs > 0) handler.postDelayed(sceneEnd, holdMs);
        view.setScene(s);
    }

    private boolean isInteractive() {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            return pm == null || pm.isInteractive();
        } catch (Throwable t) {
            return true;
        }
    }

    // ---- outgoing call state: "Calling" until the other side picks up, then the timer starts
    private volatile int preciseFg = 0;          // PreciseCallState foreground call state (3 dialing, 4 alerting, 1 active)
    private volatile long preciseAt = 0;
    private Object preciseListener;

    /** Outgoing call that has not been answered yet (dialing / ringing at the other end). */
    @SuppressWarnings("deprecation")
    private boolean isDialing() {
        try {
            android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager)
                    ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null || tm.getCallState() != android.telephony.TelephonyManager.CALL_STATE_OFFHOOK) return false;
        } catch (Throwable ignored) { return false; }
        int st = preciseFg;
        return st == 3 || st == 4;               // DIALING, ALERTING
    }

    /** Listens to the precise call state (hidden API, so everything goes through reflection / Xposed). */
    @SuppressWarnings("deprecation")
    private void registerPreciseCall() {
        try {
            final android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager)
                    ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return;
            final android.telephony.PhoneStateListener l = new android.telephony.PhoneStateListener();
            preciseListener = l;
            Class<?> pcs = Class.forName("android.telephony.PreciseCallState");
            de.robv.android.xposed.XposedHelpers.findAndHookMethod(android.telephony.PhoneStateListener.class,
                    "onPreciseCallStateChanged", pcs, new de.robv.android.xposed.XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                if (param.thisObject != preciseListener) return;
                                Object r = de.robv.android.xposed.XposedHelpers.callMethod(param.args[0], "getForegroundCallState");
                                preciseFg = (r instanceof Integer) ? (Integer) r : 0;
                                preciseAt = android.os.SystemClock.uptimeMillis();
                            } catch (Throwable ignored) { }
                        }
                    });
            tm.listen(l, 0x00000800);            // LISTEN_PRECISE_CALL_STATE
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: precise call state unavailable: " + t);
        }
    }

    @SuppressWarnings("deprecation")
    private boolean isRinging() {
        try {
            android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager)
                    ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null && tm.getCallState() == android.telephony.TelephonyManager.CALL_STATE_RINGING) return true;
        } catch (Throwable ignored) { }
        try {
            android.media.AudioManager am = (android.media.AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            return am != null && am.getMode() == android.media.AudioManager.MODE_RINGTONE;
        } catch (Throwable ignored) { }
        return false;
    }

    private final android.content.BroadcastReceiver eventReceiver = new android.content.BroadcastReceiver() {
        @Override
        public void onReceive(Context c, android.content.Intent i) {
            try {
                onEvent(i);
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: event failed: " + t);
            }
        }
    };

    private void onEvent(android.content.Intent i) {
        String a = i.getAction();
        if (a == null) return;
        if (android.content.Intent.ACTION_POWER_CONNECTED.equals(a)) {
            lastPowerCheck = 0;
            refreshPower();
            if (prefBool(K_ANIM_CHARGE, true)) showScene(PillView.SC_CHARGE, holdMs(), false);
        } else if (android.content.Intent.ACTION_SCREEN_OFF.equals(a)) {
            if (!realCallScene() && sceneCur != PillView.SC_NONE) {
                sceneCur = PillView.SC_NONE;
                sceneUntil = 0;
                handler.removeCallbacks(sceneEnd);
                if (view != null) view.setScene(PillView.SC_NONE);
            }
        } else if (android.content.Intent.ACTION_SCREEN_ON.equals(a)) {
            boolean locked = false;
            try {
                android.app.KeyguardManager km = (android.app.KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
                locked = km != null && km.isKeyguardLocked();
            } catch (Throwable ignored) { }
            lastLockCheck = 0;
            if (locked && prefBool(K_ANIM_LOCK, true)) showScene(PillView.SC_LOCK, 0, false);   // stays until unlock
        } else if (android.content.Intent.ACTION_USER_PRESENT.equals(a)) {
            if (prefBool(K_ANIM_UNLOCK, true)) showScene(PillView.SC_UNLOCK, 1900, false);
        } else if ("android.intent.action.PHONE_STATE".equals(a)) {
            String st = i.getStringExtra("state");
            if ("RINGING".equals(st)) {
                String num = i.getStringExtra("incoming_number");
                if (num != null && num.length() > 0) lookupCaller(num);
            } else if ("IDLE".equals(st)) {
                incomingName = null;
            }
        } else if (android.content.Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(a)) {
            int st = i.getBooleanExtra("state", false) ? 1 : 0;
            if (st == lastAir) return;
            lastAir = st;
            fireToggle(1, st == 1, K_ANIM_FLIGHT);
        } else if ("android.net.wifi.WIFI_AP_STATE_CHANGED".equals(a)) {
            int ws = i.getIntExtra("wifi_state", -1);          // 11 = disabled, 13 = enabled
            if (ws != 11 && ws != 13) return;
            int st = ws == 13 ? 1 : 0;
            if (st == lastHot) return;
            boolean first = lastHot < 0;
            lastHot = st;
            if (!(first && st == 0)) fireToggle(2, st == 1, K_ANIM_HOTSPOT);
        } else if ("android.location.MODE_CHANGED".equals(a)) {
            int st = locationOn() ? 1 : 0;
            if (st == lastLoc) return;
            lastLoc = st;
            fireToggle(3, st == 1, K_ANIM_LOC);
        } else if (android.media.AudioManager.RINGER_MODE_CHANGED_ACTION.equals(a)) {
            int m = i.getIntExtra(android.media.AudioManager.EXTRA_RINGER_MODE, -1);
            if (m < 0 || m == lastRinger) return;
            lastRinger = m;
            if (!isInteractive() || !prefBool(K_ANIM_RINGER, true)) return;
            int sc = m == android.media.AudioManager.RINGER_MODE_SILENT ? PillView.SC_SILENT
                    : (m == android.media.AudioManager.RINGER_MODE_VIBRATE ? PillView.SC_VIBRATE : PillView.SC_RING);
            showScene(sc, holdMs(), false);
        }
    }

    /** Settings screen "Play" buttons: the app writes "name:timestamp", the pill plays that scene. */
    private void runPreview(String pv) {
        int k = pv.indexOf(':');
        String name = k > 0 ? pv.substring(0, k) : pv;
        int sc;
        switch (name) {
            case "charge": sc = PillView.SC_CHARGE; break;
            case "silent": sc = PillView.SC_SILENT; break;
            case "vibrate": sc = PillView.SC_VIBRATE; break;
            case "ring": sc = PillView.SC_RING; break;
            case "call": sc = PillView.SC_CALL; break;
            case "lock": sc = PillView.SC_LOCK; break;
            case "unlock": sc = PillView.SC_UNLOCK; break;
            case "incoming": sc = PillView.SC_INCOMING; break;
            case "torch_on": sc = PillView.SC_TORCH_ON; break;
            case "torch_off": sc = PillView.SC_TORCH_OFF; break;
            case "flight_on": sc = PillView.SC_FLIGHT_ON; break;
            case "flight_off": sc = PillView.SC_FLIGHT_OFF; break;
            case "hotspot_on": sc = PillView.SC_HOT_ON; break;
            case "hotspot_off": sc = PillView.SC_HOT_OFF; break;
            case "location_on": sc = PillView.SC_LOC_ON; break;
            case "location_off": sc = PillView.SC_LOC_OFF; break;
            default: return;
        }
        long hold = holdMs();
        if (sc == PillView.SC_INCOMING) hold = Math.max(hold * 2, 5000L);
        if (sc == PillView.SC_CALL) {
            // like a real call: "Ringing" first, then the timer starts from 0:00 when the call is picked up
            callStart = android.os.SystemClock.uptimeMillis();
            if (view != null) { view.setCallDialing(false); view.setCall(callStart, true); }
            hold = 3000L + Math.max(hold * 2, 5000L);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (view != null && sceneCur == PillView.SC_CALL) {
                        callStart = android.os.SystemClock.uptimeMillis();
                        view.setCall(callStart, false);
                    }
                }
            }, 3000L);
        }
        showScene(sc, hold, true);
    }

    public PillController(Context ctx) {
        this.ctx = ctx;
        this.wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
    }

    public void start() {
        try {
            xsp = new XSharedPreferences(MODULE_PKG, PREF_FILE);
            xsp.makeWorldReadable();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: prefs init: " + t);
        }
        try {
            android.media.AudioManager am = (android.media.AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) lastRinger = am.getRingerMode();
        } catch (Throwable ignored) { }
        try {
            android.content.IntentFilter f = new android.content.IntentFilter();
            f.addAction(android.content.Intent.ACTION_POWER_CONNECTED);
            f.addAction(android.content.Intent.ACTION_SCREEN_ON);
            f.addAction(android.content.Intent.ACTION_SCREEN_OFF);
            f.addAction(android.content.Intent.ACTION_USER_PRESENT);
            f.addAction(android.media.AudioManager.RINGER_MODE_CHANGED_ACTION);
            f.addAction(android.content.Intent.ACTION_AIRPLANE_MODE_CHANGED);
            f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
            f.addAction("android.location.MODE_CHANGED");
            f.addAction("android.intent.action.PHONE_STATE");
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                ctx.registerReceiver(eventReceiver, f, null, handler, Context.RECEIVER_NOT_EXPORTED);
            } else {
                ctx.registerReceiver(eventReceiver, f, null, handler);
            }
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: receiver failed: " + t);
        }
        try {
            lastAir = android.provider.Settings.Global.getInt(ctx.getContentResolver(), "airplane_mode_on", 0);
            lastLoc = locationOn() ? 1 : 0;
        } catch (Throwable ignored) { }
        registerTorch();
        registerPreciseCall();
        // small delay so System UI finishes booting
        handler.postDelayed(tick, 4000);
        handler.postDelayed(fastTick, 4000);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                update();
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: update failed: " + t);
            }
            handler.postDelayed(this, 400);
        }
    };

    // ---- smooth fade: follows the pull-down frame by frame instead of waiting for the 400 ms poll
    private float lastExt = 1f;
    /** 0..1 how far the Control Center is pulled open; read by CcBattery. */
    static volatile float ccProgress = 0f;
    /** Visible height of the tallest Control Center view as a fraction of the screen (not capped). */
    static volatile float ccHeightFrac = 0f;

    private android.view.Choreographer choreo;
    private final android.view.Choreographer.FrameCallback fastFrame = new android.view.Choreographer.FrameCallback() {
        @Override
        public void doFrame(long frameTimeNanos) { fastTick.run(); }
    };

    private final Runnable fastTick = new Runnable() {
        @Override
        public void run() {
            long next = 50;
            try {
                android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                if (pm != null && !pm.isInteractive()) {
                    ccProgress = 0f; ccHeightFrac = 0f;
                    next = 500;
                } else {
                    float p = panelProgress();
                    ccProgress = p;
                    boolean open = p > 0.05f;
                    if (open && !prevCcOpen) {
                        bringToFront(false);
                        frontRetry(3);                 // second swap only once the panel stands still (not mid pull)
                    }
                    prevCcOpen = open;
                    if (lineAdded && lineView != null) {
                        float ext = 1f - p;
                        if (ext != lastExt) {
                            lineView.setExternalFade(ext);
                            lastExt = ext;
                        }
                    }
                    // moving: run on every display frame (vsync), not on a free-running 16 ms timer that drifts
                    // against the frame clock and makes the fade stutter. Open and still: relaxed.
                    next = (p > 0f && p < 1f) ? 0 : (p >= 1f ? 33 : 50);
                    sbReconcile();
                }
            } catch (Throwable ignored) { }
            handler.removeCallbacks(this);
            try {
                if (choreo == null) choreo = android.view.Choreographer.getInstance();
                choreo.removeFrameCallback(fastFrame);
                if (next <= 0) { choreo.postFrameCallback(fastFrame); return; }
            } catch (Throwable ignored) { next = Math.max(next, 16); }
            handler.postDelayed(this, Math.max(next, 16));
        }
    };

    private int frontTries = 0;

    /** Second window swap: runs when the Control Center has stopped moving (a swap in the middle of the pull drops frames). */
    private void frontRetry(int tries) {
        frontTries = tries;
        handler.removeCallbacks(frontCheck);
        handler.postDelayed(frontCheck, 380);
    }

    private final Runnable frontCheck = new Runnable() {
        @Override
        public void run() {
            if (!prevCcOpen) return;
            if (ccProgress >= 0.97f) { bringToFront(true); return; }
            if (--frontTries > 0) handler.postDelayed(this, 250);   // still moving: look again a bit later
        }
    };

    /** 0 = Control Center closed, 1 = fully open. Same 30 % rule as controlCenterOpen(), but gradual. */
    private float panelProgress() {
        float best = 0f, hMax = 0f;
        int screenH = screenH();
        if (screenH <= 0) return 0f;
        Rect r = tmpRect;
        synchronized (ccViews) {
            for (int i = ccViews.size() - 1; i >= 0; i--) {
                View v = ccViews.get(i).get();
                if (v == null) { ccViews.remove(i); continue; }
                try {
                    if (!v.isAttachedToWindow() || !v.isShown()
                            || v.getWindowVisibility() != View.VISIBLE) continue;
                    float a = effectiveAlpha(v);
                    if (a <= 0.02f) continue;
                    if (!v.getGlobalVisibleRect(r)) continue;
                    float p = (r.height() - screenH * 0.12f) / (screenH * 0.18f);
                    p = Math.max(0f, Math.min(1f, p));
                    best = Math.max(best, p);
                    hMax = Math.max(hMax, r.height() / (float) screenH);
                } catch (Throwable ignored) { }
            }
        }
        ccHeightFrac = hMax;
        // the Control Center header itself (also true when it was reached by swiping over from the notification panel)
        best = Math.max(best, CcBattery.headerSignal());
        return best;
    }

    // ---- the pill must stay above the Control Center window (a window added later covers older ones of the same layer)
    private boolean prevCcOpen = false;
    private long lastFront = 0;

    /** Adds a fresh pill window on top, then removes the old one a moment later (no flicker: both look the same). */
    private void bringToFront(boolean force) {
        long now = android.os.SystemClock.uptimeMillis();
        if (!added || view == null || (!force && now - lastFront < 1200)) return;
        lastFront = now;
        try {
            final PillView old = view;
            PillView nv = new PillView(ctx);
            wm.addView(nv, params(lastW, lastH, lastY, winType));
            view = nv;
            if (lastVisible) nv.setAlpha(old.getAlpha()); else { nv.setAlpha(0f); nv.setVisibility(View.GONE); }
            update();   // applies dot / border / bolt / shape to the new window right away
            try { if (sceneCur != PillView.SC_NONE) nv.setScene(sceneCur); } catch (Throwable ignored) { }
            handler.postDelayed(new Runnable() {
                @Override public void run() { try { wm.removeViewImmediate(old); } catch (Throwable ignored) { } }
            }, 90);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: bring to front failed: " + t);
        }
    }

    private void setPillShown(boolean show) {
        if (view == null) return;
        view.animate().cancel();
        if (show) {
            view.setVisibility(View.VISIBLE);
            view.animate().alpha(1f).setDuration(240).start();
        } else {
            view.animate().alpha(0f).setDuration(180).withEndAction(new Runnable() {
                @Override public void run() {
                    if (!lastVisible && view != null) view.setVisibility(View.GONE);
                }
            }).start();
        }
    }

    private int pref(String key, int def) {
        try {
            if (xsp != null) return xsp.getInt(key, def);
        } catch (Throwable ignored) { }
        return def;
    }

    private boolean prefBool(String key, boolean def) {
        try {
            if (xsp != null) return xsp.getBoolean(key, def);
        } catch (Throwable ignored) { }
        return def;
    }

    private int mm(float mm10) {
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_MM, mm10 / 10f, dm));
    }

    /** Pixels the camera cut-out centre is away from the screen centre (+ = right). 0 if unknown. */
    private int cutoutOffsetX() {
        try {
            DisplayCutout dc = wm.getCurrentWindowMetrics().getWindowInsets().getDisplayCutout();
            if (dc == null) {
                android.hardware.display.DisplayManager dmg = (android.hardware.display.DisplayManager)
                        ctx.getSystemService(Context.DISPLAY_SERVICE);
                android.view.Display d = dmg == null ? null : dmg.getDisplay(android.view.Display.DEFAULT_DISPLAY);
                dc = d == null ? null : d.getCutout();
            }
            if (dc != null) {
                Rect r = dc.getBoundingRectTop();
                if (r != null && !r.isEmpty()) {
                    int screenW = wm.getCurrentWindowMetrics().getBounds().width();
                    return (r.left + r.right) / 2 - screenW / 2;
                }
            }
        } catch (Throwable ignored) { }
        return 0;
    }

    private int cutoutCenterY() {
        try {
            DisplayCutout dc = wm.getCurrentWindowMetrics().getWindowInsets().getDisplayCutout();
            if (dc != null) {
                Rect r = dc.getBoundingRectTop();
                if (r != null && !r.isEmpty()) return (r.top + r.bottom) / 2;
            }
        } catch (Throwable ignored) { }
        try {
            android.hardware.display.DisplayManager dmg = (android.hardware.display.DisplayManager)
                    ctx.getSystemService(Context.DISPLAY_SERVICE);
            android.view.Display d = dmg == null ? null : dmg.getDisplay(android.view.Display.DEFAULT_DISPLAY);
            DisplayCutout dc = d == null ? null : d.getCutout();
            if (dc != null) {
                Rect r = dc.getBoundingRectTop();
                if (r != null && !r.isEmpty()) return (r.top + r.bottom) / 2;
            }
        } catch (Throwable ignored) { }
        try {
            int id = ctx.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (id > 0) return ctx.getResources().getDimensionPixelSize(id) / 2;
        } catch (Throwable ignored) { }
        return mm(30);
    }

    // ---- charging / power saving colours
    private static final int COLOR_WHITE = 0xFFFFFFFF;
    private static final int COLOR_GREEN = 0xFF34C759;
    private static final int COLOR_YELLOW = 0xFFFFCC00;
    private boolean charging = false, powerSave = false;
    private long lastPowerCheck = 0;

    private void refreshPower() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastPowerCheck < 1000) return;
        lastPowerCheck = now;
        try {
            android.content.Intent i = ctx.registerReceiver(null,
                    new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
            charging = i != null && i.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) != 0;
            if (i != null) {
                int lv = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int sc = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
                if (lv >= 0 && sc > 0) battLevel = Math.round(lv * 100f / sc);
            }
        } catch (Throwable ignored) { }
        try {
            android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            powerSave = pm != null && pm.isPowerSaveMode();
        } catch (Throwable ignored) { }
    }

    private int lineColor() {
        return charging ? COLOR_GREEN : (powerSave ? COLOR_YELLOW : COLOR_WHITE);
    }

    private void update() {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (added && pm != null && !pm.isInteractive()) { // screen off: nothing to update
                if (view != null) { view.setBlink(false); view.setStrokeBlink(false); }
                return;
            }
        } catch (Throwable ignored) { }
        if (xsp != null && xsp.hasFileChanged()) xsp.reload();
        refreshPower();
        final boolean call = prefBool(K_IND_CALL, true) && callActive();
        final boolean callAnim = prefBool(K_ANIM, true) && prefBool(K_ANIM_CALL, true);
        final boolean callOutline = call && !callAnim;   // old green blinking outline only without the call pill

        boolean enabled = prefBool(K_ENABLED, true);
        boolean portrait = ctx.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_PORTRAIT;
        boolean locked = false;
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager)
                    ctx.getSystemService(Context.KEYGUARD_SERVICE);
            locked = km != null && km.isKeyguardLocked();
        } catch (Throwable ignored) { }
        boolean visible = enabled && portrait && (!locked || prefBool(K_LOCK, true));

        int capW = mm(pref(K_WIDTH, D_WIDTH));
        int capH = mm(pref(K_HEIGHT, D_HEIGHT));
        int expW = Math.max(capW, mm(pref(K_EXP_W, D_EXP_W)));
        int pad = Math.round(ctx.getResources().getDisplayMetrics().density * 14f);
        // the window has room for the expanded pill and its glow; the pill is drawn centred inside it
        int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
        int animH = mm(D_HEIGHT);                    // scene text / icons keep this size, whatever the pill height is
        int bigH = Math.max(capH, animH);            // the capsule grows to this height while a scene is shown
        int w = Math.round(Math.max(expW * 1.35f, bigH * 10f)) + 2 * pad;
        w = Math.min(w, screenW);
        int h = bigH + 2 * pad;
        int y = cutoutCenterY() - h / 2 + mm(pref(K_YOFF, D_YOFF));
        int x = (prefBool(K_AUTOX, true) ? cutoutOffsetX() : 0) + mm(pref(K_XOFF, D_XOFF));
        curX = x;

        if (!added) {
            view = new PillView(ctx);
            for (int type : TYPES) {
                try {
                    wm.addView(view, params(w, h, y, type));
                    winType = type;
                    added = true;
                    break;
                } catch (Throwable t) {
                    XposedBridge.log("DynamicPill: window type " + type + " failed: " + t);
                    view = new PillView(ctx);
                }
            }
            if (!added) return;
            view.setAlpha(0f);                                  // fade in on first show
            view.animate().alpha(1f).setDuration(350).start();
            lastW = w; lastH = h; lastY = y; lastX = x;
        } else if (w != lastW || h != lastH || y != lastY || x != lastX) {
            wm.updateViewLayout(view, params(w, h, y, winType));
            lastW = w; lastH = h; lastY = y; lastX = x;
        }

        try { view.setGeometry(capW, capH, expW, pad); view.setAnimHeight(animH); view.setSceneListener(sbListener); } catch (Throwable ignored) { }
        try { view.setBattery(battLevel); view.setDotScale(pref(K_DOT_PCT, 100)); } catch (Throwable ignored) { }
        try { if (!call) syncLockScene(); } catch (Throwable ignored) { }
        try { view.setScales(pref(K_TXT_PCT, 100), pref(K_ICO_PCT, 100)); } catch (Throwable ignored) { }
        try {
            // call pill stays for the whole call
            boolean realScene = realCallScene();
            if (call && callAnim) {
                boolean ringing = isRinging();                 // incoming, not answered yet
                boolean dialing = !ringing && isDialing();     // outgoing, the other side has not answered yet
                boolean waiting = ringing || dialing;
                if (callWasRinging && !waiting) callStart = android.os.SystemClock.uptimeMillis();   // answered: timer from 0:00
                callWasRinging = waiting;
                int want = (ringing && prefBool(K_ANIM_INCOMING, true)) ? PillView.SC_INCOMING : PillView.SC_CALL;
                if (!realScene) {
                    callStart = android.os.SystemClock.uptimeMillis();
                    showScene(want, 0, false);
                } else if (sceneCur != want) {
                    showScene(want, 0, true);          // incoming <-> active call: blur, resize, new content
                }
                view.setCallDialing(dialing);
                view.setCall(callStart, waiting);
                view.setIncomingName(incomingName);
            } else if (realScene) {
                sceneCur = PillView.SC_NONE;
                sceneUntil = 0;
                view.setScene(PillView.SC_NONE);
            }
            // "Play" buttons in the settings screen
            String pv = null;
            try { if (xsp != null) pv = xsp.getString(K_PREVIEW, null); } catch (Throwable ignored) { }
            if (!previewInit) {
                previewInit = true;
                lastPreview = pv;
            } else if (pv != null && !pv.equals(lastPreview)) {
                lastPreview = pv;
                runPreview(pv);
            }
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: scene failed: " + t);
        }

        try { view.setPillAlpha(pref(K_ALPHA, 100)); } catch (Throwable ignored) { }
        try { view.setSmooth(pref(K_SMOOTH, 30)); } catch (Throwable ignored) { }
        try {
            int bw = mm(pref(K_BORDER, 4));
            if ((charging || callOutline) && bw < 1) bw = Math.round(ctx.getResources().getDisplayMetrics().density * 3f);
            view.setBorder(bw);
            // call or charging = green outline (a call also makes it blink)
            view.setStrokeColor((callOutline || charging) ? COLOR_GREEN : COLOR_WHITE);
            view.setStrokeBlink(callOutline);
        } catch (Throwable ignored) { }

        try {
            boolean dotOn = prefBool(K_IND_DOT, true);
            boolean wa = dotOn && prefBool(K_IND_WA, true) && !locked && isWhatsAppForeground();
            // permanent dot = yellow; green while WhatsApp is open
            view.setDot(dotOn, wa ? COLOR_GREEN : COLOR_YELLOW);
            view.setBolt(charging && prefBool(K_IND_CHARGE, true));
            // blinks (3 s) every 15 s for as long as an unread notification is in the panel
            boolean blink = dotOn && prefBool(K_IND_NOTIF, true) && notifBlinkWanted(locked);
            view.setBlink(blink);
            // neon outline for as long as WhatsApp is open
            view.setNeon(prefBool(K_WA_NEON, true) && !locked && isWhatsAppForeground(), COLOR_NEON);
        } catch (Throwable ignored) { }

        if (visible != lastVisible) {
            lastVisible = visible;
            setPillShown(visible);
        }

        try {
            updateLine(portrait, locked);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: line failed: " + t);
        }
    }

    private void updateLine(boolean portrait, boolean locked) {
        // Lock screen: shown, but hidden on the PIN / pattern screen (also while swiping it up)
        // and while the shade / Control Center is pulled over it.
        // Unlocked (home + apps): shown, hidden while the shade / Control Center is open.
        boolean hide = false;
        try {
            if (locked) hide = pinScreenOpen() || barState() == 2 || controlCenterOpen();
            else hide = panelExpanded() || controlCenterOpen();
            if (CcBattery.headerSignal() > 0.05f) hide = true;   // Control Center on screen, however it was opened
        } catch (Throwable ignored) { }
        boolean expanded = hide;
        boolean on = prefBool(K_LINE_ON, true) && portrait && !hide;
        String why = "on=" + on + " locked=" + locked + " expanded=" + expanded;
        if (!why.equals(lastLineLog)) {
            lastLineLog = why;
            XposedBridge.log("DynamicPill: line " + why);
        }
        int w = mm(pref(K_LINE_W, D_LINE_W));
        int h = Math.max(1, mm(pref(K_LINE_H, 6)));
        int fromRight = mm(pref(K_LINE_X, D_LINE_X));
        int top = mm(pref(K_LINE_Y, D_LINE_Y));
        int alpha = pref(K_LINE_ALPHA, 70);

        // The line is an overlay window (hosting it inside the keyguard view was invisible on some ROMs).
        boolean vis = on;
        int x = Math.max(0, fromRight - w / 2);
        if (!lineAdded) {
            LineView lv = new LineView(ctx);
            wm.addView(lv, lineParams(w, h, x, top, winType));     // throws -> nothing is kept, next tick retries cleanly
            lineView = lv;
            lineAdded = true;
            lastLW = w; lastLH = h; lastLX = x; lastLY = top;
            lineView.setShown(vis);
            lastLineVisible = vis;
        } else if (w != lastLW || h != lastLH || x != lastLX || top != lastLY) {
            wm.updateViewLayout(lineView, lineParams(w, h, x, top, winType));
            lastLW = w; lastLH = h; lastLX = x; lastLY = top;
        }
        lineView.setLineAlpha(alpha);
        lineView.setTint(lineColor());
        if (vis != lastLineVisible) {
            lineView.setShown(vis);
            lastLineVisible = vis;
        }
    }

    private WindowManager.LayoutParams lineParams(int w, int h, int x, int y, int type) {
        WindowManager.LayoutParams lp = params(w, h, y, type);
        lp.gravity = Gravity.TOP | Gravity.END;   // x = distance from the right edge
        lp.x = x;
        lp.setTitle("DynamicPillLine");
        return lp;
    }

    private WindowManager.LayoutParams params(int w, int h, int y, int type) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.x = curX;                 // offset from the screen centre: camera auto-centre + manual fine tune
        lp.y = y;
        lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.alpha = 1.0f; // window alpha poora solid
        lp.setTitle("DynamicPill");
        return lp;
    }
}

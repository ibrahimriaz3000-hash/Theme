package com.dynamicpill.module;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/**
 * iOS style "100%" text next to the battery icon in the Control Center header.
 * The status bar is not touched: whatever the system "Battery indicator" option says
 * (icon only / percentage in icon / percentage outside) still applies there.
 */
final class CcBattery {
    private CcBattery() { }

    static final String K_CC_BATT = "cc_batt_pct";

    private static XSharedPreferences xsp;
    private static long lastReload = 0;

    static synchronized boolean enabled() {
        try {
            if (xsp == null) {
                xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                xsp.makeWorldReadable();
            }
            long now = System.currentTimeMillis();
            if (now - lastReload > 1000) {
                lastReload = now;
                if (xsp.hasFileChanged()) xsp.reload();
            }
            return xsp.getBoolean(K_CC_BATT, true);
        } catch (Throwable t) {
            return true;
        }
    }

    /** Called for every BatteryMeterView that attaches; does nothing outside the Control Center. */
    static void attach(View battery, boolean inControlCenter) {
        try {
            if (!inControlCenter) return;
            ViewGroup host;
            int index;
            if (battery instanceof LinearLayout) {
                host = (ViewGroup) battery;
                index = 0; // text first, icon last: "100% [battery]"
            } else if (battery.getParent() instanceof LinearLayout) {
                host = (ViewGroup) battery.getParent();
                index = host.indexOfChild(battery);
            } else {
                XposedBridge.log("DynamicPill: CC battery host is not a LinearLayout, skipped");
                return;
            }
            for (int i = 0; i < host.getChildCount(); i++) {
                if (host.getChildAt(i) instanceof PctText) return; // already added
            }
            PctText t = new PctText(battery.getContext(), battery);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = android.view.Gravity.CENTER_VERTICAL;
            host.addView(t, Math.max(0, index), lp);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CC battery attach failed: " + t);
        }
    }

    private static int lastStyleLog = -2;

    /**
     * The system "Battery indicator" option (Settings -> Notifications & status bar):
     * 0 = icon only, 1 = percentage in the icon, 2 = percentage next to the icon.
     * The in-icon number is drawn on a canvas (not a TextView), so it can only be detected from the setting.
     * Returns true when the system already shows the percentage somewhere (then we must stay hidden).
     */
    static boolean settingShowsPercent(Context c) {
        int style = -1;
        try {
            style = android.provider.Settings.System.getInt(c.getContentResolver(), "battery_indicator_style", -1);
        } catch (Throwable ignored) { }
        if (style != lastStyleLog) {
            lastStyleLog = style;
            XposedBridge.log("DynamicPill: battery_indicator_style=" + style);
        }
        if (style > 0) return true;
        if (style == 0) return false;
        try {
            return android.provider.Settings.System.getInt(c.getContentResolver(),
                    "status_bar_show_battery_percent", 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    /** True when the system itself already shows a percentage text inside the battery view. */
    private static boolean systemShowsPercent(View root, View ignore) {
        if (!(root instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) root;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == ignore) continue;
            if (c instanceof TextView) {
                CharSequence s = ((TextView) c).getText();
                if (s != null && s.length() > 0 && c.getVisibility() == View.VISIBLE
                        && c.getWidth() > 0 && c.getAlpha() > 0.1f
                        && Character.isDigit(s.charAt(0))) return true;
            } else if (systemShowsPercent(c, ignore)) {
                return true;
            }
        }
        return false;
    }

    static final class PctText extends TextView {
        private final View battery;
        private int level = -1;
        private boolean registered = false;

        private final BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) { read(i); sync(); }
        };

        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                sync();
                if (isAttachedToWindow()) postDelayed(this, 1000);
            }
        };

        PctText(Context ctx, View battery) {
            super(ctx);
            this.battery = battery;
            setTextColor(Color.WHITE);
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            setSingleLine(true);
            setIncludeFontPadding(false);
            int p = Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 3,
                    ctx.getResources().getDisplayMetrics()));
            setPadding(0, 0, p, 0);
            setVisibility(View.GONE);
        }

        private void read(Intent i) {
            if (i == null) return;
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
        }

        private boolean first = true;
        private boolean target = false;
        private boolean forced = false;
        private int pend = 0;

        // fires the moment the user changes "Battery indicator" in Settings
        private final android.database.ContentObserver styleObs =
                new android.database.ContentObserver(new android.os.Handler(android.os.Looper.getMainLooper())) {
            @Override
            public void onChange(boolean selfChange) { forced = true; sync(); }
        };

        private void apply(boolean show, boolean anim) {
            target = show;
            animate().cancel();
            if (show) {
                setVisibility(View.VISIBLE);
                if (anim) {
                    setAlpha(0f);
                    animate().alpha(1f).setDuration(220).start();
                } else {
                    setAlpha(1f);
                }
            } else if (anim) {
                animate().alpha(0f).setDuration(160).withEndAction(new Runnable() {
                    @Override public void run() {
                        if (!target) setVisibility(View.GONE);
                    }
                }).start();
            } else {
                setAlpha(1f);
                setVisibility(View.GONE);
            }
        }

        private void sync() {
            try {
                // nothing to do while the Control Center is closed (also avoids useless layout work)
                if (!first && !forced && !battery.isShown()) return;
                forced = false;
                if (level >= 0) {
                    String s = level + "%";
                    if (!s.contentEquals(getText())) setText(s);
                }
                boolean bySetting = settingShowsPercent(getContext());
                boolean want = level >= 0 && enabled() && !bySetting && !systemShowsPercent(battery, this);
                if (first) {                     // already in place from the very first frame: no pop-in
                    first = false;
                    pend = 0;
                    apply(want, false);
                    return;
                }
                if (bySetting) {                 // system shows %, so hide at once: never two numbers on screen
                    pend = 0;
                    if (target || getVisibility() != View.GONE) apply(false, false);
                    return;
                }
                if (want == target) { pend = 0; return; }
                if (++pend >= 2) {               // must stay changed for 2 checks: no flicker mid-animation
                    pend = 0;
                    apply(want, true);
                }
            } catch (Throwable ignored) { }
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            try {
                if (!registered) {
                    read(getContext().registerReceiver(rcv, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
                    registered = true;
                }
            } catch (Throwable ignored) { }
            try {
                getContext().getContentResolver().registerContentObserver(
                        android.provider.Settings.System.getUriFor("battery_indicator_style"), false, styleObs);
            } catch (Throwable ignored) { }
            removeCallbacks(loop);
            sync();                               // decide right now, before the first draw
            postDelayed(loop, 1000);
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            removeCallbacks(loop);
            try { getContext().getContentResolver().unregisterContentObserver(styleObs); } catch (Throwable ignored) { }
            try {
                if (registered) getContext().unregisterReceiver(rcv);
            } catch (Throwable ignored) { }
            registered = false;
        }
    }
}

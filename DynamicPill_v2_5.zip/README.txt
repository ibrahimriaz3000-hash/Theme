Dynamic Pill (LSPosed module) v2.2
1. Upload this zip's contents to a GitHub repo (the .github/workflows/build.yml is included).
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot. Open settings from the "Dynamic Pill" Control Center tile (long press) or from LSPosed.

Changes in 2.2
- Status Bar Padding (Left / Right / Top) removed completely: settings section, status bar height hook,
  content insets hook, keyguard/status bar view tracking. System UI status bar is left untouched.
- Pill is centred on the real camera cutout / status bar height again (no padding offset).
- Slider no longer gets stuck capturing touches when the gesture is cancelled.

Changes in 2.3
- New switch "Battery % in Control Center (iOS style)" (settings -> CONTROL CENTER, on by default).
  Shows "66%" before the battery icon in the Control Center header. The status bar is untouched, so with
  Settings -> Notifications & status bar -> Battery indicator = icon only, the status bar has no percentage
  and only the Control Center shows it. If the system already shows a percentage text there, ours hides itself.

Changes in 2.4  (smooth pull-down, no glitch)
- Grabber line now fades out frame by frame while you pull the status bar / Control Center down
  (before it waited for a 400 ms poll, then popped), and fades back in when it closes.
- Pill fades in / out (enable switch, lock screen switch, first start) instead of popping.
- Control Center battery % is laid out before the first frame (no pop-in while the panel opens),
  changes are debounced (no flicker) and fade in/out; no work is done while the panel is closed.
- build.yml replaced with a stronger workflow (debug + release APK, checksums, cache, retry, auto release on tag).

Changes in 2.5
- Fixed double battery percentage in the Control Center: with Settings -> Battery indicator = "Percentage (in the icon)"
  or "Percentage outside", our extra "63%" now stays hidden at once (read from the system setting; the in-icon
  number is canvas-drawn so it could not be detected from the view). It re-checks the moment you change that option.
  Only with "icon only" does the Control Center show the iOS style percentage.

package com.dynamicpill.module;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import de.robv.android.xposed.XposedBridge;

/**
 * 3.3.8 "Tiles Size": makes the round tiles of the Control Center grid (QSTileItemView) bigger / smaller.
 * Only the round icon (QSTileItemIconView) of each tile is scaled around its own centre, so the grid
 * positions, the labels and the other parts do not move. The value is re-read on every draw (cheap, the
 * setting itself is cached for 700 ms), so a change applies the next time the Control Center is drawn.
 */
final class GridTiles {
    private static boolean logged = false;

    /** Wide cards (Wi-Fi / Mobile data), brightness + volume sliders and the tile card panel: the whole view grows. */
    static void attachWhole(View v) { attach(v, v); }

    /** Round grid tile: only its icon circle grows. */
    static void attach(final View tile) { attach(tile, findIcon(tile, 0)); }

    private static void attach(final View tile, final View target) {
        try {
            if (target == null) {
                if (!logged) { logged = true; XposedBridge.log("DynamicPill: tiles size - view not found in " + tile.getClass().getName()); }
                return;
            }
            // a scaled view must not be cut off by its cell / row / grid
            View v = target;
            for (int i = 0; i < 5 && v != null; i++) {
                if (v instanceof ViewGroup) { ((ViewGroup) v).setClipChildren(false); ((ViewGroup) v).setClipToPadding(false); }
                android.view.ViewParent p = v.getParent();
                v = p instanceof View ? (View) p : null;
            }
            final ViewTreeObserver.OnPreDrawListener l = new ViewTreeObserver.OnPreDrawListener() {
                @Override public boolean onPreDraw() {
                    apply(target);
                    return true;
                }
            };
            tile.getViewTreeObserver().addOnPreDrawListener(l);
            tile.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override public void onViewAttachedToWindow(View x) { }
                @Override public void onViewDetachedFromWindow(View x) {
                    try { x.getViewTreeObserver().removeOnPreDrawListener(l); } catch (Throwable ignored) { }
                    x.removeOnAttachStateChangeListener(this);
                }
            });
            apply(target);
        } catch (Throwable ignored) { }
    }

    private static void apply(View icon) {
        float s = ControlCenterSize.gridScale() / 100f;
        if (icon.getScaleX() == s && icon.getScaleY() == s) return;
        int w = icon.getWidth(), h = icon.getHeight();
        if (w > 0 && h > 0) { icon.setPivotX(w / 2f); icon.setPivotY(h / 2f); }
        icon.setScaleX(s);
        icon.setScaleY(s);
    }

    private static View findIcon(View v, int depth) {
        if (v.getClass().getName().endsWith("QSTileItemIconView")) return v;
        if (depth > 3 || !(v instanceof ViewGroup)) return null;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) {
            View r = findIcon(g.getChildAt(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }
}

Dynamic Pill (LSPosed module) v2.18
1. Upload this zip's contents to a GitHub repo (the .github/workflows/build.yml is included).
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot. Open settings from the "Dynamic Pill" Control Center tile (long press) or from LSPosed.

Changes in 2.2
- Status Bar Padding (Left / Right / Top) removed completely: settings section, status bar height hook,
  content insets hook, keyguard/status bar view tracking. System UI status bar is left untouched.
- Pill is centred on the real camera cutout / status bar height again (no padding offset).
- Slider no longer gets stuck capturing touches when the gesture is cancelled.

Changes in 2.3
- New switch "Battery % in Control Center (iOS style)" (settings -> CONTROL CENTER, on by default).
  Shows "66%" before the battery icon in the Control Center header. The status bar is untouched, so with
  Settings -> Notifications & status bar -> Battery indicator = icon only, the status bar has no percentage
  and only the Control Center shows it. If the system already shows a percentage text there, ours hides itself.

Changes in 2.4  (smooth pull-down, no glitch)
- Grabber line now fades out frame by frame while you pull the status bar / Control Center down
  (before it waited for a 400 ms poll, then popped), and fades back in when it closes.
- Pill fades in / out (enable switch, lock screen switch, first start) instead of popping.
- Control Center battery % is laid out before the first frame (no pop-in while the panel opens),
  changes are debounced (no flicker) and fade in/out; no work is done while the panel is closed.
- build.yml replaced with a stronger workflow (debug + release APK, checksums, cache, retry, auto release on tag).

Changes in 2.5
- Fixed double battery percentage in the Control Center: with Settings -> Battery indicator = "Percentage (in the icon)"
  or "Percentage outside", our extra "63%" now stays hidden at once (read from the system setting; the in-icon
  number is canvas-drawn so it could not be detected from the view). It re-checks the moment you change that option.
  Only with "icon only" does the Control Center show the iOS style percentage.

Changes in 2.6  (status bar icons jerk while pulling down)
- The Control Center battery "63%" no longer takes any layout space while the panel is being pulled. Before, it widened
  the header the moment it appeared, so the status bar icons (signal / wifi) that morph into the Control Center header
  jumped and vanished. Now the header moves exactly like stock, and the % expands in smoothly (width + fade) only after
  the Control Center is open, and collapses as soon as you start closing it.

Changes in 2.7  (icons glitch while closing the Control Center)
- 2.6 used a threshold that was reached early while pulling, so the % still changed the header layout in the middle of
  the icon morph (opening and closing). Now the % is only revealed after the panel has stopped moving fully open
  (settled for 160 ms), and it collapses the moment the panel starts to close, before the status bar icons
  (signal / wifi) morph back. Nothing changes the header layout while it is moving.

Changes in 2.8  (icons wrong while the Control Center is closing)
- The screenshots show the Control Center header icons (wifi + 62% + battery, signal clipped) while the panel is
  fading / blurring away. HyperOS closes it with a fade, so height alone could not detect the closing.
  Now the % follows the header itself: it is revealed only after the header has stopped moving and is fully opaque,
  and collapses (70 ms) the instant the header moves or fades, before the icons morph back into the status bar.
  When the Control Center is hidden the % is reset, so the next opening always starts clean.

Changes in 2.9
- Pill shape: new setting PILL -> "Corner smoothness (0 = circle)", default 30.
  The corners were already fully round (radius = half the height), so they cannot get rounder; instead the ends now
  use an iOS style continuous curve (superellipse) so the curve blends into the straight edges without a visible
  seam. 0 = old plain circular capsule, 100 = softest / squarest curve. The white border follows the same shape.

Changes in 2.10
- Control Center battery %: pure fade in / fade out. The text no longer wipes in from the side: it is drawn pinned
  next to the battery icon. Opening: space opens first (text still invisible), then the text fades in (smoothstep, 320 ms).
  Closing: the text fades out fast (150 ms) while the space closes, so the status bar icons are not squeezed.

Changes in 2.11  (pill visible in dark mode)
- In system dark mode the black pill vanished on a black status bar. Now a thin light rim plus a faint soft glow
  fades in around the pill (350 ms) and fades out again in light mode. The rim follows the pill's smooth shape.
  Settings -> PILL -> "Dark mode rim (0 = off)", default 60. It hides itself while the white border is shown.

Changes in 2.12  (camera in the centre of the pill)
- NEW: "Auto-center on camera cut-out" (default on): the pill is centred on the real camera cut-out reported by the
  system instead of the screen centre, so the camera sits in the middle of the pill even if it is off-centre.
- NEW: "Horizontal offset" slider (+-15 mm, 0.1 mm steps) for fine tuning left / right.
- "Vertical offset" range increased from +-10 mm to +-15 mm.

Changes in 2.13
- REMOVED: "Dark mode rim" (setting, glow and rim drawing) completely.
- Control Center battery %: it no longer sits next to the battery icon. It now floats right ABOVE the carrier name
  (e.g. "ZONG"), right aligned with it, and fades in / out in place (no sliding). It takes no layout space, so the
  header icons are never moved. If the carrier view is not found it is placed a little above the battery icon.
  Same rules as before: fades in only after the Control Center is fully open, fades out the moment you start closing,
  hidden when the system "Battery indicator" already shows a percentage.

Changes in 2.14
- The battery % above the carrier name / next to the battery icon is removed (this module no longer adds it).
- NEW: Control Center info line above the date (left side):  "57% UNTIL 1:30 ●"
  (charging: "57% FULL AT 2:15"). No fade in / out effect: it just moves with the header.
- The green dot blinks all the time while the Control Center is open.
- Estimated time source, in order: 1) system battery discharge prediction (PowerManager, Android 12+),
  2) remaining charge / smoothed current draw, 3) observed % drop rate. Charging: system charge-time estimate.
  Time uses the phone's 12 / 24 hour setting; adds the weekday if it ends on another day.

Changes in 2.15
- Time now always has AM / PM ("UNTIL 1:30 PM").
- The info line follows the system "Battery indicator" setting:
  Graphical (icon only)      -> "57% UNTIL 1:30 PM"
  Number inside the icon     -> "UNTIL 1:30 PM"   (no % : the icon already shows it)
  Number next to the icon    -> "UNTIL 1:30 PM"   (no % : it is already next to the icon)
  Charging: "FULL AT 2:15 PM" (with the % in front only for icon only).
  Changing the option updates the line at once.

Changes in 2.16  (pill / line with the Control Center)
- Control Center opened directly: the pill no longer disappears. When the Control Center starts to open the pill
  window is swapped for a fresh one on top (new window is added first, the old one removed 90 ms later = no flicker),
  and once more 300 ms later, so a Control Center window created later can not cover it.
- Control Center reached by swiping over from the notification panel: the grabber line no longer shows up.
  The line is now also hidden (and fades with it) whenever the Control Center header is really on screen,
  however it was opened (new signal from the header, checked every 40 ms).

Changes in 2.17
- Diagnostic only (no visible change): the first 2 times the Control Center is fully open, the module writes its
  view tree (class names, ids, positions) to the LSPosed module log, every line starts with "DP-TREE".
  Needed to build the paged Control Center (page 1: toggles + sliders, swipe -> page 2: icons) without guessing.

Changes in 2.18  (two page Control Center)
- NEW: Control Center with 2 pages (settings -> CONTROL CENTER -> "Two page Control Center", on by default).
    Page 1: Mobile data / Wi-Fi, media, sliders and the first two rows of icons.
    Page 2: the remaining icon rows + Edit.
  Swipe left = page 2, swipe right = page 1 (a right swipe on page 1 still does what the system does).
  The pages slide + fade like the example video; the header (pill, UNTIL line, date, status icons) stays.
- Built without the real view names: icon rows are found by their round shape, the split is above the 3rd icon row.
  If the Control Center has fewer than 3 icon rows nothing is changed. Switch it off in settings if it ever looks wrong.
- The Control Center is always put back to normal when it closes.

Changes in 3.1  (v2.18 + Color Guard + expanding pill animations, merged into one project)
- Everything from v2.18 is kept: auto-centre on the camera cut-out, horizontal / vertical offset, Control Center
  battery % + estimated time, two page Control Center, pill and line staying above the Control Center.
- NEW (from 3.0): GOODLOOKS COLOR GUARD (ROOT) section - Contrast, Saturation, Red / Green / Blue, Responsive Mode,
  Dedup Apply, SurfaceFlinger Guard, Adaptive Debounce, Boost Keepalive, Black Almond Auto + Intensity.
  The Magisk / KernelSU module is bundled in assets/colorguard and installed through root on first open of settings.
- NEW (from 3.1): ANIMATIONS (EXPANDING PILL) section - master switch, a switch for Charging, Silent / Vibrate / Ring,
  Call, Lock, Unlock and the WhatsApp neon outline, Expanded width, Show time.
- NEW: Text size (60-150 %) and Icon size (60-140 %) sliders for the animation text and icons.
- NEW: PREVIEW (TAP TO PLAY ON THE PILL) - Play buttons for Charging, Silent, Vibrate, Ring, Call, Lock, Unlock.
- The pill now grows to the width its text and icons really need, so nothing is cut off; if the window were ever
  too narrow the whole content is scaled down to fit.
- A pill window swapped to the front (Control Center) keeps the animation that is playing.
- Call: with the call pill on, the old green blinking outline is not used (switch in INDICATORS applies only when
  the call pill is off).
- Control Center info line ("37% UNTIL 6:46 AM") now sits on the same row as the carrier name (ZONG): its text
  baseline is aligned with the carrier's baseline (carrier found by name / shape, re-checked every 500 ms).
  If no carrier text is found it stays above the date as before.
- Animation pill size is now independent of the pill size: text and icons are designed for a fixed 4.0 mm pill
  height (Text size / Icon size sliders still scale them). However small the idle pill is made, a scene grows the
  capsule to that height and width, so text and icons look the same.
- Charging pill is wider (more room around "Charging", the percentage and the battery); the camera stays covered.
- Control Center: carrier name (ZONG) moves to the left and the battery info line ("35% UNTIL 6:41 AM") sits on the
  right, same row. Switch: CONTROL CENTER -> "Carrier name left, battery info right (swap)", on by default.
- Status bar hides while a pill animation plays (like the example video): the status bar content (clock, signal,
  Wi-Fi, battery, also the lock screen one) blurs and fades out as the pill expands, stays hidden for "Show time",
  then fades back in after the pill has shrunk. It is released at once if the notification panel / Control Center
  is pulled down. Switch: ANIMATIONS -> "Hide status bar while the pill animates" (on by default).
- Pill animations are smoother and longer: expand 640 ms (softer overshoot), content fades in over 560 ms with a
  finer 12-step blur, collapse 640 ms, scene-to-scene switch 420 ms, status bar fade 380 ms out / 520 ms back in.
- Call pill: shows "Ringing" while the phone rings and the timer starts from 0:00 when the call is picked up.
  The Call preview now plays the same flow (3 s ringing, then the timer).
- NEW pills: Torch on/off, Flight mode on/off, Hotspot on/off, Location on/off (icon pill + label, coloured when on,
  grey + slash when off). Each has a switch in ANIMATIONS and two Play buttons in PREVIEW.
- NEW: Incoming call pill - ringing handset with ripples, the caller name (or number; "Incoming call" when the
  system does not give it) and decline / accept circles (drawn only, the pill cannot be tapped). While the phone
  rings this pill is shown; when the call is picked up it changes smoothly into the call pill and the timer starts
  from 0:00. Switch in ANIMATIONS, Play button in PREVIEW. With the switch off the old "Ringing" call pill is used.
- NEW: "Dot size" slider (40-250 %) in INDICATORS for the dot inside the pill.
- Lock pill: the lock icon now stays on the pill for as long as the screen is on and still locked (it used to
  disappear after 1.6 s). It ends with the unlock animation when the phone is unlocked, or when the screen turns off.
  If another pill plays meanwhile (charging, torch, ...), the lock icon comes back after it.

Changes in 3.1.2  (hello in the Control Center header)
- The rainbow "hello" (teal > yellow > orange > pink > purple > blue) is now drawn permanently in the Control Center
  header, on the right, where the carrier name (ZONG) used to be. It fades in / out exactly like the header.
- The carrier name moves to the left, above the "76% UNTIL ..." line (same left edge as the date). The info line and the
  date stay where they were. The media tile and everything else is untouched.
- Switch: Settings -> CONTROL CENTER -> "Hello in the header (carrier name moves up-left)" (on by default).
  With it off the old behaviour comes back (the "Carrier name left, battery info right" swap switch works again).
- If the carrier name view cannot be found on a ROM, nothing is moved and no hello is drawn.

Changes in 3.1.3  (header flicker while the Control Center opens / closes)
- The carrier name (ZONG) was moved up with an absolute translationY every frame. The system animates that same value
  while the header opens / closes, so the two fought each other and the header flickered (ZONG, info line and hello
  jumped to different rows). Now our shift is ADDED to the system's animated value, and the info line / hello follow the
  carrier's real (animated) position again, so everything moves together.
- The white halo around the "hello" is softer.
- Play Protect "App scan recommended" is Google's own prompt for apps it has not seen; it cannot be switched off from
  inside the app. See the reply notes: sign every build with the same keystore (KEYSTORE_BASE64 secret).

Changes in 3.1.4  (header flicker + gap)
- Header flicker / double text fixed: the Control Center can hold more than one battery view, and each one created its own
  info line + "hello" and both moved the same carrier name (ZONG) every frame (double "68% UNTIL", double "hello", jumping rows).
  Now only ONE overlay is active at a time; the others draw nothing and never touch the carrier.
- Gap between the "68% UNTIL ..." line and the date reduced: ZONG + info line now keep the same row spacing down to the date.
  It is measured once the header stands still, so nothing jitters while it opens / closes.

Changes in 3.1.5
- "hello" is now exactly in the middle (vertically) between the ZONG row and the "67% UNTIL ..." row.
- Swap switch (CONTROL CENTER -> "Swap: ZONG + battery info right, hello left"): ON = ZONG and the battery info line sit on the
  right (right aligned), the hello moves to the left, where the date starts. OFF = ZONG + info line left, hello right.
  Same single-overlay logic as 3.1.4, so no flicker while switching or while the header animates.
- REMOVED: "Two page Control Center" completely (setting, CcPager.java, touch hook).

Changes in 3.1.6
- Swap layout (ZONG + info right, hello left): the blinking green dot now sits on the percentage side (before the "91% ..."),
  so the text ends exactly under ZONG / the status icons and nothing sticks out on the right.

Changes in 3.1.7
- NEW: raise the phone -> the Always-On display turns on (ambient pulse). Settings -> ALWAYS-ON DISPLAY -> "Raise phone: Always-On
  display turns on" (on by default). While the screen is off the module waits on the system's wake-up PICK_UP gesture sensor
  (one-shot trigger sensor, no polling) and asks System UI's doze code (DozeTriggers.requestPulse) to pulse the display; if that
  class is not reachable it sends the "com.android.systemui.doze.pulse" broadcast. LSPosed log lines start with "DP-RAISE"
  (they tell whether a pick-up sensor was found).

Changes in 3.1.8  (status bar with the incoming / call pill, smoother fade)
- The status bar hide was decided only at the exact moment a pill started / ended. If the shade or the call UI was still moving
  at that moment (typical when a call comes in), the status bar stayed visible next to the pill (clock + signal beside the pill)
  and was never hidden again. Now the status bar follows the pill state continuously (checked every ~100 ms): any pill (incoming
  call, call, lock, charging, ...) hides it, and it is hidden again after the shade / Control Center was closed while a pill
  is still showing.
- Smoother fade: the alpha is re-asserted every ~40 ms (was 80), the blur is only rebuilt when its value changes.
- LSPosed log: lines "DP-SB hide=.. want=.. scene=.. statusBarViews=N" show every status bar decision
  (statusBarViews=0 would mean the status bar view was not found on this ROM).

Changes in 3.1.10
- REMOVED: rounded screen corners (setting, sliders, CornerView.java) - back to the 3.1.8 behaviour.
- "Raise phone: Always-On display" stays removed.
- Kept: single info-line overlay (no flicker), swap layout (ZONG + info right, hello left, dot before the %),
  hello centred between the two rows, status bar follows the pill state (incoming call etc.), two page Control Center removed.

Changes in 3.1.11  (smoother Control Center up / down + optimization)
- Control Center pull-down / close now follows the display frame clock (Choreographer) instead of a free-running 16 ms
  timer, so the grabber line fade and the pill / header logic move in step with every frame. Idle polling is lighter.
- The second "pill window to front" swap no longer happens in the middle of the pull (it dropped frames); it waits until
  the Control Center stands still.
- Header overlay (info line + hello): the blinking green dot pauses while the header moves, so the overlay is not
  redrawn every frame during the pull; it resumes when the header has settled.
- Header overlay: prefs are read from one cached snapshot (was 2 synchronized reloads per frame); the 40 ms visibility
  poll slows to 300 ms while the panel is closed; battery changes while closed are applied after the next frame.
- Grabber line: the gradient is built once and the fade is a paint alpha (before: new LinearGradient on every frame).
- Screen height is cached (WindowMetrics was rebuilt many times per second).
- Fixed: a failing addView of the line window created a new LineView every 400 ms (leak).
- Fixed: header overlay kept the battery view alive after it detached (leak); it is now disposed on detach.
- Fixed: iOS switch snap() could be overwritten by a running animation; no ArgbEvaluator allocation per draw.
- Settings: slider values are written at most every ~90 ms (was one prefs write per touch event).
- Removed the old "DP-TREE" view-tree diagnostic (it walked up to 700 views on the UI thread while the panel was open).

Changes in 3.1.12  (SB Logo Hook merged in)
- NEW: status bar logo (33 built-in logos or your own PNG) is now part of this module. The separate "SB Logo Hook" module
  is not needed any more: disable / uninstall it in LSPosed, otherwise both modules touch the same status bar.
- Settings -> STATUS BAR LOGO: show logo, position (left after the clock / right at the end of the icons), logo, size,
  follow the status bar icon colour, margin start / end, and "Apply now" (restarts System UI with root).
  Logo settings are read when System UI starts, so use "Apply now" (or reboot) after changing them.
- Custom logo: put the image at Download/SBLogo/statusbar_logo.png and pick "Custom".
- The logo lives inside the status bar view, so it fades / hides together with the status bar while the pill animates.
- Logo code is isolated in StatusLogo.java and wrapped in try / catch: if the status bar layout of a ROM does not match,
  the logo is skipped (LSPosed log lines "DynamicPill-Logo: ...", "container id not found" + "view tree:") and the pill is unaffected.
- Nothing else changed: pill, line, Control Center, Color Guard, build.yml and the manifest are the same as 3.1.11.

Changes in 3.1.13  (settings screen with tabs)
- Settings now have a scrollable tab bar under the title (like the Xiaomi Accessibility screen): Pill, Indicators,
  Animations, Preview, Line, Logo, Control Center, Color Guard. The selected tab is a dark pill; each tab shows only its own
  settings. The selected tab is kept when the screen is recreated (rotation / dark mode change).
- No setting, key or default changed: only the layout of the settings screen.

Changes in 3.1.14  (logo spacing, lock screen overlap)
- Logo position "Right": the logo is now placed directly AFTER the battery, inside the battery's own parent (status bar and
  lock screen bar each get their own). Before, it lived in a separate container: on the lock screen the system moves the
  battery to the right edge and the logo stayed where it was, so the two touched / overlapped. Now the layout of the bar
  makes room for the logo, and it hides together with the battery.
- Vertical centre: the logo is moved (translationY only, no relayout) so its centre is exactly the centre of the battery
  icon, re-checked after every layout. It can no longer sit higher or lower than the battery.
- Spacing: "Auto" margin start is 4 dp from the battery and margin end 0 for the right position (sliders still override).
  Position "Left" is unchanged (after the clock).
- Safety net: if the battery cannot be used as anchor on a ROM (not in a horizontal LinearLayout) the old container
  placement is used after 1.5 s, and the LSPosed log shows "DynamicPill-Logo: battery parent not usable: ..." with the
  view classes, so it can be adjusted.

Changes in 3.1.15  (Control Center "64% UNTIL 3:10 PM" comes back faster)
- The battery-time code itself is unchanged since 3.1.11. What was lost is its data: the % history and the current-draw
  average lived only in memory, so every System UI restart (module update, "Apply now", reboot) started from zero and the
  "UNTIL <time>" part stayed empty for 15+ minutes. The % history is now saved in System UI's own files folder
  (dp_batt_samples.txt, last 3 hours) and loaded again, so after a restart the time shows right away.
  The very first run after this update still needs one normal stretch of use (about 15 minutes and a 1 % drop) to fill it.
- If the time is still missing, LSPosed log shows one line (every 5 min): "DynamicPill: no UNTIL time yet: prediction=...
  current=... counter=... emaCount=... samples=..." - it says which of the three estimators had no data.


Changes in 3.1.16  (status bar logo removed completely)
- Removed: the Logo tab, StatusLogo.java, all 33 ic_statusbar_logo_* drawables, the logo prefs (logo_enabled, logo_position,
  logo_style, logo_size, logo_tint, logo_margin_start, logo_margin_end), the zygote init and the System UI hooks for the logo.
- Removed helpers that only the Logo tab used (pickRow, actionRow, restartSystemUi, dp units).
- Old logo values left in pill_prefs are simply ignored. If the logo was still showing, restart System UI once.
- Control Center "UNTIL <time>": CcBattery is based on 3.1.15 (saved % history, "no UNTIL time yet" log line) plus:
  * current / charge counter reported in mA / mAh by some ROMs are now converted to uA / uAh, and an unsupported
    (negative) current reading is ignored;
  * the %-drop fallback needs 5 min (was 15) and a 1 % drop;
  * NEW last fallback: the last drain rate measured on this phone is saved (dp_batt_rate.txt, valid 7 days) and used
    until a fresh estimate exists, so the time also shows right after a System UI restart / reboot.
- MainHook.java is identical to 3.1.11 again (no logo hooks, no zygote init).

Changes in 3.1.17  (outgoing call pill)
- Call pill: while you are calling someone and they have not answered yet, the pill now says "Calling" (incoming calls
  still say "Ringing"). The 0:00 timer only starts when the other side picks up.
- Uses the precise call state (DIALING / ALERTING) through a PhoneStateListener hook. If System UI refuses it, the pill
  behaves as before and LSPosed logs "DynamicPill: precise call state unavailable".


Changes in 3.1.18  (dot side button, icon-only pills)
- NEW: Settings -> INDICATORS -> "Dot side" button. Tap it to swap the idle dot between the right (default) and the left
  side of the pill. The green charging bolt automatically goes to the opposite side. Pref key: dot_left.
- Pill animations (Silent / Vibrate / Ring, Torch, Flight, Hotspot, Location, Incoming call): the coloured / grey capsule
  behind the icon is gone, only the vector icon is drawn (in its own colour: red silent bell, orange vibrate, yellow torch,
  orange plane, green hotspot, blue location, white ring bell, grey when "Off"). Slashes keep a thin black gap so they
  stay readable without a background. The icon area is narrower, so the pill is a bit shorter and the icon sits closer
  to the text. Incoming call: green handset (with ripples) and red / green decline / accept handsets, no circles.

Changes in 3.1.19  (no backgrounds at all)
- Every pill is vector only now: the charging pill battery is a thin outline + fill (no dark track), the icon capsules stay
  removed. The "Coloured background" switch of 3.1.18 is removed; backgrounds are never drawn.

Changes in 3.1.20  (custom dot colour)
- NEW: Settings -> INDICATORS -> "Dot colour": Auto (yellow, as before), 9 preset swatches and a hue slider for any colour.
  Pref key: dot_color (0 = auto). The dot still turns green while WhatsApp is open if that switch is on.


Changes in 3.1.29  (Control Center sliders fixed, scope, reset / apply buttons)
- FIXED: Control Center sliders had no effect. Cause 1: almost every size of the Control Center is written in layout XML
  (@dimen/... in layout_width / margin / padding) and the inflater reads those through TypedArray, which was never hooked
  (only Resources.getDimension*). New DimenHook.java hooks both Resources and TypedArray (getDimension, getDimensionPixelSize,
  getDimensionPixelOffset, getLayoutDimension x2). Cause 2: the dimen -> slider cache was keyed by resource id only, but System UI
  and miui.systemui.plugin both use package id 0x7f, so one id could mean two different dimens and the sliders mixed up; the cache
  is now keyed by AssetManager + id.
- NEW: every slider has a round reset button (arrow) next to its value; it writes the default at once.
  Control Center and Status Bar tabs have an ACTIONS card: "Apply now" (restarts System UI with root, so the Control Center is
  rebuilt with the new sizes) and "Reset this tab". Color Guard sliders have a reset button too (they apply live as before).
- REMOVED (did not work): Status bar height, Padding top, Clock / icons padding start / end (settings, hooks, keys).
  Kept: Padding start (left) and Padding end (right).
- LSPosed scope now recommends: System UI (com.android.systemui), System UI Plug-in (miui.systemui.plugin) and
  System Framework (android). Plug-in: dimen hooks are installed when the plug-in loads. Framework: scope is registered,
  no framework feature is active at the moment.
- Values are re-read every 0.7 s (was 1.5 s). After changing a Control Center slider use "Apply now" (or reopen the panel).


Control Center cleanup (3.1.30)
- Removed sliders: Tile size, Big tile size, Text size, Custom/edit tile size, Tile columns, Side margin, Corner radius, Brightness slider, Detail panels, Edit screen, Expanded tile view, MiPlay/media cards, Device controls, Notification panel header, Focus notifications (and their hooks).
- Kept: Tile spacing, Header, Header top offset, Media player, Footer, Page dots, Volume panel, Universal cards, Power menu.

3.1.31: Control Center -> MORE PARTS -> new "Hide media player" switch (next to the Media player slider). On = media player collapses to size 0. Reopen Control Center (or restart System UI) to apply.

3.2.1: Tile card redone (switch: Control Center -> MORE PARTS -> "Tile card in the media player place", default off).
- The "+" button and the name list are gone.
- Tiles shown in the card are left out of the real tile list (QSListController.getListItems), so the grid closes up (no gap).
- Circles draw the tile's own icon (QSTile.getState().icon); a tap calls QSTile.click(), long press QSTile.longClick().
- Edit screen: the card is shown there too. Tap a tile in the edit grid = into the card (max 4); tap it again, or tap its circle in the card = out.
- Default tiles: mobile data, Wi-Fi, airplane mode. Restart System UI after switching it on.

3.2.2: Tile card fix. In 3.2.1 the tile list hook was never installed (the plug-in has its own class loader), so the card stayed empty.
- The hook is now installed when System UI loads the plug-in class QSListController (ClassLoader.loadClass), and again from the media panel's own class loader as a backup.
- The LSPosed log shows "DynamicPill: tile card hooks go on" and "tile list hook is running" when it works.
- After installing the APK: reboot (or at least restart System UI), then open the Control Center.

3.2.3: Tile card fix for the Control Center edit screen (the card was shown but stayed empty).
- In the edit screen System UI builds its own tile records, so the card could not find the real tiles any more.
- The card now takes the real tiles from the list controller's own added / copied lists (QSListController.addedTiles, copiedTiles), and as a last resort the State (icon, label, on/off) of the tile view that is shown in the edit grid (QSTileItemView / QSCardItemView updateState, updateCustomizeState).
- Tapping a tile in the edit grid (into the card / out of the card) now redraws the card at once.
- If the card is still empty in the edit screen, the LSPosed log has one line "DynamicPill: tile card empty in edit screen, specs=... records=... tiles=... states=..." - send me that line.
- Normal screen behaviour is unchanged. Restart System UI after installing.

3.2.4: Tile card was empty because the saved list of card tiles was empty (LSPosed log: specs=[]). The hooks, tiles and states were all found correctly.
- The list is now stored under a new key, so the stuck empty list is ignored and the default tiles (mobile data, Wi-Fi, airplane mode) come back.
- Edit screen: TAP a tile (do not drag) to put it into the card / take it out. The log shows "DynamicPill: tile card now holds [...]" after every tap.

3.2.5: Tile card showed letters (M, H, S, F) instead of icons.
- QSTile.Icon.getDrawable(context) was called with the plug-in's context, but the icon resource ids belong to System UI, so no drawable came back and the card fell back to the first letter of the label.
- The icon is now fetched with the System UI context first (plug-in context only as a fallback), and copied before tinting so the real tile's own icon is never recoloured.
- If an icon still cannot be loaded the LSPosed log has: "DynamicPill: tile card icon not found, icon=<class> error=<exception>".

3.2.6: Tile card - taps, icons, edit screen.
- Tap on a circle did nothing: QSTile.click() was called without arguments, but this System UI version has click(View) / longClick(View). The tap now finds the real method whatever its signature is (and passes the circle as the view). The LSPosed log shows "DynamicPill: tile card tap <spec> -> true/false".
- Letters instead of icons for system tiles (mobile data, flashlight ...): if QSTile.Icon.getDrawable() gives nothing, the icon is now loaded by the plug-in's own QSTileItemIconView (the same class the tile grid uses) and copied.
- Edit screen: tiles that are in the card are left out of the edit grid too (like in the normal screen), so they are not shown twice. Tap a circle in the card to take a tile out again (it goes back to the grid); tap a tile in the grid to put it in the card.

3.2.7: "Hide media player" switch removed (settings, key and hook). The Media player size slider and the tile card switch stay.

3.2.8: Tile card - a tile that is ON now has a yellow disc with a dark icon (was white disc, blue icon). Colours: ON_DISC / ON_ICON at the top of TileCard.java.

3.2.9: Smoothness.
- The wide Wi-Fi / Mobile data cards scrolled their title as a marquee in a very narrow box (text ran sideways and was cut hard at the edges = flicker in the screen recording). Marquee is off now (QSCardItemView.startMarquee is skipped, titles get ellipsize END and stay still). Log line: "DynamicPill: card text marquee hooks on".
- Tile card circles are only rebuilt / redrawn when the tile's state, icon or label changed (before: new icon copy + redraw every 350 ms tick, alpha / visibility were set again each time).

3.3.0: Tile card - old media text ("No playback history") showing behind the card while the Control Center opens / closes.
- Cause: the media player's own views were only hidden by a 350 ms timer, and the media controller (expand / spread animation, bind, mode change) or its constraint group made them visible again in between, so they showed through the translucent card for a few frames (seen in the screen recording).
- The tile card switch now means "media player off": the original media views are hidden at once when the panel attaches, in front of every frame (pre-draw), and again after every media controller callback (onBindViewHolder, applyPayload, onExpandChange, onSpreadChange, updateMode, updateConfiguration, onUnbindViewHolder). Log line: "DynamicPill: media player off hooks on".
- Switch off = media player comes back exactly as before (visibility restored). If the card cannot be created the media player is restored too.
- Switch label changed to "Tile card instead of the media player (media player off, + button, 4 tiles)". Restart System UI after installing.

3.3.1: Tile card glass look + colour theme, liquid glass pill switch removed.
- Tile card circles now have the Control Center glass look: translucent body (lighter at the top, deeper at the bottom), a soft highlight on the upper half and a thin bright rim. (Android cannot blur what is behind a view from a module, so the frost is made with translucency + gradients.)
- New setting: Control Center -> MORE PARTS -> "Tile card colour (icons follow it, Auto = yellow)". Pick a swatch or slide the hue. A tile that is ON is tinted with that colour and its icon gets a dark shade of the same hue; an OFF tile stays grey glass with a faint touch of the colour. Auto = the old yellow. Key: cc_tile_color.
- Removed: "Liquid glass pill (frosted glass look, off = black)" - the switch, its key (pill_glass), and all glass drawing code. The pill is always plain black now.

3.3.2: Tile card circles now look exactly like the system's own tiles (the glass look of 3.3.1 is gone).
- ON tile = white disc + coloured icon, OFF tile = translucent grey disc with a thin light rim + white icon (colours taken from the system tiles of the screenshot: disc #FAF8F9, blue icon #3C88F8).
- The icon colour follows the phone's theme: it is read from the icon tint of a real ON tile in the Control Center grid (QSTileItemView, checked every 3 s); the blue above is used until one is found (and if the tint read is white / black / transparent it is ignored).
- Settings: "Tile card icon colour (Auto = same as the system tiles)". Auto follows the system; a swatch / hue overrides it.

3.3.3: Removed the "Page dots" and "Power menu (reboot / shutdown)" sliders, and the note under "Apply now / Reset this tab" ("Values are saved at once ...").
- Both removed sliders are also switched off in ControlCenterSize: an old saved value (e.g. Page dots 200 %) no longer changes anything, the page dots and the power menu are at the system size again. Restart System UI after installing.

3.3.4: Settings labels shortened: the switch is now just "Tile card", the colour row is "Tile Cards Icon Color". Nothing else changed.

3.3.5: Control Center settings cut down. Removed: Tile spacing, Header (clock, date, buttons), Header top offset, Footer and bottom area, Volume panel, Universal cards (and the TILES / PANEL / PLUGIN PARTS sections).
- Their effect is switched off too (ControlCenterSize.load): an old saved value (e.g. Volume panel 90 %) no longer changes anything, those parts are at the system size again.
- The "Media player" size slider is renamed "Tile Cards" (it sizes the card). Remaining in the tab: Tile Cards slider, Tile card switch, Tile Cards Icon Color. Restart System UI after installing.

3.3.6: New slider "Icons Scale" (Control Center tab, under Tile Cards Icon Color), 50 - 150 %, default 100 %.
- Up to 116 % the circles of the tile card grow (at 116 % they touch each other); above that the icon grows inside the full size circle. Below 100 % everything gets smaller. Applied within a second, no restart needed. Key: cc_tile_scale.

3.3.7: App name changed to "MIUIThemePark" (strings.xml app_name: app info, launcher, LSPosed module list). The package name (com.dynamicpill.module), the settings screen title, and the Quick Settings tile name are unchanged, so saved settings and the LSPosed scope keep working.

3.3.8: New slider "Tiles Size" (Control Center tab, under Icons Scale), 60 - 150 %, default 100 %.
- It makes the round tiles of the Control Center grid (Settings, Auto-brightness, Flashlight, Location ... ) bigger or smaller. Only the round tile itself is scaled around its own centre, so the rows, the Wi-Fi / Mobile data cards, the tile card and the sliders stay where they are. Around 125 % the circles touch each other.
- Applied the next time the Control Center is drawn (close and open it once), no restart needed. Key: cc_grid_scale.
- If nothing changes, the LSPosed log has: "DynamicPill: tiles size - icon view not found in <class>" - send me that line.

3.3.9: The "Tiles Size" slider (now "Control Center Size (tiles, cards, sliders)") also resizes the top part: the Wi-Fi / Mobile data cards, the tile card and the brightness + volume sliders (3.3.8 only did the round grid tiles).
- Each of them grows around its own centre, the round grid tiles only as a circle. Around 110 % the top parts start to touch their neighbours, above that they overlap a little; use the Tile Cards slider to shrink the card if needed.
- Applied when the Control Center is drawn again (close / open it once). LSPosed log if something does not change: "DynamicPill: tiles size - view not found in <class>".

3.3.10: Control Center Size - top part no longer overlaps or gets cut at the sides.
- 3.3.9 scaled the Wi-Fi / Mobile data cards, the tile card and the sliders each around its own centre, so they ran into each other and the sides were cut. Now they are scaled as ONE block around the top centre (the gaps grow with it, same look as the round tiles below), no parent clips it any more, and the block never gets wider than the screen (12 dp margin).
- The round tiles and the Edit button below move down by exactly the extra height of the block, so nothing overlaps them. Round tiles still grow around their own centre.
- Close / open the Control Center once after changing the slider. If the Edit button does not follow, tell me.

package com.dynamicpill.module;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.WeakHashMap;

/**
 * Tile card: replaces the media player card of the Control Center (miui.systemui.controlcenter.panel.main.media.
 * MediaPlayerPanel, MIUISystemUIPlugin.apk) with a 2x2 card of round tiles and a "+" button that opens a picker.
 * The tiles are mirrors of the real Control Center tiles (QSTileItemView / QSCardItemView): the circle shows the
 * tile's state and icon, a tap is forwarded to the real tile, so the real toggle code runs. The real tiles that
 * are shown in the card are hidden in the normal tile grid. Chosen tiles are kept in System UI's own preferences.
 * Every step is wrapped in try/catch: when something does not match, the card simply does nothing.
 */
final class TileCard {
    static final String SP_NAME = "dynamicpill_cc_tiles", SP_KEY = "specs";
    private static final String DEFAULT_SPECS = "cell,wifi,airplane";

    private static final ArrayList<WeakReference<View>> TILES = new ArrayList<>();
    private static final WeakHashMap<View, Card> CARDS = new WeakHashMap<>();
    private static final WeakHashMap<View, Integer> HIDDEN = new WeakHashMap<>();

    private TileCard() { }

    // ---------------------------------------------------------------- registration (from MainHook)

    static void registerTile(View v) {
        try {
            synchronized (TILES) {
                for (int i = TILES.size() - 1; i >= 0; i--) {
                    View o = TILES.get(i).get();
                    if (o == null) TILES.remove(i);
                    else if (o == v) return;
                }
                TILES.add(new WeakReference<>(v));
            }
        } catch (Throwable ignored) { }
    }

    static void registerPanel(final View p) {
        try {
            if (!(p instanceof ViewGroup) || !ControlCenterSize.tileCardOn()) return;
            p.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (CARDS.containsKey(p) || !ControlCenterSize.tileCardOn()) return;
                        Card c = new Card(p.getContext(), (ViewGroup) p);
                        CARDS.put(p, c);
                        ((ViewGroup) p).addView(c, new ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    } catch (Throwable t) {
                        XposedBridge.log("DynamicPill: tile card failed: " + t);
                    }
                }
            });
        } catch (Throwable ignored) { }
    }

    // ---------------------------------------------------------------- reading a real tile

    static String specOf(View v) {
        try {
            Object st = XposedHelpers.getObjectField(v, "state");
            if (st == null) return null;
            Object sp = XposedHelpers.getObjectField(st, "spec");
            return sp instanceof String ? (String) sp : null;
        } catch (Throwable t) { return null; }
    }

    private static Object stateOf(View v) {
        try { return XposedHelpers.getObjectField(v, "state"); } catch (Throwable t) { return null; }
    }

    private static ArrayList<View> liveTiles() {
        ArrayList<View> out = new ArrayList<>();
        synchronized (TILES) {
            for (int i = TILES.size() - 1; i >= 0; i--) {
                View v = TILES.get(i).get();
                if (v == null) TILES.remove(i);
                else out.add(v);
            }
        }
        return out;
    }

    /** The attached real tile for a spec (an attached one is preferred). */
    private static View tileFor(String spec) {
        View fallback = null;
        for (View v : liveTiles()) {
            if (!spec.equals(specOf(v))) continue;
            if (v.isAttachedToWindow()) return v;
            if (fallback == null) fallback = v;
        }
        return fallback;
    }

    // ---------------------------------------------------------------- the card

    private static final class Card extends FrameLayout {
        private final ViewGroup panel;
        private final ArrayList<ImageView> circles = new ArrayList<>();
        private final String[] circleSpec = new String[4];
        private final String[] circleKey = new String[4];
        private final TextView plus;
        private final ScrollView pickerScroll;
        private final LinearLayout pickerList;
        private boolean picking = false;
        private final WeakHashMap<View, Integer> panelHidden = new WeakHashMap<>();
        private final Runnable tickR = new Runnable() { @Override public void run() { tick(); } };

        Card(Context c, ViewGroup panel) {
            super(c);
            this.panel = panel;
            setClipChildren(false);
            for (int i = 0; i < 4; i++) {
                final int idx = i;
                ImageView iv = new ImageView(c);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int pd = dpi(15);
                iv.setPadding(pd, pd, pd, pd);
                iv.setVisibility(GONE);
                iv.setOnClickListener(new OnClickListener() {
                    @Override public void onClick(View v) { forward(idx, false); }
                });
                iv.setOnLongClickListener(new OnLongClickListener() {
                    @Override public boolean onLongClick(View v) { return forward(idx, true); }
                });
                circles.add(iv);
                addView(iv);
            }
            plus = new TextView(c);
            plus.setText("+");
            plus.setTextColor(Color.WHITE);
            plus.setTextSize(18);
            plus.setGravity(Gravity.CENTER);
            plus.setBackground(oval(0x66808080));
            plus.setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) { picking = true; rebuildPicker(); }
            });
            addView(plus);

            pickerList = new LinearLayout(c);
            pickerList.setOrientation(LinearLayout.VERTICAL);
            pickerScroll = new ScrollView(c);
            pickerScroll.addView(pickerList, new ScrollView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            pickerScroll.setVisibility(GONE);
            addView(pickerScroll);
        }

        private int dpi(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

        private GradientDrawable oval(int color) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            return g;
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            removeCallbacks(tickR);
            post(tickR);
        }

        @Override protected void onDetachedFromWindow() {
            removeCallbacks(tickR);
            super.onDetachedFromWindow();
        }

        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l, h = b - t;
            if (picking) {
                pickerScroll.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
                pickerScroll.layout(0, 0, w, h);
                return;
            }
            int pad = dpi(10), strip = dpi(28);
            int gh = h - strip - pad, gw = w - 2 * pad;
            int cell = Math.max(1, Math.min(gw, gh) / 2);
            int d = Math.max(1, Math.round(cell * 0.84f));
            int ox = (w - 2 * cell) / 2, oy = pad + (gh - 2 * cell) / 2;
            for (int i = 0; i < 4; i++) {
                ImageView iv = circles.get(i);
                int cx = ox + (i % 2) * cell + cell / 2, cy = oy + (i / 2) * cell + cell / 2;
                iv.measure(MeasureSpec.makeMeasureSpec(d, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(d, MeasureSpec.EXACTLY));
                iv.layout(cx - d / 2, cy - d / 2, cx + d / 2, cy + d / 2);
            }
            int ps = dpi(24);
            plus.measure(MeasureSpec.makeMeasureSpec(ps, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ps, MeasureSpec.EXACTLY));
            plus.layout((w - ps) / 2, h - pad / 2 - ps, (w + ps) / 2, h - pad / 2);
        }

        // ---- chosen tiles (kept in System UI's own preferences)

        private SharedPreferences sp() { return getContext().getSharedPreferences(SP_NAME, Context.MODE_PRIVATE); }

        private LinkedHashSet<String> selected() {
            LinkedHashSet<String> s = new LinkedHashSet<>();
            String csv = sp().getString(SP_KEY, null);
            if (csv == null) csv = DEFAULT_SPECS;
            for (String x : csv.split(",")) if (x.trim().length() > 0) s.add(x.trim());
            return s;
        }

        private void saveSelected(LinkedHashSet<String> s) {
            StringBuilder sb = new StringBuilder();
            for (String x : s) { if (sb.length() > 0) sb.append(','); sb.append(x); }
            sp().edit().putString(SP_KEY, sb.toString()).apply();
        }

        // ---- picker (inline, inside the card)

        private void rebuildPicker() {
            pickerList.removeAllViews();
            final LinkedHashSet<String> sel = selected();
            TextView done = row("Done", true, false);
            done.setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) { picking = false; pickerScroll.setVisibility(GONE); tick(); requestLayout(); }
            });
            pickerList.addView(done);
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            for (View tv : liveTiles()) {
                final String spec = specOf(tv);
                if (spec == null || !seen.add(spec)) continue;
                CharSequence label = null;
                try { Object st = stateOf(tv); if (st != null) label = (CharSequence) XposedHelpers.getObjectField(st, "label"); }
                catch (Throwable ignored) { }
                String name = label != null && label.length() > 0 ? label.toString() : spec;
                final TextView r = row((sel.contains(spec) ? "\u2713  " : "     ") + name, false, sel.contains(spec));
                r.setOnClickListener(new OnClickListener() {
                    @Override public void onClick(View v) {
                        LinkedHashSet<String> s = selected();
                        if (!s.remove(spec)) s.add(spec);
                        saveSelected(s);
                        rebuildPicker();
                    }
                });
                pickerList.addView(r);
            }
            pickerScroll.setVisibility(VISIBLE);
            for (ImageView iv : circles) iv.setVisibility(GONE);
            plus.setVisibility(GONE);
            requestLayout();
        }

        private TextView row(String text, boolean bold, boolean on) {
            TextView t = new TextView(getContext());
            t.setText(text);
            t.setTextSize(13);
            t.setSingleLine(true);
            t.setTextColor(bold ? 0xFF3D8BFF : (on ? Color.WHITE : 0xFFB0B0B0));
            t.setPadding(dpi(12), dpi(7), dpi(12), dpi(7));
            return t;
        }

        // ---- forwarding taps to the real tile

        private boolean forward(int idx, boolean longClick) {
            try {
                String spec = circleSpec[idx];
                if (spec == null) return false;
                View real = tileFor(spec);
                if (real == null) return false;
                return longClick ? real.performLongClick() : real.performClick();
            } catch (Throwable t) { return false; }
        }

        // ---- periodic refresh while the Control Center is shown

        private void tick() {
            try {
                if (!isAttachedToWindow()) return;
                boolean on = ControlCenterSize.tileCardOn();
                if (!on) {
                    setVisibility(GONE);
                    restoreAll();
                    postDelayed(tickR, 1500);
                    return;
                }
                setVisibility(VISIBLE);
                hidePanelChildren();
                if (!picking) {
                    pickerScroll.setVisibility(GONE);
                    plus.setVisibility(VISIBLE);
                    update();
                }
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: tile card tick failed: " + t);
            }
            try { postDelayed(tickR, 350); } catch (Throwable ignored) { }
        }

        private void hidePanelChildren() {
            for (int i = 0; i < panel.getChildCount(); i++) {
                View c = panel.getChildAt(i);
                if (c == this) continue;
                if (!panelHidden.containsKey(c)) panelHidden.put(c, c.getVisibility());
                if (c.getVisibility() != GONE) c.setVisibility(GONE);
            }
        }

        private void update() {
            LinkedHashSet<String> sel = selected();
            LinkedHashSet<String> shown = new LinkedHashSet<>();
            int n = 0;
            for (String spec : sel) {
                if (n >= 4) break;
                View real = tileFor(spec);
                if (real == null) continue;
                ImageView iv = circles.get(n);
                circleSpec[n] = spec;
                shown.add(spec);
                paint(n, iv, real);
                n++;
            }
            for (int i = n; i < 4; i++) { circleSpec[i] = null; circleKey[i] = null; circles.get(i).setVisibility(GONE); }
            // real tiles that live in the card are hidden in the normal grid
            for (View v : liveTiles()) {
                String spec = specOf(v);
                if (spec != null && shown.contains(spec)) {
                    if (!HIDDEN.containsKey(v)) HIDDEN.put(v, v.getVisibility());
                    if (v.getVisibility() != GONE) v.setVisibility(GONE);
                } else if (HIDDEN.containsKey(v)) {
                    Integer old = HIDDEN.remove(v);
                    v.setVisibility(old == null ? VISIBLE : old);
                }
            }
        }

        private void paint(int n, ImageView iv, View real) {
            Object st = stateOf(real);
            if (st == null) return;
            int state = 0;
            try { state = XposedHelpers.getIntField(st, "state"); } catch (Throwable ignored) { }
            Object iconObj = null;
            try { iconObj = XposedHelpers.getObjectField(st, "icon"); } catch (Throwable ignored) { }
            if (iconObj == null) {
                try {
                    Object sup = XposedHelpers.getObjectField(st, "iconSupplier");
                    if (sup instanceof java.util.function.Supplier) iconObj = ((java.util.function.Supplier<?>) sup).get();
                } catch (Throwable ignored) { }
            }
            String key = state + ":" + System.identityHashCode(iconObj);
            iv.setVisibility(VISIBLE);
            if (key.equals(circleKey[n])) return;
            circleKey[n] = key;
            boolean active = state == 2;
            iv.setBackground(oval(active ? 0xFFF7F4F4 : 0x66808080));
            iv.setAlpha(state == 0 ? 0.4f : 1f);
            Drawable d = null;
            try {
                if (iconObj instanceof Drawable) d = (Drawable) iconObj;
                else if (iconObj != null) d = (Drawable) XposedHelpers.callMethod(iconObj, "getDrawable", getContext());
            } catch (Throwable ignored) { }
            if (d != null) {
                try { d = d.mutate(); d.setTint(active ? 0xFF3D8BFF : Color.WHITE); } catch (Throwable ignored) { }
            }
            iv.setImageDrawable(d);
        }

        private void restoreAll() {
            try {
                for (View v : liveTiles()) {
                    if (HIDDEN.containsKey(v)) { Integer o = HIDDEN.remove(v); v.setVisibility(o == null ? VISIBLE : o); }
                }
                for (View c : new ArrayList<>(panelHidden.keySet())) {
                    Integer o = panelHidden.remove(c);
                    c.setVisibility(o == null ? VISIBLE : o);
                }
            } catch (Throwable ignored) { }
        }
    }
}

package com.dynamicpill.module;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/**
 * Rounded screen corners: a full screen, touch-through overlay that paints only the four corners black
 * (the square minus a quarter circle).  Top and bottom corners have their own radius.
 */
final class CornerView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF oval = new RectF();
    private float top = 0f, bottom = 0f;

    CornerView(Context c) {
        super(c);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        setWillNotDraw(false);
    }

    /** Radii in pixels. */
    void setRadii(float topPx, float bottomPx) {
        topPx = Math.max(0f, topPx);
        bottomPx = Math.max(0f, bottomPx);
        if (topPx == top && bottomPx == bottom) return;
        top = topPx;
        bottom = bottomPx;
        invalidate();
    }

    private void corner(Canvas c, float r) {
        if (r < 0.5f) return;
        path.reset();
        path.moveTo(0f, 0f);
        path.lineTo(r, 0f);
        oval.set(0f, 0f, 2f * r, 2f * r);
        path.arcTo(oval, 270f, -90f);        // quarter circle from the top point round to the left point
        path.close();
        c.drawPath(path, paint);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float maxR = Math.min(w, h) / 2f;
        float t = Math.min(top, maxR), b = Math.min(bottom, maxR);
        c.save(); corner(c, t); c.restore();                                           // top left
        c.save(); c.translate(w, 0f); c.scale(-1f, 1f); corner(c, t); c.restore();     // top right
        c.save(); c.translate(0f, h); c.scale(1f, -1f); corner(c, b); c.restore();     // bottom left
        c.save(); c.translate(w, h); c.scale(-1f, -1f); corner(c, b); c.restore();     // bottom right
    }
}

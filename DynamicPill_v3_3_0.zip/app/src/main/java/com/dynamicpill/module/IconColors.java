package com.dynamicpill.module;

import android.app.Notification;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.service.notification.StatusBarNotification;
import android.view.View;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Colours the small notification icons in the status bar with the colour of their app
 * (WhatsApp = green, Snapchat = yellow ...). Hooks StatusBarIconView.setColorInternal(int):
 * every tint path of that view (dark intensity, animations, shelf) ends there, so the colour
 * is replaced in one place. Only notification icons that the system itself tints are touched
 * (mUseTint == true); system icons (wifi, battery, ...) and icons MIUI replaced with
 * coloured artwork stay as they are.
 */
final class IconColors {
    static final String K_ICON_COLOR = "notif_icon_color";

    private static final int NONE = 1;   // cache marker: "no colour for this app"
    private static final ConcurrentHashMap<String, Integer> CACHE = new ConcurrentHashMap<>();
    private static final HashMap<String, Integer> KNOWN = new HashMap<>();
    private static XSharedPreferences xsp;
    private static long lastCheck = 0;
    private static boolean enabled = true;

    static {
        // exact brand colours; every other app gets the dominant colour of its launcher icon
        KNOWN.put("com.whatsapp", 0xFF25D366);
        KNOWN.put("com.whatsapp.w4b", 0xFF25D366);
        KNOWN.put("com.snapchat.android", 0xFFFFFC00);
        KNOWN.put("org.telegram.messenger", 0xFF2AABEE);
        KNOWN.put("org.thunderdog.challegram", 0xFF2AABEE);
        KNOWN.put("com.instagram.android", 0xFFE1306C);
        KNOWN.put("com.facebook.katana", 0xFF1877F2);
        KNOWN.put("com.facebook.orca", 0xFF0A93FF);
        KNOWN.put("com.facebook.lite", 0xFF1877F2);
        KNOWN.put("com.zhiliaoapp.musically", 0xFFFE2C55);
        KNOWN.put("com.ss.android.ugc.trill", 0xFFFE2C55);
        KNOWN.put("com.google.android.youtube", 0xFFFF2D2D);
        KNOWN.put("com.google.android.gm", 0xFFEA4335);
        KNOWN.put("com.spotify.music", 0xFF1DB954);
        KNOWN.put("com.pinterest", 0xFFE60023);
        KNOWN.put("com.discord", 0xFF5865F2);
        KNOWN.put("com.linkedin.android", 0xFF0A66C2);
        KNOWN.put("com.reddit.frontpage", 0xFFFF4500);
        KNOWN.put("com.google.android.apps.messaging", 0xFF4C8DF6);
        KNOWN.put("com.google.android.dialer", 0xFF4C8DF6);
        KNOWN.put("com.android.vending", 0xFF34A853);
    }

    private IconColors() { }

    static void hook(ClassLoader cl) {
        try {
            xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
            xsp.makeWorldReadable();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: icon colour prefs: " + t);
        }
        final Class<?> iv = XposedHelpers.findClass("com.android.systemui.statusbar.StatusBarIconView", cl);

        // every tint colour of the view passes through here
        XposedHelpers.findAndHookMethod(iv, "setColorInternal", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    int in = (Integer) param.args[0];
                    if (in == 0) return;                                  // 0 = "no tint": leave it
                    int c = colorFor((View) param.thisObject);
                    if (c != 0) param.args[0] = (in & 0xFF000000) | (c & 0x00FFFFFF);   // keep dim / doze alpha
                } catch (Throwable ignored) { }
            }
        });

        // icon or notification changed after the colour was set: apply again
        XC_MethodHook again = new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    Object v = param.thisObject;
                    int cur = XposedHelpers.getIntField(v, "mCurrentSetColor");
                    if (cur != 0 && colorFor((View) v) != 0) XposedHelpers.callMethod(v, "setColorInternal", cur);
                } catch (Throwable ignored) { }
            }
        };
        try {
            XposedHelpers.findAndHookMethod(iv, "set", Class.forName("com.android.internal.statusbar.StatusBarIcon"), again);
        } catch (Throwable t) { XposedBridge.log("DynamicPill: icon set hook: " + t); }
        try {
            XposedHelpers.findAndHookMethod(iv, "setNotification", StatusBarNotification.class, again);
        } catch (Throwable t) { XposedBridge.log("DynamicPill: icon notif hook: " + t); }
    }

    private static boolean on() {
        long now = SystemClock.uptimeMillis();
        if (now - lastCheck > 2000) {
            lastCheck = now;
            try {
                if (xsp != null) {
                    if (xsp.hasFileChanged()) xsp.reload();
                    enabled = xsp.getBoolean(K_ICON_COLOR, true);
                }
            } catch (Throwable ignored) { }
        }
        return enabled;
    }

    /** Colour for this icon view, or 0 = leave it alone. */
    private static int colorFor(View v) {
        if (!on()) return 0;
        StatusBarNotification sbn = (StatusBarNotification) XposedHelpers.getObjectField(v, "mNotification");
        if (sbn == null) return 0;                                         // system icon (wifi, battery ...)
        if (!XposedHelpers.getBooleanField(v, "mUseTint")) return 0;       // MIUI keeps its own coloured artwork
        String pkg = sbn.getPackageName();
        if (pkg == null || "android".equals(pkg) || "com.android.systemui".equals(pkg)) return 0;
        Integer c = CACHE.get(pkg);
        if (c == null) {
            int found = KNOWN.containsKey(pkg) ? KNOWN.get(pkg) : dominant(v.getContext(), pkg);
            c = found == 0 ? NONE : found;
            CACHE.put(pkg, c);
        }
        return c == NONE ? 0 : c;
    }

    /** Most vivid colour of the app's launcher icon, brightened so it reads on a dark status bar. 0 = grey icon. */
    private static int dominant(Context ctx, String pkg) {
        try {
            PackageManager pm = ctx.getPackageManager();
            Drawable d = pm.getApplicationIcon(pkg);
            final int s = 48;
            Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            d.setBounds(0, 0, s, s);
            d.draw(cv);
            float[] hsv = new float[3];
            float[] wsum = new float[36];          // hue buckets of 10 degrees
            float[] sSum = new float[36], vSum = new float[36];
            for (int y = 0; y < s; y++) {
                for (int x = 0; x < s; x++) {
                    int p = b.getPixel(x, y);
                    if (Color.alpha(p) < 200) continue;
                    Color.colorToHSV(p, hsv);
                    if (hsv[1] < 0.35f || hsv[2] < 0.35f) continue;    // skip white, grey, black, dull
                    int k = Math.min(35, (int) (hsv[0] / 10f));
                    float w = hsv[1] * hsv[2];
                    wsum[k] += w; sSum[k] += hsv[1] * w; vSum[k] += hsv[2] * w;
                    // neighbouring buckets share the weight so a hue on a bucket edge is not split away
                }
            }
            b.recycle();
            int best = -1;
            float bw = 0;
            for (int k = 0; k < 36; k++) {
                float w = wsum[k] + 0.5f * (wsum[(k + 1) % 36] + wsum[(k + 35) % 36]);
                if (w > bw) { bw = w; best = k; }
            }
            if (best < 0 || bw < 6f) return 0;                        // mostly grey / white icon: keep white
            float h = best * 10f + 5f;
            float sat = sSum[best] / Math.max(0.0001f, wsum[best]);
            return Color.HSVToColor(new float[]{h, Math.max(0.55f, Math.min(1f, sat)), 1f});
        } catch (Throwable t) {
            return 0;
        }
    }
}

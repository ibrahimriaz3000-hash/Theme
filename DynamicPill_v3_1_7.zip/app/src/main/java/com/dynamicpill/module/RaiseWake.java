package com.dynamicpill.module;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Raise the phone -> the Always-On display shows (an ambient "pulse"), like a pick-up gesture.
 * While the screen is off the module listens to the system's wake-up PICK_UP gesture sensor (one-shot trigger sensor,
 * no polling, no battery drain).  When it fires, System UI's own doze code is asked to pulse the display
 * (DozeTriggers.requestPulse, reason = sensor pick-up).  If that class can not be reached, the standard
 * "com.android.systemui.doze.pulse" broadcast is sent instead.
 * Everything is try / catch protected; lines start with "DP-RAISE" in the LSPosed log.
 */
final class RaiseWake {
    private RaiseWake() { }

    static final String K_RAISE_AOD = "raise_aod";
    private static final int TYPE_PICK_UP = 25;                 // Sensor.TYPE_PICK_UP_GESTURE
    private static final int PULSE_REASON_SENSOR_PICKUP = 3;    // DozeLog.PULSE_REASON_SENSOR_PICKUP

    private static WeakReference<Object> dozeTriggers = new WeakReference<>(null);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static Context ctx;
    private static SensorManager sm;
    private static Sensor pick;
    private static boolean started = false, armed = false;
    private static long lastPulse = 0;

    /** Remember System UI's DozeTriggers instance (it owns the pulse logic). */
    static void hookDoze(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass("com.android.systemui.doze.DozeTriggers", cl);
            XposedBridge.hookAllConstructors(c, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    dozeTriggers = new WeakReference<>(param.thisObject);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DP-RAISE doze hook failed (broadcast fallback is used): " + t);
        }
    }

    static synchronized void start(Context c) {
        if (started) return;
        started = true;
        try {
            ctx = c;
            sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
            if (sm == null) return;
            pick = sm.getDefaultSensor(TYPE_PICK_UP, true);
            if (pick == null) pick = sm.getDefaultSensor(TYPE_PICK_UP);
            if (pick == null) {
                List<Sensor> all = sm.getSensorList(Sensor.TYPE_ALL);
                for (Sensor s : all) {
                    String t = String.valueOf(s.getStringType()).toLowerCase();
                    String n = String.valueOf(s.getName()).toLowerCase();
                    if ((t.contains("pickup") || t.contains("pick_up") || t.contains("lift") || t.contains("raise")
                            || n.contains("pickup") || n.contains("pick up") || n.contains("lift") || n.contains("raise"))
                            && s.getReportingMode() == Sensor.REPORTING_MODE_ONE_SHOT) { pick = s; break; }
                }
            }
            XposedBridge.log("DP-RAISE pick-up sensor: " + (pick == null ? "NONE found" : pick.getName() + " / " + pick.getStringType()));
            if (pick == null) return;
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_SCREEN_OFF);
            f.addAction(Intent.ACTION_SCREEN_ON);
            c.registerReceiver(new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent i) {
                    try {
                        if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) arm(); else disarm();
                    } catch (Throwable ignored) { }
                }
            }, f);
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) arm();
        } catch (Throwable t) {
            XposedBridge.log("DP-RAISE start failed: " + t);
        }
    }

    private static final TriggerEventListener TRIGGER = new TriggerEventListener() {
        @Override
        public void onTrigger(TriggerEvent event) {
            armed = false;                                   // trigger sensors are one-shot
            MAIN.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                        if (pm != null && pm.isInteractive()) return;     // screen already on
                        if (CcBattery.flag(K_RAISE_AOD, true)) pulse();
                        arm();                                           // listen for the next raise
                    } catch (Throwable ignored) { }
                }
            });
        }
    };

    private static void arm() {
        if (armed || pick == null || sm == null) return;
        if (!CcBattery.flag(K_RAISE_AOD, true)) return;
        armed = sm.requestTriggerSensor(TRIGGER, pick);
    }

    private static void disarm() {
        if (!armed || pick == null || sm == null) return;
        try { sm.cancelTriggerSensor(TRIGGER, pick); } catch (Throwable ignored) { }
        armed = false;
    }

    private static void pulse() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastPulse < 1500) return;
        lastPulse = now;
        boolean ok = false;
        Object dt = dozeTriggers.get();
        if (dt != null) {
            for (Method m : dt.getClass().getDeclaredMethods()) {
                if (!m.getName().equals("requestPulse")) continue;
                try {
                    m.setAccessible(true);
                    Class<?>[] pt = m.getParameterTypes();
                    Object[] a = new Object[pt.length];
                    boolean first = true;
                    for (int i = 0; i < pt.length; i++) {
                        Class<?> t = pt[i];
                        if (t == int.class) { a[i] = first ? PULSE_REASON_SENSOR_PICKUP : 0; first = false; }
                        else if (t == boolean.class) a[i] = false;
                        else if (t == long.class) a[i] = 0L;
                        else if (t == float.class) a[i] = 0f;
                        else a[i] = null;
                    }
                    m.invoke(dt, a);
                    ok = true;
                    break;
                } catch (Throwable t) {
                    XposedBridge.log("DP-RAISE requestPulse failed: " + t);
                }
            }
        }
        if (!ok) {
            try { ctx.sendBroadcast(new Intent("com.android.systemui.doze.pulse")); } catch (Throwable ignored) { }
        }
    }
}

package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.PowerManager;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/**
 * Control Center header info line, placed right above the date (left side):
 *     "57% UNTIL 1:30 ●"      (● = green dot, blinks the whole time the Control Center is open)
 * The text is a floating overlay (no layout space, no fade effect): it simply moves / fades together with the
 * header. The battery % next to the battery icon is NOT added by this module any more.
 */
final class CcBattery {
    private CcBattery() { }

    static final String K_CC_BATT = "cc_batt_pct";
    static final String K_CC_SWAP = "cc_swap_carrier";   // carrier name on the left, battery info on the right
    static final String K_CC_HELLO = "cc_hello_header";  // rainbow "hello" where the carrier name was, carrier moves up-left
    private static final int DOT_GREEN = 0xFF8CE600;

    private static XSharedPreferences xsp;

    private static long flagStamp = 0;
    private static boolean fBatt = true, fSwap = true, fHello = true;

    /** Reads the three switches at most every 400 ms (update() runs once per frame, so this must stay cheap). */
    private static void loadFlags() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - flagStamp < 400) return;
        synchronized (CcBattery.class) {
            if (now - flagStamp < 400) return;
            flagStamp = now;
            try {
                if (xsp == null) {
                    xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                    xsp.makeWorldReadable();
                }
                if (xsp.hasFileChanged()) xsp.reload();
                fBatt = xsp.getBoolean(K_CC_BATT, true);
                fSwap = xsp.getBoolean(K_CC_SWAP, true);
                fHello = xsp.getBoolean(K_CC_HELLO, true);
            } catch (Throwable ignored) { }
        }
    }

    static boolean flag(String key, boolean def) {
        loadFlags();
        if (K_CC_BATT.equals(key)) return fBatt;
        if (K_CC_SWAP.equals(key)) return fSwap;
        if (K_CC_HELLO.equals(key)) return fHello;
        return def;
    }

    static boolean enabled() { return flag(K_CC_BATT, true); }

    // ---- "the Control Center header is really on screen" signal, read by PillController (hides the line, keeps pill on top)
    private static volatile float hdrAlpha = 0f;
    private static volatile long hdrStamp = 0L;

    /** 0 = Control Center header not on screen, otherwise its effective opacity (0..1). Fresh within 160 ms. */
    static float headerSignal() {
        return (android.os.SystemClock.uptimeMillis() - hdrStamp < 160L) ? hdrAlpha : 0f;
    }

    private static final java.util.WeakHashMap<View, InfoView> ATTACHED = new java.util.WeakHashMap<>();

    /** The header can contain more than one BatteryMeterView; only ONE InfoView may draw the line / hello and move the
     *  carrier name, otherwise two overlays fight over the same view (double text, flicker). */
    private static InfoView owner;

    /** Called for every BatteryMeterView that attaches; does nothing outside the Control Center. */
    static void attach(View battery, boolean inControlCenter) {
        try {
            if (!inControlCenter) return;
            ViewGroup host = MainHook.ccRoot(battery);
            if (host == null) {
                XposedBridge.log("DynamicPill: CC root not found, skipped");
                return;
            }
            InfoView old = ATTACHED.get(battery);
            if (old != null) {
                if (old.host == host && old.getParent() != null) return;
                old.dispose();
            }
            final InfoView v = new InfoView(battery.getContext(), battery, host);
            host.getOverlay().add(v);
            ATTACHED.put(battery, v);
            battery.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override public void onViewAttachedToWindow(View x) { }
                @Override public void onViewDetachedFromWindow(View x) {
                    try {
                        x.removeOnAttachStateChangeListener(this);
                        v.dispose();
                        if (ATTACHED.get(x) == v) ATTACHED.remove(x);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CC info attach failed: " + t);
        }
    }

    static final class InfoView extends View {
        final ViewGroup host;
        private final View battery;
        private final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dotP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float dp;
        private final int[] loc = new int[2];
        private final int[] hloc = new int[2];

        private String text = "";
        private float blink = 1f;
        private boolean dotLeft = false;          // swap layout: the dot sits before the % (percentage side), not past the right edge
        private ValueAnimator blinkAnim;
        private View anchor;                  // the date text view
        private View carrier;                 // the carrier name (ZONG): the info line sits on its row
        private View movedCarrier;                // carrier view we shifted to the left (restored when not needed)
        private float sysTy = 0f;                 // the carrier's own vertical translation (the system animates it)
        private float lastSetTy = Float.NaN;      // the value we last wrote, to tell our write from the system's
        private HelloMark mark;                   // the rainbow "hello"
        private boolean markAdded = false;
        private long lastFindCarrier = 0;
        private final int[] cloc = new int[2];
        private final int[] aloc = new int[2];
        private float gapStable = Float.NaN;      // how far the carrier + info line are moved down towards the date
        private int lastAy = Integer.MIN_VALUE;
        private float lastBaseY = Float.NaN;
        private int lastPosKey = Integer.MIN_VALUE;
        private long lastMoveAt = 0;
        private int aloc0 = 0;                    // date view y on screen (movement detector)
        private long lastFind = 0;
        private float lastSize = -1f;
        private int lastL = Integer.MIN_VALUE, lastT = Integer.MIN_VALUE, lastW = -1, lastH = -1;
        private boolean registered = false;
        private boolean stale = false;            // battery changed while the panel was closed
        private final Runnable lateRefresh = new Runnable() { @Override public void run() { refresh(); } };
        private android.view.ViewTreeObserver obs;

        // ---- battery state / estimate
        private int level = -1;
        private boolean charging = false;
        private final ArrayDeque<long[]> samples = new ArrayDeque<>();   // {time, level} while discharging
        private double emaCurrent = -1;                                  // smoothed |current_now| in uA
        private int emaCount = 0;

        private final BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                read(i);
                if (battery.isShown()) refresh(); else stale = true;
            }
        };

        private final android.view.ViewTreeObserver.OnPreDrawListener pre =
                new android.view.ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() { update(); return true; }
        };

        private final android.database.ContentObserver styleObs =
                new android.database.ContentObserver(new android.os.Handler(android.os.Looper.getMainLooper())) {
            @Override
            public void onChange(boolean selfChange) { refresh(); }
        };

        // reports every 40 ms whether the Control Center header is really visible (any way it was opened)
        private final android.graphics.Rect vr = new android.graphics.Rect();
        private final Runnable sig = new Runnable() {
            @Override
            public void run() {
                try {
                    float a = 0f;
                    if (battery.isShown() && battery.getWidth() > 0 && battery.getWindowVisibility() == View.VISIBLE) {
                        battery.getLocationOnScreen(loc);
                        int sh = battery.getResources().getDisplayMetrics().heightPixels;
                        if (loc[1] >= 0 && loc[1] < sh / 2 && battery.getGlobalVisibleRect(vr)) a = effAlpha(battery);
                    }
                    if (a > 0.05f) { hdrAlpha = Math.min(1f, a); hdrStamp = android.os.SystemClock.uptimeMillis(); }
                } catch (Throwable ignored) { }
                if (isAttachedToWindow()) postDelayed(this, battery.isShown() ? 40 : 300);
            }
        };

        private float effAlpha(View v) {
            float a = 1f;
            View c = v;
            for (int i = 0; i < 16 && c != null; i++) {
                a *= c.getAlpha();
                c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
            }
            return a;
        }

        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                try {
                    if (battery.isShown()) refresh();
                    else stopBlink();
                } catch (Throwable ignored) { }
                if (isAttachedToWindow()) postDelayed(this, battery.isShown() ? 15000 : 1500);
            }
        };

        InfoView(Context ctx, View battery, ViewGroup host) {
            super(ctx);
            this.battery = battery;
            this.host = host;
            dp = ctx.getResources().getDisplayMetrics().density;
            textP.setColor(Color.WHITE);
            textP.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 14,
                    ctx.getResources().getDisplayMetrics()));
            textP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            dotP.setColor(DOT_GREEN);
            setVisibility(View.GONE);
        }

        /** True when this view is the one that draws. Another one takes over only when the owner's header is gone. */
        private boolean claim() {
            InfoView o = owner;
            if (o == this) return true;
            if (o == null || !o.isAttachedToWindow() || !o.battery.isShown()) {
                if (o != null) { o.restoreCarrier(); if (o.getVisibility() != View.GONE) o.setVisibility(View.GONE); }
                owner = this;
                return true;
            }
            return false;
        }

        /** Not the owner: draw nothing, touch nothing. */
        private void hideSoft() {
            if (getVisibility() != View.GONE) setVisibility(View.GONE);
            if (mark != null) mark.setAlpha(0);
            stopBlink();
        }

        void dispose() {
            if (owner == this) owner = null;
            try { removeCallbacks(loop); removeCallbacks(sig); } catch (Throwable ignored) { }
            stopBlink();
            restoreCarrier();
            try { if (mark != null) host.getOverlay().remove(mark); } catch (Throwable ignored) { }
            markAdded = false;
            try { host.getOverlay().remove(this); } catch (Throwable ignored) { }
        }

        // ------------------------------------------------------------------ battery estimate

        private void read(Intent i) {
            if (i == null) return;
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int pl = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING
                    || st == BatteryManager.BATTERY_STATUS_FULL || pl > 0;
            if (ch != charging) { samples.clear(); emaCurrent = -1; emaCount = 0; }
            charging = ch;
            if (!charging && level >= 0) {
                long now = System.currentTimeMillis();
                long[] last = samples.peekLast();
                if (last == null || last[1] != level) samples.addLast(new long[]{now, level});
                while (!samples.isEmpty() && now - samples.peekFirst()[0] > 3L * 3600000L) samples.pollFirst();
            }
        }

        /** Best estimate of the remaining runtime (ms) while discharging, or -1. */
        private long dischargeMs(BatteryManager bm) {
            long ms = -1;
            // 1) the system's own prediction (same engine as the system battery screen), Android 12+
            try {
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
                    java.time.Duration d = pm.getBatteryDischargePrediction();
                    if (d != null) ms = d.toMillis();
                }
            } catch (Throwable ignored) { }
            if (ok(ms)) return ms;
            // 2) remaining charge / smoothed current draw
            try {
                long cur = Math.abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW));
                long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
                if (cur > 0) {
                    emaCurrent = emaCurrent < 0 ? cur : emaCurrent * 0.8 + cur * 0.2;
                    emaCount++;
                }
                if (emaCount >= 3 && cc > 0 && emaCurrent > 0) ms = (long) (cc / emaCurrent * 3600000.0);
            } catch (Throwable ignored) { }
            if (ok(ms)) return ms;
            // 3) observed % drop rate
            try {
                long[] first = samples.peekFirst();
                long now = System.currentTimeMillis();
                if (first != null && level > 0 && now - first[0] >= 15 * 60000L && first[1] > level) {
                    double perMs = (first[1] - level) / (double) (now - first[0]);
                    ms = (long) (level / perMs);
                }
            } catch (Throwable ignored) { }
            return ok(ms) ? ms : -1;
        }

        private boolean ok(long ms) { return ms >= 60000L && ms <= 200L * 3600000L; }

        private String clock(long atMs) {
            String s = new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(atMs));
            Calendar a = Calendar.getInstance(), b = Calendar.getInstance();
            b.setTimeInMillis(atMs);
            if (a.get(Calendar.DAY_OF_YEAR) != b.get(Calendar.DAY_OF_YEAR) || a.get(Calendar.YEAR) != b.get(Calendar.YEAR))
                s += " " + new SimpleDateFormat("EEE", Locale.getDefault()).format(new Date(atMs));
            return s;
        }

        /**
         * System "Battery indicator" (Settings -> Notifications & status bar):
         * 0 = icon only, 1 = number inside the icon, 2 = number next to the icon.
         */
        private int indicatorStyle() {
            int style = -1;
            try {
                style = android.provider.Settings.System.getInt(getContext().getContentResolver(),
                        "battery_indicator_style", -1);
            } catch (Throwable ignored) { }
            if (style >= 0) return style;
            try {
                return android.provider.Settings.System.getInt(getContext().getContentResolver(),
                        "status_bar_show_battery_percent", 0) == 1 ? 2 : 0;
            } catch (Throwable t) {
                return 0;
            }
        }

        private void refresh() {
            try {
                if (level < 0) return;
                BatteryManager bm = (BatteryManager) getContext().getSystemService(Context.BATTERY_SERVICE);
                // style 0 (icon only): the % is nowhere else, so it is part of this line.
                // style 1 / 2 (% inside / next to the icon): the system already shows it, so only "UNTIL <time>".
                boolean withPct = indicatorStyle() == 0;
                String pct = withPct ? level + "%" : "";
                String part;                       // e.g. "UNTIL 1:30 PM" / "FULL AT 2:15 PM" / ""
                if (charging) {
                    if (level >= 100) part = "CHARGED";
                    else {
                        long ms = -1;
                        try { ms = bm.computeChargeTimeRemaining(); } catch (Throwable ignored) { }
                        part = ok(ms) ? "FULL AT " + clock(System.currentTimeMillis() + ms) : "";
                    }
                } else {
                    long ms = dischargeMs(bm);
                    part = ms > 0 ? "UNTIL " + clock(System.currentTimeMillis() + ms) : "";
                }
                String t = (pct + (pct.isEmpty() || part.isEmpty() ? "" : " ") + part).toUpperCase(Locale.getDefault());
                if (!t.equals(text)) { text = t; lastW = -1; }
            } catch (Throwable ignored) { }
        }

        // ------------------------------------------------------------------ finding the date view

        private String idName(View v) {
            try {
                if (v.getId() != View.NO_ID) return v.getResources().getResourceEntryName(v.getId()).toLowerCase();
            } catch (Throwable ignored) { }
            return "";
        }

        private void scanDate(View v, int battTop, View[] best, int[] cnt, boolean strict) {
            if (best[0] != null || cnt[0]++ > 4000 || v == this) return;
            if (v instanceof TextView && v.isShown() && v.getWidth() > 0) {
                CharSequence t = ((TextView) v).getText();
                if (t != null && t.length() > 0) {
                    String cn = v.getClass().getName().toLowerCase(), id = idName(v);
                    boolean byName = (cn.contains("date") || id.contains("date")) && !cn.contains("update");
                    boolean byShape = false;
                    if (!strict) {
                        String s = t.toString();
                        boolean dg = false, lt = false;
                        for (int i = 0; i < s.length(); i++) {
                            if (Character.isDigit(s.charAt(i))) dg = true;
                            else if (Character.isLetter(s.charAt(i))) lt = true;
                        }
                        v.getLocationOnScreen(hloc);
                        byShape = dg && lt && !s.contains("%") && Math.abs(hloc[1] - battTop) < 60 * dp
                                && hloc[0] < battTop + 10000 && hloc[0] + v.getWidth() < loc[0] + 4;
                    }
                    if (byName || byShape) { best[0] = v; return; }
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    scanDate(g.getChildAt(i), battTop, best, cnt, strict);
                    if (best[0] != null) return;
                }
            }
        }

        private void findAnchor() {
            long now = android.os.SystemClock.uptimeMillis();
            if (anchor != null && anchor.isShown()) return;
            if (now - lastFind < 500) return;
            lastFind = now;
            anchor = null;
            try {
                battery.getLocationOnScreen(loc);
                int battTop = loc[1];
                View[] best = new View[1];
                scanDate(host, battTop, best, new int[]{0}, true);
                if (best[0] == null) scanDate(host, battTop, best, new int[]{0}, false);
                anchor = best[0];
            } catch (Throwable ignored) { }
        }

        private void scanCarrier(View v, int dateTop, int hostW, View[] best, int[] cnt, boolean strict) {
            if (best[0] != null || cnt[0]++ > 4000 || v == this || v == anchor) return;
            if (v instanceof TextView && v.isShown() && v.getWidth() > 0) {
                CharSequence t = ((TextView) v).getText();
                if (t != null && t.length() > 0) {
                    String cn = v.getClass().getName().toLowerCase(), id = idName(v);
                    boolean byName = cn.contains("carrier") || id.contains("carrier");
                    boolean byShape = false;
                    if (!strict && !byName) {
                        String s = t.toString().trim();
                        boolean letters = s.length() > 0 && s.length() <= 24;
                        for (int i = 0; i < s.length() && letters; i++) {
                            char ch = s.charAt(i);
                            if (!(Character.isLetter(ch) || ch == ' ' || ch == '-' || ch == '.')) letters = false;
                        }
                        v.getLocationOnScreen(cloc);
                        byShape = letters && cloc[0] + v.getWidth() / 2 > hostW / 2
                                && cloc[1] < dateTop + 10 * dp && cloc[1] > dateTop - 90 * dp;
                    }
                    if (byName || byShape) { best[0] = v; return; }
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    scanCarrier(g.getChildAt(i), dateTop, hostW, best, cnt, strict);
                    if (best[0] != null) return;
                }
            }
        }

        private void findCarrier() {
            long now = android.os.SystemClock.uptimeMillis();
            if (carrier != null && carrier.isShown()) return;
            if (now - lastFindCarrier < 500) return;
            lastFindCarrier = now;
            carrier = null;
            try {
                if (anchor == null) return;
                int[] dl = new int[2];
                anchor.getLocationOnScreen(dl);
                View[] best = new View[1];
                int hostW = host.getWidth();
                scanCarrier(host, dl[1], hostW, best, new int[]{0}, true);
                if (best[0] == null) scanCarrier(host, dl[1], hostW, best, new int[]{0}, false);
                carrier = best[0];
            } catch (Throwable ignored) { }
        }

        /** Puts the carrier view back where the system wants it. */
        private void restoreCarrier() {
            try {
                if (movedCarrier != null) {
                    movedCarrier.setTranslationX(0f);
                    if (movedCarrier.getTranslationY() == lastSetTy) movedCarrier.setTranslationY(sysTy);   // give the system's value back
                    movedCarrier = null;
                    lastSetTy = Float.NaN;
                    sysTy = 0f;
                }
                if (mark != null) mark.setAlpha(0);
            } catch (Throwable ignored) { }
        }

        private float relAlpha(View v) {
            float a = 1f;
            View c = v;
            for (int i = 0; i < 16 && c != null && c != host; i++) {
                a *= c.getAlpha();
                c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
            }
            return a;
        }

        // ------------------------------------------------------------------ layout every frame

        private void update() {
            try {
                if (!enabled() || !battery.isShown() || text.isEmpty()) { hideNow(); return; }
                if (!claim()) { hideSoft(); return; }
                if (stale) { stale = false; post(lateRefresh); }      // after this frame, so the pull never waits for it
                findAnchor();
                findCarrier();
                float a;
                int left, bottom;
                float gapDown = 0f;
                host.getLocationOnScreen(hloc);
                int hx = hloc[0], hy = hloc[1];
                if (anchor != null && anchor.isShown()) {
                    a = relAlpha(anchor);
                    anchor.getLocationOnScreen(loc);
                    aloc0 = loc[1];
                    left = loc[0];
                    bottom = loc[1] - Math.round(dp * 2f);
                    float sz = ((TextView) anchor).getTextSize();
                    if (sz != lastSize) {
                        lastSize = sz;
                        textP.setTextSize(sz);
                        try { textP.setTypeface(((TextView) anchor).getTypeface()); } catch (Throwable ignored) { }
                        lastW = -1;
                    }
                } else {
                    a = relAlpha(battery);
                    battery.getLocationOnScreen(loc);
                    left = Math.round(dp * 24f);
                    bottom = loc[1] - Math.round(dp * 24f);
                }
                if (a < 0.02f) { hideNow(); return; }
                Paint.FontMetrics fm = textP.getFontMetrics();
                int th = (int) Math.ceil(fm.descent - fm.ascent);
                // same row as the carrier name (ZONG): put our text baseline on the carrier's baseline
                if (anchor != null && carrier != null && carrier.isShown() && carrier != anchor) {
                    carrier.getLocationOnScreen(cloc);
                    float ourOff = 0f;                                              // our own shift up, without the system's
                    if (movedCarrier == carrier && !Float.isNaN(lastSetTy) && carrier.getTranslationY() == lastSetTy)
                        ourOff = lastSetTy - sysTy;
                    cloc[1] -= Math.round(ourOff);
                    int cb = carrier instanceof TextView ? ((TextView) carrier).getBaseline() : -1;
                    float baseY = cb > 0 ? cloc[1] + cb : cloc[1] + carrier.getHeight() / 2f + (-fm.ascent - fm.descent) / 2f;
                    // close the gap between the info line and the date: same row pitch as ZONG -> info line.
                    // Measured only while the header stands still (no jitter while it animates), then kept.
                    anchor.getLocationOnScreen(aloc);
                    int ab = anchor instanceof TextView ? ((TextView) anchor).getBaseline() : -1;
                    float dateBase = ab > 0 ? aloc[1] + ab : aloc[1] + anchor.getHeight() * 0.75f;
                    boolean still = Math.abs(aloc[1] - lastAy) <= 1 && !Float.isNaN(lastBaseY) && Math.abs(baseY - lastBaseY) <= 1f;
                    lastAy = aloc[1];
                    lastBaseY = baseY;
                    if ((a >= 0.97f && still) || (Float.isNaN(gapStable) && a >= 0.97f)) {
                        float pitch = dateBase - baseY;
                        gapStable = Math.max(0f, Math.min(dp * 16f, pitch - th * 1.12f));
                    }
                    gapDown = Float.isNaN(gapStable) ? 0f : gapStable;
                    bottom = Math.round(baseY + fm.descent + gapDown);
                }
                float tw = textP.measureText(text);
                float r = th * 0.13f, gap = th * 0.35f;
                int w = (int) Math.ceil(tw + gap + r * 2f) + 2;
                boolean helloMode = flag(K_CC_HELLO, true);
                boolean carrierOk = anchor != null && carrier instanceof TextView && carrier.isShown() && carrier != anchor;
                float markEdge = Float.NaN;
                boolean markLeft = false;
                final int dateLeft = left;
                final boolean mirror = helloMode && flag(K_CC_SWAP, true);   // swap on: ZONG + info right, hello left
                // hello mode: the carrier name (ZONG) moves up-left above the info line and the rainbow "hello" takes its
                // old place on the right.  Swap mode (old): carrier to the left, info line to the right.
                if (carrierOk && (helloMode || flag(K_CC_SWAP, true))) {
                    TextView ct = (TextView) carrier;
                    ct.getLocationOnScreen(cloc);
                    float tx = ct.getTranslationX();
                    float x0, x1;
                    android.text.Layout lay = ct.getLayout();
                    if (lay != null && lay.getLineCount() > 0) {
                        float base = cloc[0] + ct.getCompoundPaddingLeft() - ct.getScrollX();
                        x0 = base + lay.getLineLeft(0);
                        x1 = base + lay.getLineRight(0);
                    } else {
                        x0 = cloc[0] + ct.getPaddingLeft();
                        x1 = cloc[0] + ct.getWidth() - ct.getPaddingRight();
                    }
                    x0 -= tx;           // position without our own shift
                    x1 -= tx;
                    float dx = mirror ? 0f : left - x0;          // mirror: ZONG stays on its own right-hand place
                    if (movedCarrier != ct) {
                        restoreCarrier();
                        movedCarrier = ct;
                        android.view.ViewParent pp = ct.getParent();      // let it draw outside its own box
                        for (int i = 0; i < 6 && pp instanceof ViewGroup; i++) {
                            ((ViewGroup) pp).setClipChildren(false);
                            ((ViewGroup) pp).setClipToPadding(false);
                            pp = pp.getParent();
                        }
                    }
                    if (Math.abs(ct.getTranslationX() - dx) > 0.5f) ct.setTranslationX(dx);
                    // vertical: ADD our shift to whatever the system animates (writing an absolute value fought the
                    // header animation every frame = flicker)
                    float cur = ct.getTranslationY();
                    if (Float.isNaN(lastSetTy) || cur != lastSetTy) sysTy = cur;   // the system moved it: that is the new base
                    float want = sysTy + gapDown + (helloMode ? -th * 1.08f : 0f);
                    if (cur != want) ct.setTranslationY(want);
                    lastSetTy = want;
                    if (mirror) {
                        left = Math.round(x1) - w;                     // info line ends where ZONG ends (right side)
                        markEdge = dateLeft; markLeft = true;          // hello on the left, where the date starts
                    } else if (helloMode) markEdge = x1;               // info line stays on the left, hello ends where ZONG ended
                    else left = Math.round(x1) - w;                    // info line ends where the carrier used to end
                } else {
                    restoreCarrier();                                  // carrier not found: no hello (it would sit on top of the name)
                }
                boolean dl = mirror && carrierOk;
                if (dl != dotLeft) { dotLeft = dl; invalidate(); }
                updateMark(helloMode && !Float.isNaN(markEdge), markEdge, markLeft, bottom - fm.descent, th, a, hx, hy);
                int l = left - hx, t = bottom - th - hy;
                if (l != lastL || t != lastT || w != lastW || th != lastH) {
                    lastL = l; lastT = t; lastW = w; lastH = th;
                    layout(l, t, l + w, t + th);
                }
                if (getVisibility() != View.VISIBLE) setVisibility(View.VISIBLE);
                if (getAlpha() != a) setAlpha(a);
                long nowMs = android.os.SystemClock.uptimeMillis();
                int posKey = (anchor != null && anchor.isShown()) ? aloc0 : Integer.MIN_VALUE + 1;
                if (posKey != lastPosKey || a < 0.97f) { lastPosKey = posKey; lastMoveAt = nowMs; }
                if (nowMs - lastMoveAt > 140) startBlink();
                else if (blinkAnim != null) { stopBlink(); blink = 1f; invalidate(); }
            } catch (Throwable ignored) { }
        }

        /** Places the rainbow "hello" on the row of the info line, right aligned to markRight (screen x). */
        private void updateMark(boolean show, float edge, boolean onLeft, float baseline, int th, float a, int hx, int hy) {
            if (!show) { if (mark != null) mark.setAlpha(0); return; }
            if (mark == null) mark = new HelloMark();
            if (!markAdded) {
                host.getOverlay().add(mark);
                markAdded = true;
            }
            float ts = textP.getTextSize();
            int hw = Math.round(ts * 5.0f), hh = Math.round(ts * 1.65f);
            // right edge (or left edge when onLeft) of the hello
            int bl = onLeft ? Math.round(edge - hw * 0.03f) - hx : Math.round(edge + ts * 0.25f) - hx - hw;
            // vertically exactly in the middle between the ZONG row and the info line row
            int cy = Math.round(baseline - ts * 0.36f - th * 0.54f) - hy;
            Rect r = mark.getBounds();
            if (r.left != bl || r.top != cy - hh / 2 || r.width() != hw || r.height() != hh) {
                mark.setBounds(bl, cy - hh / 2, bl + hw, cy - hh / 2 + hh);
                mark.invalidateSelf();
            }
            mark.setAlpha(Math.round(255f * Math.max(0f, Math.min(1f, a))));   // fades exactly like the header
        }

        private void hideNow() {
            restoreCarrier();
            if (getVisibility() != View.GONE) setVisibility(View.GONE);
            stopBlink();
        }

        // ------------------------------------------------------------------ green dot blink (all the time while open)

        private void startBlink() {
            if (blinkAnim != null && blinkAnim.isRunning()) return;
            blinkAnim = ValueAnimator.ofFloat(0f, 1f);
            blinkAnim.setDuration(1100);
            blinkAnim.setRepeatCount(ValueAnimator.INFINITE);
            blinkAnim.setInterpolator(new android.view.animation.LinearInterpolator());
            blinkAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator va) {
                    float t = (Float) va.getAnimatedValue();
                    blink = 0.12f + 0.88f * (0.5f + 0.5f * (float) Math.cos(t * 2f * Math.PI));
                    invalidate();
                }
            });
            blinkAnim.start();
        }

        private void stopBlink() {
            if (blinkAnim != null) { blinkAnim.cancel(); blinkAnim = null; }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (text.isEmpty()) return;
            Paint.FontMetrics fm = textP.getFontMetrics();
            float base = -fm.ascent;
            int th = getHeight();
            float r = th * 0.13f, gap = th * 0.35f;
            float tx = dotLeft ? r * 2f + gap : 0f;
            canvas.drawText(text, tx, base, textP);
            float cx = dotLeft ? r : textP.measureText(text) + gap + r;
            // centre the dot on the capital letters, not on the full line box
            float cy = base - (textP.getTextSize() * 0.36f);
            dotP.setAlpha(Math.round(255f * blink));
            canvas.drawCircle(cx, cy, r, dotP);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            try {
                if (!registered) {
                    read(getContext().registerReceiver(rcv, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
                    registered = true;
                }
            } catch (Throwable ignored) { }
            try {
                obs = battery.getViewTreeObserver();
                if (obs.isAlive()) obs.addOnPreDrawListener(pre);
            } catch (Throwable ignored) { }
            try {
                getContext().getContentResolver().registerContentObserver(
                        android.provider.Settings.System.getUriFor("battery_indicator_style"), false, styleObs);
            } catch (Throwable ignored) { }
            refresh();
            removeCallbacks(loop);
            postDelayed(loop, 1500);
            removeCallbacks(sig);
            post(sig);
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            removeCallbacks(loop);
            removeCallbacks(sig);
            stopBlink();
            try { if (obs != null && obs.isAlive()) obs.removeOnPreDrawListener(pre); } catch (Throwable ignored) { }
            obs = null;
            try { getContext().getContentResolver().unregisterContentObserver(styleObs); } catch (Throwable ignored) { }
            try { if (registered) getContext().unregisterReceiver(rcv); } catch (Throwable ignored) { }
            registered = false;
        }
    }
}

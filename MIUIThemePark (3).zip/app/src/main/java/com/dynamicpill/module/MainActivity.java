package com.dynamicpill.module;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** iOS style settings screen. Values are read live by System UI (under a second). */
public class MainActivity extends Activity {
    private static final int BLUE = 0xFF2979FF;
    private static final int GREEN = 0xFF34C759;
    private static final int GRAY = 0xFF8E8E93;
    // light / dark follow the system setting
    private boolean night;
    private int BG, CARD, TEXT, DIVIDER, TRACK;
    private static final int UNIT_MM = 0, UNIT_PCT = 1, UNIT_SEC = 2;

    private SharedPreferences sp;

    // ---- GoodLooks Color Guard (root) ----
    private LockableLayout cgCard;
    private TextView cgNote;
    private final Map<String, CgSlider> cgSliders = new HashMap<>();
    private final Map<String, IosSwitch> cgSwitches = new HashMap<>();

    private static class CgSlider {
        FillSlider bar;
        TextView val;
        float min, step;
        int dec;
    }

    /** Card that ignores all touches while locked (until the root read finished). */
    private static class LockableLayout extends LinearLayout {
        boolean locked;

        LockableLayout(Context c) {
            super(c);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            return locked || super.onInterceptTouchEvent(e);
        }
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        night = (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        BG = night ? 0xFF000000 : 0xFFF2F2F7;
        CARD = night ? 0xFF1C1C1E : 0xFFFFFFFF;
        TEXT = night ? 0xFFFFFFFF : 0xFF000000;
        DIVIDER = night ? 0xFF38383A : 0xFFE5E5EA;
        TRACK = night ? 0xFF363636 : 0xFFE5E5EA;
        try {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_WORLD_READABLE);
        } catch (Throwable t) {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_PRIVATE);
            Toast.makeText(this, "Activate the module in LSPosed first", Toast.LENGTH_LONG).show();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(48), dp(16), dp(32));

        TextView title = new TextView(this);
        title.setText("Dynamic Pill");
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(TEXT);
        title.setPadding(dp(4), 0, 0, dp(4));
        root.addView(title);

        // ---- Pill
        LinearLayout pill = section(root, "PILL");
        switchRow(pill, "Show pill", PillController.K_ENABLED, true);
        switchRow(pill, "Show on lock screen", PillController.K_LOCK, true);
        sliderRow(pill, "Width", PillController.K_WIDTH, PillController.D_WIDTH, 40, 300, 0, UNIT_MM);
        sliderRow(pill, "Height", PillController.K_HEIGHT, PillController.D_HEIGHT, 20, 120, 0, UNIT_MM);
        switchRow(pill, "Auto-center on camera cut-out", PillController.K_AUTOX, true);
        sliderRow(pill, "Horizontal offset", PillController.K_XOFF, PillController.D_XOFF, 0, 300, -150, UNIT_MM);
        sliderRow(pill, "Vertical offset", PillController.K_YOFF, PillController.D_YOFF, 0, 300, -150, UNIT_MM);
        sliderRow(pill, "Opacity", PillController.K_ALPHA, 100, 0, 100, 0, UNIT_PCT);
        sliderRow(pill, "White border (0 = off)", PillController.K_BORDER, 4, 0, 20, 0, UNIT_MM);
        sliderRow(pill, "Corner smoothness (0 = circle)", PillController.K_SMOOTH, 30, 0, 100, 0, UNIT_PCT);

        // ---- Indicators
        LinearLayout ind = section(root, "INDICATORS (INSIDE THE PILL)");
        switchRow(ind, "Yellow dot (always on)", PillController.K_IND_DOT, true);
        switchRow(ind, "Dot turns green in WhatsApp", PillController.K_IND_WA, true);
        switchRow(ind, "Call: green blinking outline (only if call pill is off)", PillController.K_IND_CALL, true);
        switchRow(ind, "Charging: green bolt icon", PillController.K_IND_CHARGE, true);
        switchRow(ind, "Blink dot every 15 s while a notification is waiting", PillController.K_IND_NOTIF, true);

        // ---- Animations (expanding pill)
        LinearLayout an = section(root, "ANIMATIONS (EXPANDING PILL)");
        switchRow(an, "Pill animations (master switch)", PillController.K_ANIM, true);
        switchRow(an, "Charging pill", PillController.K_ANIM_CHARGE, true);
        switchRow(an, "Silent / Vibrate / Ring pill", PillController.K_ANIM_RINGER, true);
        switchRow(an, "Call pill (timer + waveform)", PillController.K_ANIM_CALL, true);
        switchRow(an, "Lock pill (screen wakes locked)", PillController.K_ANIM_LOCK, true);
        switchRow(an, "Unlock pill (open lock + neon ring)", PillController.K_ANIM_UNLOCK, true);
        switchRow(an, "WhatsApp neon outline", PillController.K_WA_NEON, true);
        switchRow(an, "Hide status bar while the pill animates", PillController.K_SB_HIDE, true);
        sliderRow(an, "Expanded width", PillController.K_EXP_W, PillController.D_EXP_W, 100, 400, 0, UNIT_MM);
        sliderRow(an, "Show time", PillController.K_HOLD, PillController.D_HOLD, 10, 60, 0, UNIT_SEC);
        sliderRow(an, "Text size", PillController.K_TXT_PCT, 100, 60, 150, 0, UNIT_PCT);
        sliderRow(an, "Icon size", PillController.K_ICO_PCT, 100, 60, 140, 0, UNIT_PCT);

        LinearLayout pv = section(root, "PREVIEW (TAP TO PLAY ON THE PILL)");
        previewRow(pv, "Charging", "charge");
        previewRow(pv, "Silent", "silent");
        previewRow(pv, "Vibrate", "vibrate");
        previewRow(pv, "Ring", "ring");
        previewRow(pv, "Call", "call");
        previewRow(pv, "Lock", "lock");
        previewRow(pv, "Unlock", "unlock");

        // ---- Line
        LinearLayout line = section(root, "LINE (iOS GRABBER)");
        switchRow(line, "Show line", PillController.K_LINE_ON, true);
        sliderRow(line, "Width", PillController.K_LINE_W, PillController.D_LINE_W, 30, 600, 0, UNIT_MM);
        sliderRow(line, "Thickness", PillController.K_LINE_H, 6, 2, 30, 0, UNIT_MM);
        sliderRow(line, "Center from right edge", PillController.K_LINE_X, PillController.D_LINE_X, 0, 700, 0, UNIT_MM);
        sliderRow(line, "Distance from top", PillController.K_LINE_Y, PillController.D_LINE_Y, 0, 300, 0, UNIT_MM);
        sliderRow(line, "Opacity", PillController.K_LINE_ALPHA, 70, 5, 100, 0, UNIT_PCT);

        // ---- Control Center
        LinearLayout cc = section(root, "CONTROL CENTER");
        switchRow(cc, "Battery % + estimated time in Control Center", CcBattery.K_CC_BATT, true);
        switchRow(cc, "Carrier name left, battery info right (swap)", CcBattery.K_CC_SWAP, true);
        switchRow(cc, "Two page Control Center (swipe left / right)", CcPager.K_PAGER, true);

        // ---- GoodLooks Color Guard (needs root, engine runs as a Magisk/KernelSU module)
        LinearLayout cg = section(root, "GOODLOOKS COLOR GUARD (ROOT)");
        cgCard = (LockableLayout) cg;
        cgCard.locked = true;
        cgCard.setAlpha(0.5f);
        cgSliderRow(cg, "Contrast", "contrast", 1.0f, 8.0f, 0.1f, 2.0f);
        cgSliderRow(cg, "Saturation", "saturation", 1.0f, 8.0f, 0.1f, 1.6f);
        cgSliderRow(cg, "Red", "tint_red", 0.3f, 2.0f, 0.05f, 1.0f);
        cgSliderRow(cg, "Green", "tint_green", 0.3f, 2.0f, 0.05f, 1.0f);
        cgSliderRow(cg, "Blue", "tint_blue", 0.3f, 2.0f, 0.05f, 1.0f);
        cgSwitchRow(cg, "Responsive Mode", "hg_responsive_mode");
        cgSwitchRow(cg, "Dedup Apply", "hg_dedup_apply");
        cgSwitchRow(cg, "SurfaceFlinger Guard", "hg_sf_guard");
        cgSwitchRow(cg, "Adaptive Debounce", "hg_adaptive_debounce");
        cgSwitchRow(cg, "Boost Keepalive (anti-tamper)", "hg_boost_keepalive");
        cgSwitchRow(cg, "Ultimate Black Almond - Auto (dark mode)", "almond_auto");
        cgSliderRow(cg, "Black Almond Intensity", "almond_intensity", 0.0f, 1.0f, 0.05f, 0.60f);

        cgNote = new TextView(this);
        cgNote.setText("Connecting to root...");
        cgNote.setTextSize(12);
        cgNote.setTextColor(GRAY);
        cgNote.setPadding(dp(16), dp(8), dp(16), 0);
        root.addView(cgNote);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);

        ColorGuard.start(this, (values, error) -> {
            if (isFinishing() || isDestroyed()) return;
            if (values == null) {
                cgNote.setText(error == null ? "Root access is required." : error
                        + "\nGrant root to Dynamic Pill in Magisk / KernelSU, then reopen settings.");
                return;
            }
            for (Map.Entry<String, String> e : values.entrySet()) {
                CgSlider cs = cgSliders.get(e.getKey());
                IosSwitch sw = cgSwitches.get(e.getKey());
                try {
                    if (cs != null) {
                        float v = Float.parseFloat(e.getValue());
                        cs.bar.setProgress(Math.round((v - cs.min) / cs.step));
                        cs.val.setText(String.format(Locale.US, "%." + cs.dec + "f", v));
                    } else if (sw != null) {
                        sw.snap("1".equals(e.getValue().trim()));
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            cgCard.locked = false;
            cgCard.setAlpha(1f);
            cgNote.setText("Color Guard engine is active. Changes apply live, no reboot.");
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        ColorGuard.flushNow();
    }

    private void cgSwitchRow(LinearLayout card, String name, final String id) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        IosSwitch sw = new IosSwitch(this, TRACK, GREEN);
        sw.snap(true);
        sw.setListener(on -> ColorGuard.queue(id, on ? "1" : "0"));
        cgSwitches.put(id, sw);
        row.addView(sw);
        card.addView(row);
    }

    /** Decimal slider backed by the module's flag file (value = min + progress * step). */
    private void cgSliderRow(LinearLayout card, String name, final String id,
                             float min, float max, float step, float def) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(this);
        val.setTextSize(15);
        val.setTextColor(GRAY);
        top.addView(val);
        row.addView(top);

        final CgSlider cs = new CgSlider();
        cs.min = min;
        cs.step = step;
        cs.dec = step < 0.1f ? 2 : 1;
        cs.val = val;
        val.setText(String.format(Locale.US, "%." + cs.dec + "f", def));

        final FillSlider bar = new FillSlider(this, TRACK, BLUE);
        bar.setMax(Math.round((max - min) / step));
        bar.setProgress(Math.round((def - min) / step));
        bar.setListener((p, user) -> {
            String v = String.format(Locale.US, "%." + cs.dec + "f", cs.min + p * cs.step);
            val.setText(v);
            if (user) ColorGuard.queue(id, v);
        });
        cs.bar = bar;
        cgSliders.put(id, cs);

        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        blp.topMargin = dp(10);
        blp.bottomMargin = dp(8);
        row.addView(bar, blp);
        card.addView(row);
    }

    private LinearLayout section(LinearLayout root, String name) {
        TextView h = new TextView(this);
        h.setText(name);
        h.setTextSize(12);
        h.setTextColor(GRAY);
        h.setPadding(dp(16), dp(20), 0, dp(6));
        root.addView(h);

        LinearLayout card = new LockableLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(12));
        card.setBackground(g);
        root.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void divider(LinearLayout card) {
        if (card.getChildCount() == 0) return;
        View d = new View(this);
        d.setBackgroundColor(DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.leftMargin = dp(16);
        card.addView(d, lp);
    }

    private void switchRow(LinearLayout card, String name, final String key, boolean def) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        IosSwitch sw = new IosSwitch(this, TRACK, GREEN);
        sw.snap(sp.getBoolean(key, def));
        sw.setListener(on -> sp.edit().putBoolean(key, on).apply());
        row.addView(sw);
        card.addView(row);
    }

    /** value = progress + min + shift; mm sliders store 0.1 mm units. */
    private void sliderRow(LinearLayout card, final String name, final String key, int def,
                           final int min, int max, final int shift, final int unit) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(this);
        val.setTextSize(15);
        val.setTextColor(GRAY);
        top.addView(val);
        row.addView(top);

        int cur = sp.getInt(key, def);
        val.setText(fmt(cur, unit));

        final FillSlider bar = new FillSlider(this, TRACK, BLUE);
        bar.setMax(max - min);
        bar.setProgress(cur - shift - min);
        bar.setListener((p, user) -> {
            int v = p + min + shift;
            val.setText(fmt(v, unit));
            if (user) sp.edit().putInt(key, v).apply();
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        blp.topMargin = dp(10);
        blp.bottomMargin = dp(8);
        row.addView(bar, blp);
        card.addView(row);
    }

    /** Row with a "Play" label: asks the pill (inside System UI) to play one animation right now. */
    private void previewRow(LinearLayout card, String name, final String scene) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView go = new TextView(this);
        go.setText("Play");
        go.setTextSize(16);
        go.setTextColor(BLUE);
        row.addView(go);

        row.setOnClickListener(v -> sp.edit()
                .putString(PillController.K_PREVIEW, scene + ":" + System.currentTimeMillis()).apply());
        card.addView(row);
    }

    private String fmt(int v, int unit) {
        if (unit == UNIT_PCT) return v + " %";
        if (unit == UNIT_SEC) return (v / 10f) + " s";
        return (v / 10f) + " mm";
    }
}

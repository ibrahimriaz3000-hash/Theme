package com.themecompat.fix;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * ThemeCompatFix
 *
 * 1) com.android.thememanager (Themes app, 2.3.1.9-global):
 *    "Compatibility issues" dialog ko skip karta hai aur seedha theme apply karta hai.
 *    - ThemeOperationHandler.L(int)  -> ThemeOperationHandler.E0(int)
 *    - theme.card.helper.h.u(int)    -> theme.card.helper.h.l0(int)
 *
 * 2) miui.content.res.ThemeCompatibility.isCompatibleResource(String) ko hamesha true karta hai.
 *    Ye Themes app aur SystemUI dono mein hook hota hai.
 *    Agar SystemUI mein masla aaye to LSPosed scope se com.android.systemui untick kar do.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[ThemeCompatFix] ";
    private static final String PKG_THEME = "com.android.thememanager";
    private static final String PKG_SYSUI = "com.android.systemui";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        if (PKG_THEME.equals(lpparam.packageName)) {
            hookDialogGate(lpparam,
                    "com.android.thememanager.util.ThemeOperationHandler", "L", "E0");
            hookDialogGate(lpparam,
                    "com.android.thememanager.theme.card.helper.h", "u", "l0");
            hookFrameworkCompat(lpparam);
        } else if (PKG_SYSUI.equals(lpparam.packageName)) {
            hookFrameworkCompat(lpparam);
        }
    }

    /** gate(int) ki jagah seedha continuation(int) chalao, taake dialog show hi na ho. */
    private void hookDialogGate(LoadPackageParam lpparam, String className,
                                final String gate, final String continuation) {
        try {
            Class<?> clazz = XposedHelpers.findClass(className, lpparam.classLoader);
            XposedHelpers.findAndHookMethod(clazz, gate, int.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    XposedHelpers.callMethod(param.thisObject, continuation,
                            new Class<?>[]{int.class}, param.args[0]);
                    return null;
                }
            });
            XposedBridge.log(TAG + "hooked " + className + "." + gate);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "FAILED " + className + "." + gate + " : " + t);
        }
    }

    private void hookFrameworkCompat(LoadPackageParam lpparam) {
        try {
            Class<?> clazz = XposedHelpers.findClassIfExists(
                    "miui.content.res.ThemeCompatibility", lpparam.classLoader);
            if (clazz == null) {
                XposedBridge.log(TAG + "ThemeCompatibility not found in " + lpparam.packageName);
                return;
            }
            int n = XposedBridge.hookAllMethods(clazz, "isCompatibleResource",
                    XC_MethodReplacement.returnConstant(true)).size();
            XposedBridge.log(TAG + "isCompatibleResource hooks in " + lpparam.packageName + ": " + n);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "FAILED framework hook in " + lpparam.packageName + " : " + t);
        }
    }
}

package com.dynamicpill.module;

import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import de.robv.android.xposed.XposedBridge;

import java.lang.reflect.Method;
import java.util.WeakHashMap;

/**
 * "Control Center Scale" (3.4.0): scales the WHOLE tile area of the Control Center (Wi-Fi / mobile data cards,
 * the tile card, the toggle group, both sliders, every icon tile and the Edit button) by ONE factor.
 *
 * Why this cannot overlap: nothing in the layout is changed. The sizes / margins / row heights stay exactly as the
 * system computed them; the finished MainPanelRecyclerView (the view that holds all of those items) is only drawn
 * bigger / smaller as one picture (View.setScaleX / setScaleY). Every item grows by the same factor around the same
 * point, so the distances between them grow by the same factor too. (The old per-dimen sliders changed heights, widths
 * and margins by different amounts, which is what made tiles, sliders and cards run into each other.)
 *
 * - Pivot X = the middle of the items, pivot Y = the top of the first real row (the header space item stays where it
 *   is, so the first row never moves up under the date / status icons).
 * - When the scale is above 100 % it is limited automatically so the scaled content always stays inside the screen
 *   (side margin 16 dp, above the bottom inset). The settings value is kept; only the shown value is limited.
 * - Touches, getLocationOnScreen and drag in the system go through the view's own matrix, so they follow the scale.
 * - The system only animates ALPHA on this view (Folme MainPanelAnimController); scale is animated on the single items
 *   and on the detail panel, never on the RecyclerView itself, so nothing fights with our value.
 */
final class CcScale {
    private static final WeakHashMap<View, State> STATES = new WeakHashMap<>();
    private static final boolean DEBUG = false;

    private CcScale() { }

    /** Called from MainHook for every MainPanelRecyclerView that attaches. */
    static void attach(View v) {
        try {
            if (!(v instanceof ViewGroup)) return;
            State s = STATES.get(v);
            if (s == null) { s = new State((ViewGroup) v); STATES.put(v, s); }
            s.start();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CcScale attach failed: " + t);
        }
    }

    private static final class State implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
        final ViewGroup rv;
        boolean started = false, applied = false, loggedNoHolder = false;
        float lastScale = 1f, lastPivotY = -1f;
        int loggedReq = -1, lastReq = -1, lastW = -1, lastH = -1, lastN = -1;
        long lastAt = 0;
        Method getHolder;          // RecyclerView.getChildViewHolder(View)
        boolean holderLookedUp = false;

        State(ViewGroup rv) { this.rv = rv; }

        void start() {
            if (started) return;
            started = true;
            rv.addOnAttachStateChangeListener(this);
            rv.getViewTreeObserver().addOnPreDrawListener(this);
        }

        @Override public void onViewAttachedToWindow(View v) {
            if (!started) { started = true; v.getViewTreeObserver().addOnPreDrawListener(this); }
            lastAt = 0;
        }

        @Override public void onViewDetachedFromWindow(View v) {
            try { v.getViewTreeObserver().removeOnPreDrawListener(this); } catch (Throwable ignored) { }
            started = false;
            // leave the view as the system made it
            if (applied) { v.setScaleX(1f); v.setScaleY(1f); applied = false; lastScale = 1f; }
        }

        @Override public boolean onPreDraw() {
            try { tick(); } catch (Throwable t) { /* never break drawing */ }
            return true;
        }

        private String holderName(View child) {
            try {
                if (!holderLookedUp) {
                    holderLookedUp = true;
                    for (Class<?> c = rv.getClass(); c != null && getHolder == null; c = c.getSuperclass()) {
                        for (Method m : c.getDeclaredMethods()) {
                            if (m.getName().equals("getChildViewHolder") && m.getParameterTypes().length == 1
                                    && m.getParameterTypes()[0] == View.class) {
                                m.setAccessible(true);
                                getHolder = m;
                                break;
                            }
                        }
                    }
                }
                if (getHolder == null) return "";
                Object h = getHolder.invoke(rv, child);
                return h == null ? "" : h.getClass().getName();
            } catch (Throwable t) {
                return "";
            }
        }

        /** Bounds (left, right, top, bottom in RV coordinates) of what is really drawn inside an item: leaf views and views with a background. */
        private void visible(View v, int ox, int oy, int[] b, int depth) {
            if (v.getVisibility() != View.VISIBLE || v.getWidth() <= 0 || v.getHeight() <= 0 || v.getAlpha() < 0.02f) return;
            int l = ox + v.getLeft(), t = oy + v.getTop();
            boolean group = v instanceof ViewGroup && ((ViewGroup) v).getChildCount() > 0;
            if (!group || v.getBackground() != null) {
                b[0] = Math.min(b[0], l); b[1] = Math.max(b[1], l + v.getWidth());
                b[2] = Math.min(b[2], t); b[3] = Math.max(b[3], t + v.getHeight());
            }
            if (group && depth < 6) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++)
                    visible(g.getChildAt(i), l - g.getScrollX(), t - g.getScrollY(), b, depth + 1);
            }
        }

        private final java.util.ArrayList<ViewGroup> clipped = new java.util.ArrayList<>();
        private final java.util.ArrayList<Boolean> clipOrig = new java.util.ArrayList<>();

        /** While scaled up, the parents must not cut the list at their old edges; the original flags are put back at 100 %. */
        private void setUnclipped(boolean on) {
            try {
                if (on) {
                    if (!clipped.isEmpty()) return;
                    android.view.ViewParent p = rv.getParent();
                    ViewGroup self = rv;
                    chain(self);
                    for (int i = 0; i < 8 && p instanceof ViewGroup; i++) {
                        chain((ViewGroup) p);
                        p = p.getParent();
                    }
                } else {
                    for (int i = 0; i < clipped.size(); i++) clipped.get(i).setClipChildren(clipOrig.get(i));
                    clipped.clear(); clipOrig.clear();
                }
            } catch (Throwable ignored) { }
        }

        private void chain(ViewGroup g) {
            clipped.add(g);
            clipOrig.add(g.getClipChildren());
            g.setClipChildren(false);
        }

        private void tick() {
            int w = rv.getWidth(), h = rv.getHeight(), n = rv.getChildCount();
            if (w <= 0 || h <= 0 || n == 0) return;
            int req = ControlCenterSize.ccScale();
            if (req == 100 && !applied) return;                       // default: do nothing at all
            long now = SystemClock.uptimeMillis();
            if (req == lastReq && w == lastW && h == lastH && n == lastN && now - lastAt < 150) return;
            lastReq = req; lastW = w; lastH = h; lastN = n; lastAt = now;

            float density = rv.getResources().getDisplayMetrics().density;
            int left = Integer.MAX_VALUE, right = Integer.MIN_VALUE, topMost = Integer.MAX_VALUE, bottom = Integer.MIN_VALUE;
            int headerBottom = Integer.MIN_VALUE, footerH = 0, footerTop = Integer.MIN_VALUE;
            for (int i = 0; i < n; i++) {
                View c = rv.getChildAt(i);
                if (c == null || c.getVisibility() == View.GONE) continue;
                String hn = holderName(c);
                if (hn.contains("HeaderSpace")) { headerBottom = Math.max(headerBottom, c.getBottom()); continue; }
                if (hn.contains("FooterSpace")) { footerH = Math.max(footerH, c.getHeight()); footerTop = c.getTop(); continue; }
                if (c.getWidth() <= 0 || c.getHeight() <= 0) continue;
                topMost = Math.min(topMost, c.getTop());
                bottom = Math.max(bottom, c.getBottom());
                int[] vb = {Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE};
                visible(c, 0, 0, vb, 0);
                if (vb[1] > vb[0]) { left = Math.min(left, vb[0]); right = Math.max(right, vb[1]); }
                else { left = Math.min(left, c.getLeft()); right = Math.max(right, c.getRight()); }
            }
            if (right <= left || bottom <= topMost) return;            // nothing laid out yet

            if (headerBottom == Integer.MIN_VALUE && !loggedNoHolder && getHolder == null) {
                loggedNoHolder = true;
                XposedBridge.log("DynamicPill: CcScale: header space item not found, using the first item's top as pivot");
            }
            float pivotY;
            if (headerBottom != Integer.MIN_VALUE) pivotY = headerBottom;
            else if (lastPivotY >= 0) pivotY = lastPivotY;
            else pivotY = topMost;
            lastPivotY = pivotY;
            float pivotX = (left + right) / 2f;
            float contentW0 = right - left;
            boolean widthKnown = contentW0 < w * 0.97f;   // an item with a full width background would make it look like "no margin"

            float s = req / 100f;
            if (s > 1f) {
                float contentW = widthKnown ? contentW0 : w * 0.78f;
                float contentH = bottom - pivotY;
                float margin = 16f * density;
                android.util.DisplayMetrics dm = rv.getResources().getDisplayMetrics();
                float offX = 0, offY = 0;                                   // position of the list inside the window (layout only)
                android.view.ViewParent pp = rv.getParent();
                View cur = rv;
                for (int k = 0; k < 12 && cur != null; k++) {
                    offX += cur.getLeft() - cur.getScrollX();
                    offY += cur.getTop() - cur.getScrollY();
                    pp = cur.getParent();
                    cur = pp instanceof View ? (View) pp : null;
                }
                offX -= rv.getScrollX(); offY -= rv.getScrollY();
                float cxWin = offX + pivotX;
                float half = Math.min(cxWin - margin, dm.widthPixels - margin - cxWin);
                float maxW = contentW > 0 ? half / (contentW / 2f) : s;
                float availBottom = dm.heightPixels - footerH - 12f * density;
                float maxH = contentH > 0 ? (availBottom - (offY + pivotY)) / contentH : s;
                float want = s;
                s = Math.max(1f, Math.min(s, Math.min(maxW, maxH)));
                if (Math.abs(s - lastScale) >= 0.002f || req != loggedReq) {
                    loggedReq = req;
                    XposedBridge.log("DynamicPill: CcScale req=" + req + "% shown=" + Math.round(s * 100) + "% (wanted " + Math.round(want * 100)
                            + "%) view=" + w + "x" + h + " content=" + left + ".." + right + " (known=" + widthKnown + ") bottom=" + bottom
                            + " pivot=" + pivotX + "," + pivotY + " footerH=" + footerH + " maxW=" + maxW + " maxH=" + maxH);
                }
            }

            if (Math.abs(s - lastScale) < 0.002f && applied == (s != 1f)
                    && Math.abs(rv.getPivotX() - pivotX) < 1f && Math.abs(rv.getPivotY() - pivotY) < 1f) return;
            if (s == 1f && !applied) return;
            setUnclipped(s != 1f);
            rv.setPivotX(pivotX);
            rv.setPivotY(pivotY);
            rv.setScaleX(s);
            rv.setScaleY(s);
            lastScale = s;
            applied = s != 1f;
            if (DEBUG) XposedBridge.log("DynamicPill: CcScale req=" + req + " shown=" + s + " pivot=" + pivotX + "," + pivotY);
        }
    }
}

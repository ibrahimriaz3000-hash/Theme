CC Sliders Fix  (LSPosed module)
================================

Kya karta hai
- MiuiSystemUI.apk (host) aur MIUISystemUIPlugin.apk (plugin) dono ko hook karta hai.
- Control Center ka brightness vertical slider hamesha asli brightness dikhata hai
  aur drag karne par brightness change karta hai.
- Volume slider ko sahi waqt par resync karta hai.

Build (phone se, GitHub Actions)
1. GitHub par nayi repo banao, is zip ke andar ki sari files upload karo
   (.github folder samet) -- zip ko extract karke.
2. Actions tab > "Build APK" > Run workflow (ya push par khud chalega).
3. Run khatam ho to Artifacts se CCSliders-debug-apk download karo, APK install karo.

Use
1. LSPosed > Modules > "CC Sliders Fix" ON karo, scope mein "System UI" tick karo.
2. System UI restart karo (ya reboot).
3. Control Center kholo, slider chalao.

Debug
- LSPosed > Logs > Modules mein "[CCSliders]" wali lines dekho:
  "host hooked", "plugin loader mila", "plugin hooked", "brightness slider attach hua".

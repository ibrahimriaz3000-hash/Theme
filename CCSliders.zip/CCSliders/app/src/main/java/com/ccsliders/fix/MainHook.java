package com.ccsliders.fix;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Do jagah hook karta hai:
 *  1) MiuiSystemUI.apk (host, com.android.systemui)  -> MiuiBrightnessController
 *  2) MIUISystemUIPlugin.apk (plugin classloader)     -> BrightnessSliderController,
 *     VolumeSliderController, VerticalSeekBar
 */
public class MainHook implements IXposedHookLoadPackage {

    static final String TAG = "[CCSliders] ";
    private static final String HOST_PKG = "com.android.systemui";

    // ---- host (MiuiSystemUI.apk)
    private static final String HOST_BRIGHTNESS =
            "com.android.systemui.controlcenter.policy.MiuiBrightnessController";
    private static final String PLUGIN_FACTORY =
            "com.android.systemui.shared.plugins.PluginInstance$Factory";
    private static final String PLUGIN_CTX_WRAPPER =
            "com.android.systemui.shared.plugins.PluginActionManager$PluginContextWrapper";

    // ---- plugin (MIUISystemUIPlugin.apk)
    private static final String P_BRIGHTNESS =
            "miui.systemui.controlcenter.panel.main.brightness.BrightnessSliderController";
    private static final String P_VOLUME =
            "miui.systemui.controlcenter.panel.main.volume.VolumeSliderController";
    private static final String P_VSEEK =
            "miui.systemui.controlcenter.widget.VerticalSeekBar";

    private static final Set<ClassLoader> DONE =
            Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<ClassLoader, Boolean>()));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!HOST_PKG.equals(lp.packageName)) return;
        final ClassLoader host = lp.classLoader;

        try { hookHost(host); } catch (Throwable t) { XposedBridge.log(TAG + "hookHost: " + t); }
        try { hookPluginLoader(host); } catch (Throwable t) { XposedBridge.log(TAG + "hookPluginLoader: " + t); }
        // Agar kisi ROM build mein plugin classes host mein hi hon
        tryPlugin(host);
    }

    // ------------------------------------------------------------------ host
    private void hookHost(ClassLoader host) {
        Class<?> c = XposedHelpers.findClassIfExists(HOST_BRIGHTNESS, host);
        if (c == null) {
            XposedBridge.log(TAG + "host MiuiBrightnessController nahi mila");
            return;
        }
        XposedBridge.hookAllConstructors(c, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                SliderBridge.setHostBrightnessController(p.thisObject);
            }
        });
        // Controller ka asli state (min/max backlight) hamesha latest rakhne ke liye
        XC_MethodHook keep = new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                SliderBridge.setHostBrightnessController(p.thisObject);
            }
        };
        XposedBridge.hookAllMethods(c, "registerCallbacks", keep);
        XposedBridge.hookAllMethods(c, "setToggleSliderBase", keep);
        XposedBridge.hookAllMethods(c, "onInit", keep);
        XposedBridge.log(TAG + "host hooked");
    }

    // --------------------------------------------- plugin classloader pakadna
    private void hookPluginLoader(ClassLoader host) {
        XC_MethodHook h = new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                Object r = p.getResult();
                if (r instanceof ClassLoader) tryPlugin((ClassLoader) r);
            }
        };
        Class<?> f = XposedHelpers.findClassIfExists(PLUGIN_FACTORY, host);
        if (f != null) XposedBridge.hookAllMethods(f, "getClassLoader", h);
        Class<?> w = XposedHelpers.findClassIfExists(PLUGIN_CTX_WRAPPER, host);
        if (w != null) XposedBridge.hookAllMethods(w, "getClassLoader", h);
    }

    private void tryPlugin(ClassLoader cl) {
        if (cl == null || !DONE.add(cl)) return;
        try {
            Class<?> b = XposedHelpers.findClassIfExists(P_BRIGHTNESS, cl);
            Class<?> v = XposedHelpers.findClassIfExists(P_VOLUME, cl);
            Class<?> s = XposedHelpers.findClassIfExists(P_VSEEK, cl);
            if (b == null && v == null) return;
            XposedBridge.log(TAG + "plugin loader mila: " + cl);
            SliderBridge.setPluginLoader(cl);

            if (s != null) {
                XposedBridge.hookAllMethods(s, "setOnSeekBarChangeListener", new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        SliderBridge.wrapListenerIfBridged(p);
                    }
                });
            }
            if (b != null) {
                XC_MethodHook attach = new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        SliderBridge.attachBrightness(p.thisObject);
                    }
                };
                XposedBridge.hookAllMethods(b, "onBindViewHolder", attach);
                XposedBridge.hookAllMethods(b, "onStart", attach);
                XposedBridge.hookAllMethods(b, "setListening", attach);
                XposedBridge.hookAllMethods(b, "onConfigurationChanged", attach);
            }
            if (v != null) {
                XC_MethodHook attach = new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        SliderBridge.refreshVolume(p.thisObject);
                    }
                };
                XposedBridge.hookAllMethods(v, "onBindViewHolder", attach);
                XposedBridge.hookAllMethods(v, "setListening", attach);
                XposedBridge.hookAllMethods(v, "onConfigurationChanged", attach);
            }
            XposedBridge.log(TAG + "plugin hooked");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "tryPlugin: " + t);
        }
    }
}

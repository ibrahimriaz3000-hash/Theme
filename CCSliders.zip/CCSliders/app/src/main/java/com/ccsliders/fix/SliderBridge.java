package com.ccsliders.fix;

import android.content.Context;
import android.database.ContentObserver;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.SeekBar;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Brightness slider: slider <-> asli screen brightness ko hamesha sync rakhta hai
 * aur drag par seedha brightness set karta hai (host MiuiBrightnessController.setBrightness
 * ke zariye, warna DisplayManager / Settings fallback).
 * Volume slider: controller ke apne sync methods ko sahi waqt par chalata hai.
 */
final class SliderBridge {

    private static final String TAG = MainHook.TAG;
    private static final String BRIGHT_UTILS =
            "miui.systemui.controlcenter.brightness.BrightnessUtils";

    private static volatile WeakReference<Object> hostCtl = new WeakReference<>(null);
    private static volatile ClassLoader pluginLoader;
    private static final Map<View, Bridge> BRIDGES = new WeakHashMap<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private SliderBridge() { }

    static void setHostBrightnessController(Object c) { hostCtl = new WeakReference<>(c); }
    static void setPluginLoader(ClassLoader cl) { pluginLoader = cl; }

    // ------------------------------------------------------------ brightness
    static void attachBrightness(Object controller) {
        try {
            Object s = XposedHelpers.callMethod(controller, "getSlider");
            if (!(s instanceof SeekBar)) return;
            final SeekBar sb = (SeekBar) s;
            Bridge b;
            synchronized (BRIDGES) { b = BRIDGES.get(sb); }
            if (b == null) {
                b = new Bridge(sb);
                synchronized (BRIDGES) { BRIDGES.put(sb, b); }
                b.install();
                XposedBridge.log(TAG + "brightness slider attach hua");
            }
            b.syncSoon();
        } catch (Throwable t) {
            // getSlider() tab fail hota hai jab view holder abhi bana nahi; agle callback par ho jayega
        }
    }

    /** VerticalSeekBar.setOnSeekBarChangeListener(...) ke arg ko hamari wrapper mein lapetna. */
    static void wrapListenerIfBridged(XC_MethodHook.MethodHookParam p) {
        Bridge b;
        synchronized (BRIDGES) { b = BRIDGES.get(p.thisObject); }
        if (b == null || p.args == null || p.args.length != 1) return;
        Object a = p.args[0];
        if (a instanceof Bridge.Wrap) return;
        p.args[0] = b.wrap((SeekBar.OnSeekBarChangeListener) a);
    }

    private static final class Bridge {
        final SeekBar sb;
        volatile boolean dragging;
        ContentObserver obs;
        SeekBar.OnSeekBarChangeListener orig;

        Bridge(SeekBar sb) { this.sb = sb; }

        final class Wrap implements SeekBar.OnSeekBarChangeListener {
            final SeekBar.OnSeekBarChangeListener d;
            Wrap(SeekBar.OnSeekBarChangeListener d) { this.d = d; }
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (d != null) d.onProgressChanged(s, p, fromUser);
                if (fromUser) onUser(p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {
                dragging = true;
                if (d != null) d.onStartTrackingTouch(s);
            }
            @Override public void onStopTrackingTouch(SeekBar s) {
                if (d != null) d.onStopTrackingTouch(s);
                dragging = false;
                syncSoon();
            }
        }

        SeekBar.OnSeekBarChangeListener wrap(SeekBar.OnSeekBarChangeListener d) { return new Wrap(d); }

        void install() {
            // Maujooda listener nikal kar wrapper lagao (hook setter khud wrap kar deta hai)
            try { orig = (SeekBar.OnSeekBarChangeListener) XposedHelpers.getObjectField(sb, "onSeekBarChangeListener"); }
            catch (Throwable ignored) { }
            try { sb.setOnSeekBarChangeListener(orig); } catch (Throwable t) { XposedBridge.log(TAG + "listener: " + t); }

            sb.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override public void onViewAttachedToWindow(View v) { register(); syncSoon(); }
                @Override public void onViewDetachedFromWindow(View v) { unregister(); }
            });
            if (sb.isAttachedToWindow()) register();
        }

        void register() {
            if (obs != null) return;
            try {
                obs = new ContentObserver(MAIN) {
                    @Override public void onChange(boolean selfChange) { if (!dragging) sync(); }
                };
                Context c = sb.getContext();
                c.getContentResolver().registerContentObserver(Settings.System.getUriFor("screen_brightness_float"), false, obs);
                c.getContentResolver().registerContentObserver(Settings.System.getUriFor("screen_brightness"), false, obs);
            } catch (Throwable t) { obs = null; }
        }

        void unregister() {
            try { if (obs != null) sb.getContext().getContentResolver().unregisterContentObserver(obs); }
            catch (Throwable ignored) { }
            obs = null;
        }

        void syncSoon() { sb.post(new Runnable() { @Override public void run() { if (!dragging) sync(); } }); }

        void sync() {
            try {
                Context c = sb.getContext();
                int min = sb.getMin();
                if (sb.getMax() - min <= 0) { sb.setMax(65535); min = sb.getMin(); }
                float[] r = range(c);
                float lin = readLinear(c, r);
                float frac = linearToFraction(lin, r[0], r[1]);
                int target = min + Math.round(frac * (sb.getMax() - min));
                if (Math.abs(sb.getProgress() - target) > 1) {
                    try { XposedHelpers.callMethod(sb, "setValue", target); }
                    catch (Throwable t) { sb.setProgress(target); }
                }
            } catch (Throwable t) {
                XposedBridge.log(TAG + "brightness sync: " + t);
            }
        }

        void onUser(int progress) {
            try {
                Context c = sb.getContext();
                int min = sb.getMin();
                float span = sb.getMax() - min;
                if (span <= 0) return;
                float frac = clamp((progress - min) / span, 0f, 1f);
                float[] r = range(c);
                setLinear(c, fractionToLinear(frac, r[0], r[1]));
            } catch (Throwable t) {
                XposedBridge.log(TAG + "brightness set: " + t);
            }
        }
    }

    // --- brightness helpers
    private static float[] range(Context c) {
        Object h = hostCtl.get();
        if (h != null) {
            try {
                float mn = XposedHelpers.getFloatField(h, "mMinimumBacklight");
                float mx = XposedHelpers.getFloatField(h, "mMaximumBacklight");
                if (mx > mn) return new float[]{mn, mx};
            } catch (Throwable ignored) { }
        }
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            Method m = PowerManager.class.getMethod("getBrightnessConstraint", int.class);
            float mn = (Float) m.invoke(pm, 0);
            float mx = (Float) m.invoke(pm, 1);
            if (mx > mn) return new float[]{mn, mx};
        } catch (Throwable ignored) { }
        return new float[]{0f, 1f};
    }

    private static float readLinear(Context c, float[] r) {
        try {
            float f = Settings.System.getFloat(c.getContentResolver(), "screen_brightness_float", Float.NaN);
            if (!Float.isNaN(f)) return clamp(f, r[0], r[1]);
        } catch (Throwable ignored) { }
        try {
            int i = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            return clamp(r[0] + (i / 255f) * (r[1] - r[0]), r[0], r[1]);
        } catch (Throwable ignored) { }
        return r[0];
    }

    private static void setLinear(Context c, float lin) {
        Object h = hostCtl.get();
        if (h != null) {
            try { XposedHelpers.callMethod(h, "setBrightness", lin); return; }
            catch (Throwable ignored) { }
        }
        try {
            DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
            Method m = DisplayManager.class.getMethod("setBrightness", int.class, float.class);
            m.invoke(dm, 0, lin);
            return;
        } catch (Throwable ignored) { }
        try { Settings.System.putFloat(c.getContentResolver(), "screen_brightness_float", lin); }
        catch (Throwable t) { XposedBridge.log(TAG + "setLinear fallback: " + t); }
    }

    // MIUI ki apni BrightnessUtils curve use karte hain, warna AOSP formula
    private static final float A = 0.17883277f, B = 0.28466892f, C = 0.55991073f, R = 0.5f;

    private static float fractionToLinear(float frac, float min, float max) {
        ClassLoader cl = pluginLoader;
        if (cl != null) {
            try {
                Class<?> u = XposedHelpers.findClassIfExists(BRIGHT_UTILS, cl);
                int gmax = XposedHelpers.getStaticIntField(u, "GAMMA_SPACE_MAX");
                Object o = XposedHelpers.callStaticMethod(u, "convertGammaToLinearFloat",
                        Math.round(frac * gmax), min, max);
                return clamp((Float) o, min, max);
            } catch (Throwable ignored) { }
        }
        float ret = frac <= R ? (frac / R) * (frac / R) : (float) (Math.exp((frac - C) / A) + B);
        return clamp(min + (max - min) * (ret / 12f), min, max);
    }

    private static float linearToFraction(float lin, float min, float max) {
        ClassLoader cl = pluginLoader;
        if (cl != null) {
            try {
                Class<?> u = XposedHelpers.findClassIfExists(BRIGHT_UTILS, cl);
                int gmax = XposedHelpers.getStaticIntField(u, "GAMMA_SPACE_MAX");
                Object o = XposedHelpers.callStaticMethod(u, "convertLinearToGammaFloat", lin, min, max);
                return clamp(((Integer) o) / (float) gmax, 0f, 1f);
            } catch (Throwable ignored) { }
        }
        float n = clamp((lin - min) / (max - min), 0f, 1f) * 12f;
        float ret = n <= 1f ? (float) Math.sqrt(n) * R : (float) (A * Math.log(n - B) + C);
        return clamp(ret, 0f, 1f);
    }

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

    // ---------------------------------------------------------------- volume
    static void refreshVolume(final Object controller) {
        MAIN.post(new Runnable() {
            @Override public void run() {
                String[] steps = {"syncVolumeRange", "syncSystemVolume", "updateSlider"};
                for (String m : steps) {
                    try { XposedHelpers.callMethod(controller, m); }
                    catch (Throwable ignored) { }
                }
            }
        });
    }
}

Dynamic Pill (LSPosed module) v2.14
1. Upload this zip's contents to a GitHub repo (the .github/workflows/build.yml is included).
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot. Open settings from the "Dynamic Pill" Control Center tile (long press) or from LSPosed.

Changes in 2.2
- Status Bar Padding (Left / Right / Top) removed completely: settings section, status bar height hook,
  content insets hook, keyguard/status bar view tracking. System UI status bar is left untouched.
- Pill is centred on the real camera cutout / status bar height again (no padding offset).
- Slider no longer gets stuck capturing touches when the gesture is cancelled.

Changes in 2.3
- New switch "Battery % in Control Center (iOS style)" (settings -> CONTROL CENTER, on by default).
  Shows "66%" before the battery icon in the Control Center header. The status bar is untouched, so with
  Settings -> Notifications & status bar -> Battery indicator = icon only, the status bar has no percentage
  and only the Control Center shows it. If the system already shows a percentage text there, ours hides itself.

Changes in 2.4  (smooth pull-down, no glitch)
- Grabber line now fades out frame by frame while you pull the status bar / Control Center down
  (before it waited for a 400 ms poll, then popped), and fades back in when it closes.
- Pill fades in / out (enable switch, lock screen switch, first start) instead of popping.
- Control Center battery % is laid out before the first frame (no pop-in while the panel opens),
  changes are debounced (no flicker) and fade in/out; no work is done while the panel is closed.
- build.yml replaced with a stronger workflow (debug + release APK, checksums, cache, retry, auto release on tag).

Changes in 2.5
- Fixed double battery percentage in the Control Center: with Settings -> Battery indicator = "Percentage (in the icon)"
  or "Percentage outside", our extra "63%" now stays hidden at once (read from the system setting; the in-icon
  number is canvas-drawn so it could not be detected from the view). It re-checks the moment you change that option.
  Only with "icon only" does the Control Center show the iOS style percentage.

Changes in 2.6  (status bar icons jerk while pulling down)
- The Control Center battery "63%" no longer takes any layout space while the panel is being pulled. Before, it widened
  the header the moment it appeared, so the status bar icons (signal / wifi) that morph into the Control Center header
  jumped and vanished. Now the header moves exactly like stock, and the % expands in smoothly (width + fade) only after
  the Control Center is open, and collapses as soon as you start closing it.

Changes in 2.7  (icons glitch while closing the Control Center)
- 2.6 used a threshold that was reached early while pulling, so the % still changed the header layout in the middle of
  the icon morph (opening and closing). Now the % is only revealed after the panel has stopped moving fully open
  (settled for 160 ms), and it collapses the moment the panel starts to close, before the status bar icons
  (signal / wifi) morph back. Nothing changes the header layout while it is moving.

Changes in 2.8  (icons wrong while the Control Center is closing)
- The screenshots show the Control Center header icons (wifi + 62% + battery, signal clipped) while the panel is
  fading / blurring away. HyperOS closes it with a fade, so height alone could not detect the closing.
  Now the % follows the header itself: it is revealed only after the header has stopped moving and is fully opaque,
  and collapses (70 ms) the instant the header moves or fades, before the icons morph back into the status bar.
  When the Control Center is hidden the % is reset, so the next opening always starts clean.

Changes in 2.9
- Pill shape: new setting PILL -> "Corner smoothness (0 = circle)", default 30.
  The corners were already fully round (radius = half the height), so they cannot get rounder; instead the ends now
  use an iOS style continuous curve (superellipse) so the curve blends into the straight edges without a visible
  seam. 0 = old plain circular capsule, 100 = softest / squarest curve. The white border follows the same shape.

Changes in 2.10
- Control Center battery %: pure fade in / fade out. The text no longer wipes in from the side: it is drawn pinned
  next to the battery icon. Opening: space opens first (text still invisible), then the text fades in (smoothstep, 320 ms).
  Closing: the text fades out fast (150 ms) while the space closes, so the status bar icons are not squeezed.

Changes in 2.11  (pill visible in dark mode)
- In system dark mode the black pill vanished on a black status bar. Now a thin light rim plus a faint soft glow
  fades in around the pill (350 ms) and fades out again in light mode. The rim follows the pill's smooth shape.
  Settings -> PILL -> "Dark mode rim (0 = off)", default 60. It hides itself while the white border is shown.

Changes in 2.12  (camera in the centre of the pill)
- NEW: "Auto-center on camera cut-out" (default on): the pill is centred on the real camera cut-out reported by the
  system instead of the screen centre, so the camera sits in the middle of the pill even if it is off-centre.
- NEW: "Horizontal offset" slider (+-15 mm, 0.1 mm steps) for fine tuning left / right.
- "Vertical offset" range increased from +-10 mm to +-15 mm.

Changes in 2.13
- REMOVED: "Dark mode rim" (setting, glow and rim drawing) completely.
- Control Center battery %: it no longer sits next to the battery icon. It now floats right ABOVE the carrier name
  (e.g. "ZONG"), right aligned with it, and fades in / out in place (no sliding). It takes no layout space, so the
  header icons are never moved. If the carrier view is not found it is placed a little above the battery icon.
  Same rules as before: fades in only after the Control Center is fully open, fades out the moment you start closing,
  hidden when the system "Battery indicator" already shows a percentage.

Changes in 2.14
- The battery % above the carrier name / next to the battery icon is removed (this module no longer adds it).
- NEW: Control Center info line above the date (left side):  "57% UNTIL 1:30 ●"
  (charging: "57% FULL AT 2:15"). No fade in / out effect: it just moves with the header.
- The green dot blinks all the time while the Control Center is open.
- Estimated time source, in order: 1) system battery discharge prediction (PowerManager, Android 12+),
  2) remaining charge / smoothed current draw, 3) observed % drop rate. Charging: system charge-time estimate.
  Time uses the phone's 12 / 24 hour setting; adds the weekday if it ends on another day.

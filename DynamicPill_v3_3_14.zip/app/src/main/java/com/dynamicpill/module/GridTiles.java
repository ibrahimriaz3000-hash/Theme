package com.dynamicpill.module;

import android.graphics.Rect;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import de.robv.android.xposed.XposedBridge;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * "Control Center Size" slider.
 *
 * 3.3.10: the top part (Wi-Fi / Mobile data cards, tile card, brightness + volume sliders) is scaled as ONE block
 * around one common pivot (top centre of the block), so the gaps between its parts grow with it and nothing
 * overlaps (3.3.9 scaled each part around its own centre: overlap). The block is kept inside the screen width.
 * Everything below the block (round grid tiles, Edit button) is moved down by exactly the extra height of the block.
 * The round grid tiles themselves grow around their own centre.
 */
final class GridTiles {
    private static final ArrayList<WeakReference<View>> TOP = new ArrayList<>();
    private static final ArrayList<WeakReference<View>> FOLLOW = new ArrayList<>();
    private static float bl, br, bt, bb;
    private static boolean haveBlock = false;
    private static long metricsAt = 0, followAt = 0;
    private static boolean logged = false;

    /** Cards, brightness / volume sliders and the tile card panel: part of the top block. */
    static void attachWhole(final View v) {
        try {
            TOP.add(new WeakReference<>(v));
            hook(v, new Runnable() { @Override public void run() { updateTop(v); } });
        } catch (Throwable ignored) { }
    }

    /** Round grid tile: its circle grows, the tile moves down with the block. */
    static void attach(final View tile) {
        try {
            final View icon = findIcon(tile, 0);
            if (icon == null) {
                if (!logged) { logged = true; XposedBridge.log("DynamicPill: tiles size - view not found in " + tile.getClass().getName()); }
                return;
            }
            hook(tile, new Runnable() { @Override public void run() { updateTile(tile, icon); } });
        } catch (Throwable ignored) { }
    }

    private static void hook(final View v, final Runnable r) {
        final ViewTreeObserver.OnPreDrawListener l = new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                try { r.run(); } catch (Throwable ignored) { }
                return true;
            }
        };
        v.getViewTreeObserver().addOnPreDrawListener(l);
        v.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View x) { }
            @Override public void onViewDetachedFromWindow(View x) {
                try { x.getViewTreeObserver().removeOnPreDrawListener(l); } catch (Throwable ignored) { }
                x.removeOnAttachStateChangeListener(this);
            }
        });
        unclip(v);
        try { r.run(); } catch (Throwable ignored) { }
    }

    private static final java.util.WeakHashMap<View, Long> UNCLIP_AT = new java.util.WeakHashMap<>();
    private static boolean clipLogged = false;

    /**
     * No parent may cut off a view that grew. MIUI re-enables clipping while the panel lays out / animates, so this is
     * done again (at most every 120 ms per view) while we draw. Parents narrower than the Control Center root are the
     * ones that cut the block at the sides: for them the outline clip and clip bounds are switched off too.
     */
    private static void unclip(View v) {
        long now = SystemClock.uptimeMillis();
        Long last = UNCLIP_AT.get(v);
        if (last != null && now - last < 120) return;
        UNCLIP_AT.put(v, now);
        View root = MainHook.ccRoot(v);
        int rootW = root != null ? root.getWidth() : 0;
        StringBuilder log = clipLogged ? null : new StringBuilder();
        View c = v;
        for (int i = 0; i < 16 && c != null; i++) {
            boolean narrow = c != v && (rootW <= 0 || c.getWidth() < rootW * 0.97f);
            if (log != null) log.append(c.getClass().getSimpleName()).append('[').append(c.getWidth())
                    .append(c instanceof ViewGroup && ((ViewGroup) c).getClipChildren() ? ",cc" : "")
                    .append(c.getClipToOutline() ? ",co" : "").append(c.getClipBounds() != null ? ",cb" : "").append("] < ");
            if (c instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) c;
                if (g.getClipChildren()) g.setClipChildren(false);
                if (g.getClipToPadding()) g.setClipToPadding(false);
            }
            if (c != v) {
                if (c.getClipBounds() != null) c.setClipBounds((Rect) null);
                if (narrow && c.getClipToOutline()) c.setClipToOutline(false);
            }
            if (c == root) break;
            android.view.ViewParent p = c.getParent();
            c = p instanceof View ? (View) p : null;
        }
        if (log != null) {
            clipLogged = true;
            XposedBridge.log("DynamicPill: tiles size - clip chain: " + log);
        }
    }

    // ---- geometry (layout positions, not affected by our own scale / translation)
    private static float[] offset(View v, View root) {
        float x = 0, y = 0;
        View c = v;
        while (c != null && c != root) {
            x += c.getLeft();
            y += c.getTop();
            android.view.ViewParent p = c.getParent();
            View pv = p instanceof View ? (View) p : null;
            if (pv != null) { x -= pv.getScrollX(); y -= pv.getScrollY(); }
            c = pv;
        }
        return c == root ? new float[]{x, y} : null;
    }

    private static void metrics(View root) {
        long now = SystemClock.uptimeMillis();
        if (now - metricsAt < 40) return;
        metricsAt = now;
        float l = Float.MAX_VALUE, r = -1, t = Float.MAX_VALUE, b = -1;
        boolean any = false;
        for (int i = TOP.size() - 1; i >= 0; i--) {
            View w = TOP.get(i).get();
            if (w == null) { TOP.remove(i); continue; }
            if (!w.isAttachedToWindow() || !w.isShown() || w.getWidth() <= 0) continue;
            float[] o = offset(w, root);
            if (o == null) continue;
            any = true;
            l = Math.min(l, o[0]); r = Math.max(r, o[0] + w.getWidth());
            t = Math.min(t, o[1]); b = Math.max(b, o[1] + w.getHeight());
        }
        haveBlock = any && r > l && b > t;
        if (haveBlock) { bl = l; br = r; bt = t; bb = b; }
    }

    /** Scale of the top block: the slider value, but never wider than the screen. */
    private static float topScale(View root) {
        float s = ControlCenterSize.topScale() / 100f;
        if (s > 1f && haveBlock) {
            float maxS = (root.getWidth() - 2 * 12 * root.getResources().getDisplayMetrics().density) / (br - bl);
            s = Math.min(s, Math.max(1f, maxS));
        }
        return s;
    }

    private static float offsetPx(View root) {
        return ControlCenterSize.offsetDp() * root.getResources().getDisplayMetrics().density;
    }

    private static float extraY(View root) {
        if (!haveBlock) return 0;
        return (bb - bt) * (topScale(root) - 1f);
    }

    private static void updateTop(View v) {
        unclip(v);
        View root = MainHook.ccRoot(v);
        if (root == null) return;
        metrics(root);
        if (!haveBlock) return;
        float s = topScale(root);
        float[] o = offset(v, root);
        if (o == null) return;
        float px = (bl + br) / 2f - o[0], py = bt - o[1];
        if (Math.abs(v.getPivotX() - px) > 0.5f) v.setPivotX(px);
        if (Math.abs(v.getPivotY() - py) > 0.5f) v.setPivotY(py);
        if (v.getScaleX() != s) v.setScaleX(s);
        if (v.getScaleY() != s) v.setScaleY(s);
        float ty = offsetPx(root);   // "Move down" slider
        if (v.getTranslationY() != ty) v.setTranslationY(ty);
    }

    private static void updateTile(View tile, View icon) {
        float s = ControlCenterSize.gridScale() / 100f;
        if (icon.getScaleX() != s || icon.getScaleY() != s) {
            int w = icon.getWidth(), h = icon.getHeight();
            if (w > 0 && h > 0) { icon.setPivotX(w / 2f); icon.setPivotY(h / 2f); }
            icon.setScaleX(s);
            icon.setScaleY(s);
        }
        View root = MainHook.ccRoot(tile);
        if (root == null) return;
        metrics(root);
        float e = haveBlock ? extraY(root) + offsetPx(root) : 0f;
        if (tile.getTranslationY() != e) tile.setTranslationY(e);
        followButtons(root, e);
    }

    /** The "Edit" button (and anything like it) below the block moves down with the tiles. */
    private static void followButtons(View root, float e) {
        long now = SystemClock.uptimeMillis();
        if (now - followAt > 1500 && root instanceof ViewGroup) {
            followAt = now;
            scan((ViewGroup) root, root, 0, new int[]{0});
        }
        for (int i = FOLLOW.size() - 1; i >= 0; i--) {
            View f = FOLLOW.get(i).get();
            if (f == null || !f.isAttachedToWindow()) { FOLLOW.remove(i); continue; }
            if (f.getTranslationY() != e) f.setTranslationY(e);
        }
    }

    private static void scan(ViewGroup g, View root, int depth, int[] count) {
        if (depth > 12 || count[0] > 600) return;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            count[0]++;
            if (c instanceof TextView) {
                CharSequence t = ((TextView) c).getText();
                if (t != null && "edit".equalsIgnoreCase(t.toString().trim()) && c.isShown()) addFollow(c, root);
            }
            if (c instanceof ViewGroup) scan((ViewGroup) c, root, depth + 1, count);
        }
    }

    private static void addFollow(View t, View root) {
        float d = root.getResources().getDisplayMetrics().density;
        View target = t;
        while (target.getParent() instanceof View && target.getParent() != root
                && ((View) target.getParent()).getHeight() <= 100 * d && ((View) target.getParent()).getHeight() > 0)
            target = (View) target.getParent();
        for (WeakReference<View> r : FOLLOW) if (r.get() == target) return;
        FOLLOW.add(new WeakReference<>(target));
    }

    private static View findIcon(View v, int depth) {
        if (v.getClass().getName().endsWith("QSTileItemIconView")) return v;
        if (depth > 3 || !(v instanceof ViewGroup)) return null;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) {
            View r = findIcon(g.getChildAt(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }
}

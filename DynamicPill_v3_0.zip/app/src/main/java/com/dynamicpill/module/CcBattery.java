package com.dynamicpill.module;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/**
 * iOS style "100%" text next to the battery icon in the Control Center header.
 * The status bar is not touched: whatever the system "Battery indicator" option says
 * (icon only / percentage in icon / percentage outside) still applies there.
 */
final class CcBattery {
    private CcBattery() { }

    static final String K_CC_BATT = "cc_batt_pct";

    private static XSharedPreferences xsp;
    private static long lastReload = 0;

    static synchronized boolean enabled() {
        try {
            if (xsp == null) {
                xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                xsp.makeWorldReadable();
            }
            long now = System.currentTimeMillis();
            if (now - lastReload > 1000) {
                lastReload = now;
                if (xsp.hasFileChanged()) xsp.reload();
            }
            return xsp.getBoolean(K_CC_BATT, true);
        } catch (Throwable t) {
            return true;
        }
    }

    /** Called for every BatteryMeterView that attaches; does nothing outside the Control Center. */
    static void attach(View battery, boolean inControlCenter) {
        try {
            if (!inControlCenter) return;
            ViewGroup host;
            int index;
            if (battery instanceof LinearLayout) {
                host = (ViewGroup) battery;
                index = 0; // text first, icon last: "100% [battery]"
            } else if (battery.getParent() instanceof LinearLayout) {
                host = (ViewGroup) battery.getParent();
                index = host.indexOfChild(battery);
            } else {
                XposedBridge.log("DynamicPill: CC battery host is not a LinearLayout, skipped");
                return;
            }
            for (int i = 0; i < host.getChildCount(); i++) {
                if (host.getChildAt(i) instanceof PctText) return; // already added
            }
            PctText t = new PctText(battery.getContext(), battery);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = android.view.Gravity.CENTER_VERTICAL;
            host.addView(t, Math.max(0, index), lp);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CC battery attach failed: " + t);
        }
    }

    private static int lastStyleLog = -2;

    /**
     * The system "Battery indicator" option (Settings -> Notifications & status bar):
     * 0 = icon only, 1 = percentage in the icon, 2 = percentage next to the icon.
     * The in-icon number is drawn on a canvas (not a TextView), so it can only be detected from the setting.
     * Returns true when the system already shows the percentage somewhere (then we must stay hidden).
     */
    static boolean settingShowsPercent(Context c) {
        int style = -1;
        try {
            style = android.provider.Settings.System.getInt(c.getContentResolver(), "battery_indicator_style", -1);
        } catch (Throwable ignored) { }
        if (style != lastStyleLog) {
            lastStyleLog = style;
            XposedBridge.log("DynamicPill: battery_indicator_style=" + style);
        }
        if (style > 0) return true;
        if (style == 0) return false;
        try {
            return android.provider.Settings.System.getInt(c.getContentResolver(),
                    "status_bar_show_battery_percent", 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    /** True when the system itself already shows a percentage text inside the battery view. */
    private static boolean systemShowsPercent(View root, View ignore) {
        if (!(root instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) root;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == ignore) continue;
            if (c instanceof TextView) {
                CharSequence s = ((TextView) c).getText();
                if (s != null && s.length() > 0 && c.getVisibility() == View.VISIBLE
                        && c.getWidth() > 0 && c.getAlpha() > 0.1f
                        && Character.isDigit(s.charAt(0))) return true;
            } else if (systemShowsPercent(c, ignore)) {
                return true;
            }
        }
        return false;
    }

    /**
     * The "63%" text. It takes NO layout space while the panel is being pulled (so the status bar icons that
     * morph into the Control Center header move exactly like stock, no jerk) and only expands in smoothly
     * once the Control Center is open. It collapses again the moment you start closing it.
     */
    static final class PctText extends TextView {
        private final View battery;
        private int level = -1;
        private boolean registered = false;

        private boolean baseWant = false;   // setting / system state says "we may show"
        private boolean open = false;       // currently revealed (or revealing)
        private float reveal = 0f;          // 0 = no width / transparent, 1 = full
        private boolean forced = false;
        private boolean first = true;
        private int pend = 0;
        private android.animation.ValueAnimator anim;

        private final BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) { read(i); forced = true; sync(); }
        };

        // fires the moment the user changes "Battery indicator" in Settings
        private final android.database.ContentObserver styleObs =
                new android.database.ContentObserver(new android.os.Handler(android.os.Looper.getMainLooper())) {
            @Override
            public void onChange(boolean selfChange) { forced = true; sync(); }
        };

        // slow loop: re-evaluates the (expensive) base decision
        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                sync();
                if (isAttachedToWindow()) postDelayed(this, 1000);
            }
        };

        // fast loop: reveal the % only once the header has SETTLED (same place, fully opaque, panel not moving),
        // and take it away the moment the header starts to move / fade (open -> close), before the status bar
        // icons morph back. The header container is narrow while it morphs, so extra width there clips the
        // signal / wifi icons.
        private float lastHf = 0f, lastA = 0f, settledHf = 0f, settledA = 1f;
        private int lastY = Integer.MIN_VALUE, settledY = 0;
        private long stableSince = 0;
        private final int[] loc = new int[2];

        private float effAlpha(View v) {
            float a = 1f;
            View c = v;
            for (int i = 0; i < 16 && c != null; i++) {
                a *= c.getAlpha();
                c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
            }
            return a;
        }

        private final Runnable fast = new Runnable() {
            @Override
            public void run() {
                long delay = 300;
                try {
                    if (!battery.isShown()) {
                        // Control Center closed: start clean for the next opening
                        if (open || reveal > 0f || getVisibility() != View.GONE) hideNow();
                        lastY = Integer.MIN_VALUE;
                    } else {
                        delay = 40;
                        battery.getLocationOnScreen(loc);
                        float hf = PillController.ccHeightFrac;
                        float a = effAlpha(battery);
                        long now = android.os.SystemClock.uptimeMillis();
                        boolean steady = lastY != Integer.MIN_VALUE
                                && Math.abs(loc[1] - lastY) <= 1
                                && Math.abs(a - lastA) < 0.01f
                                && Math.abs(hf - lastHf) < 0.002f;
                        if (!steady) stableSince = now;
                        lastY = loc[1]; lastA = a; lastHf = hf;
                        if (!open) {
                            if (baseWant && steady && a >= 0.95f && hf >= 0.30f && now - stableSince >= 160) {
                                open = true;
                                settledY = loc[1]; settledA = a; settledHf = hf;
                                animateTo(1f, 240);
                            }
                        } else if (!baseWant || Math.abs(loc[1] - settledY) > 2
                                || a < settledA - 0.03f || hf < settledHf - 0.008f) {
                            open = false;
                            animateTo(0f, 70);
                        }
                    }
                } catch (Throwable ignored) { }
                if (isAttachedToWindow()) postDelayed(this, delay);
            }
        };

        PctText(Context ctx, View battery) {
            super(ctx);
            this.battery = battery;
            setTextColor(Color.WHITE);
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            setSingleLine(true);
            setIncludeFontPadding(false);
            int p = Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 3,
                    ctx.getResources().getDisplayMetrics()));
            setPadding(0, 0, p, 0);
            setAlpha(0f);
            setVisibility(View.GONE);
        }

        private void read(Intent i) {
            if (i == null) return;
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
        }

        private void animateTo(float to, long ms) {
            if (anim != null) anim.cancel();
            if (to > 0f && getVisibility() != View.VISIBLE) setVisibility(View.VISIBLE);
            anim = android.animation.ValueAnimator.ofFloat(reveal, to);
            anim.setDuration(ms);
            anim.setInterpolator(new android.view.animation.DecelerateInterpolator());
            anim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(android.animation.ValueAnimator va) {
                    reveal = (Float) va.getAnimatedValue();
                    setAlpha(reveal);
                    requestLayout();
                }
            });
            anim.start();
        }

        private void hideNow() {
            if (anim != null) anim.cancel();
            open = false;
            reveal = 0f;
            setAlpha(0f);
            if (getVisibility() != View.GONE) setVisibility(View.GONE);
            requestLayout();
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, h);
            // width follows "reveal": zero while the panel is moving, so the header layout stays stock
            setMeasuredDimension(Math.round(getMeasuredWidth() * reveal), getMeasuredHeight());
        }

        private void sync() {
            try {
                if (!first && !forced && !battery.isShown()) return;
                forced = false;
                if (level >= 0) {
                    String s = level + "%";
                    if (!s.contentEquals(getText())) setText(s);
                }
                boolean bySetting = settingShowsPercent(getContext());
                boolean want = level >= 0 && enabled() && !bySetting && !systemShowsPercent(battery, this);
                if (bySetting || first) {        // system shows %: stay hidden at once
                    first = false;
                    pend = 0;
                    baseWant = want;
                    if (!want) hideNow();
                    return;
                }
                if (want == baseWant) { pend = 0; return; }
                if (++pend >= 2) {               // must stay changed for 2 checks: no flicker
                    pend = 0;
                    baseWant = want;
                    if (!want) hideNow();
                }
            } catch (Throwable ignored) { }
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            try {
                if (!registered) {
                    read(getContext().registerReceiver(rcv, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
                    registered = true;
                }
            } catch (Throwable ignored) { }
            try {
                getContext().getContentResolver().registerContentObserver(
                        android.provider.Settings.System.getUriFor("battery_indicator_style"), false, styleObs);
            } catch (Throwable ignored) { }
            removeCallbacks(loop);
            removeCallbacks(fast);
            sync();
            postDelayed(loop, 1000);
            post(fast);
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            removeCallbacks(loop);
            removeCallbacks(fast);
            if (anim != null) anim.cancel();
            try { getContext().getContentResolver().unregisterContentObserver(styleObs); } catch (Throwable ignored) { }
            try {
                if (registered) getContext().unregisterReceiver(rcv);
            } catch (Throwable ignored) { }
            registered = false;
        }
    }
}

#!/system/bin/sh
# /data/adb/hyperos_enhanced.conf is left in place on purpose (same as the
# full suite's own behavior) so a reinstall restores your last visual
# settings; delete it manually if you want a clean slate.

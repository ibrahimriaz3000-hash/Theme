#!/system/bin/sh
MODDIR=${0%/*}

# Wait until boot fully completes
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done

# ===========================================================================
# Blur + GoodLooks color engine - runs as its own self-contained process,
# exactly as it does inside Ultimate HyperOS Suite (own boot-wait, own
# sanitize/clamp/apply loop). The bridge keeps flags/*.flag as the single
# source of truth for these settings, exactly as before.
# ===========================================================================
[ -f "$MODDIR/visual_engine.sh" ]       && sh "$MODDIR/visual_engine.sh"       >/dev/null 2>&1 &
[ -f "$MODDIR/visual_flags_bridge.sh" ] && sh "$MODDIR/visual_flags_bridge.sh" >/dev/null 2>&1 &

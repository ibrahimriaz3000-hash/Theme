(function () {
  "use strict";

  var MOD_DIR = "/data/adb/modules/hyperos_goodlooks_colorguard";
  var FLAG_DIR = MOD_DIR + "/flags";
  var FORCE_FILE = MOD_DIR + "/force_refresh_visual";
  var CACHE_KEY = "gl_colorguard_cache_v1";
  var POLL_MS = 4000;
  var WRITE_GUARD_MS = 2500;

  var manifest = null;
  var flagsById = {};
  var values = {};        // last value confirmed from disk
  var loaded = false;     // controls stay locked until a real read succeeds
  var bridgeOk = false;
  var dragging = {};      // id -> true while a slider is held
  var inflight = {};      // id -> true while a write is running
  var pending = {};       // id -> newest value waiting behind an inflight write
  var guardUntil = {};    // id -> timestamp; don't overwrite UI right after a write
  var readBusy = false;

  function $(id) { return document.getElementById(id); }
  function q(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }

  function toast(msg) {
    var t = $("toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove("show"); }, 1800);
  }

  function setChip(text, cls) {
    var c = $("bridgeChip");
    c.textContent = text;
    c.className = "chip" + (cls ? " " + cls : "");
  }

  // ---- number helpers -----------------------------------------------------
  function decimalsOf(step) {
    var s = String(step);
    var i = s.indexOf(".");
    return i < 0 ? 0 : s.length - i - 1;
  }
  function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, n)); }
  function shown(f, raw) {           // what the label next to a slider says
    var n = parseFloat(raw);
    if (isNaN(n)) return "–";
    return String(parseFloat(n.toFixed(decimalsOf(f.step || 1))));
  }
  function forDisk(f, raw) {         // what gets written to the .flag file
    if (f.type !== "range") return String(raw).trim() === "1" ? "1" : "0";
    var n = parseFloat(raw);
    if (isNaN(n)) return null;
    n = clamp(n, f.min, f.max);
    return n.toFixed(decimalsOf(f.step || 1));
  }

  // ---- cache (only used to paint the UI instantly; disk stays the truth) --
  function loadCache() {
    try { return JSON.parse(localStorage.getItem(CACHE_KEY) || "{}") || {}; }
    catch (e) { return {}; }
  }
  function saveCache() {
    try { localStorage.setItem(CACHE_KEY, JSON.stringify(values)); } catch (e) {}
  }

  // ---- UI build ------------------------------------------------------------
  function buildGroup() {
    var groups = $("groups");
    groups.innerHTML = "";
    var g = manifest.groups[0];
    var card = document.createElement("div");
    card.className = "card locked";
    card.id = "flagCard";
    g.flags.forEach(function (f) {
      flagsById[f.id] = f;
      card.appendChild(buildRow(f));
    });
    groups.appendChild(card);
  }

  function buildRow(f) {
    var row = document.createElement("div");
    row.className = "frow";
    var meta = document.createElement("div");
    meta.className = "fmeta";
    var l = document.createElement("div"); l.className = "flabel"; l.textContent = f.label;
    var d = document.createElement("div"); d.className = "fdesc"; d.textContent = f.desc;
    meta.appendChild(l); meta.appendChild(d);
    row.appendChild(meta);
    row.appendChild(f.type === "range" ? buildRange(f) : buildToggle(f));
    return row;
  }

  function buildToggle(f) {
    var sw = document.createElement("label");
    sw.className = "switch";
    var input = document.createElement("input");
    input.type = "checkbox";
    input.id = "input-" + f.id;
    input.disabled = true;
    input.onchange = function () { commit(f, input.checked ? "1" : "0"); };
    var s = document.createElement("span");
    s.className = "slider";
    sw.appendChild(input); sw.appendChild(s);
    return sw;
  }

  function buildRange(f) {
    var wrap = document.createElement("div");
    wrap.className = "rangewrap";
    var input = document.createElement("input");
    input.type = "range";
    input.className = "range";
    input.id = "input-" + f.id;
    input.min = f.min; input.max = f.max; input.step = f.step || 1;
    input.disabled = true;
    var val = document.createElement("div");
    val.className = "rangeval";
    val.id = "val-" + f.id;
    val.textContent = "–";

    function down() { dragging[f.id] = true; }
    function up() { setTimeout(function () { dragging[f.id] = false; }, 300); }
    input.addEventListener("pointerdown", down);
    input.addEventListener("touchstart", down, { passive: true });
    input.addEventListener("pointerup", up);
    input.addEventListener("pointercancel", up);
    input.addEventListener("touchend", up);
    input.addEventListener("input", function () { val.textContent = shown(f, input.value); });
    input.addEventListener("change", function () { commit(f, input.value); });

    wrap.appendChild(input); wrap.appendChild(val);
    return wrap;
  }

  function lockUi(locked) {
    var card = $("flagCard");
    if (!card) return;
    if (locked) card.classList.add("locked"); else card.classList.remove("locked");
    var inputs = card.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) inputs[i].disabled = locked;
  }

  function paint(id, raw) {
    var f = flagsById[id];
    if (!f) return;
    var input = $("input-" + id);
    if (!input) return;
    if (f.type === "range") {
      var n = parseFloat(raw);
      if (isNaN(n)) return;
      input.value = clamp(n, f.min, f.max);
      $("val-" + id).textContent = shown(f, n);
    } else {
      input.checked = String(raw).trim() === "1";
    }
  }

  function paintAll(force) {
    var now = Date.now();
    Object.keys(values).forEach(function (id) {
      if (!force && (dragging[id] || inflight[id] || (guardUntil[id] || 0) > now)) return;
      paint(id, values[id]);
    });
  }

  // ---- reading -------------------------------------------------------------
  // One robust command: newline-separated "id=value" lines, no fragile
  // string joining, works in ash/mksh/toybox sh.
  var READ_CMD = "cd " + q(FLAG_DIR) + " 2>/dev/null && for f in *.flag; do " +
                 "[ -f \"$f\" ] && printf '%s=%s\\n' \"${f%.flag}\" \"$(cat \"$f\" 2>/dev/null)\"; done; true";

  function parseLines(out) {
    var got = {}, n = 0;
    String(out || "").split(/\r?\n/).forEach(function (line) {
      var m = /^([a-z0-9_]+)=(.*)$/.exec(line.trim());
      if (m && flagsById[m[1]]) { got[m[1]] = m[2].trim(); n++; }
    });
    return n ? got : null;
  }

  function readAll(force) {
    if (!bridgeOk || !manifest || readBusy) return Promise.resolve(false);
    readBusy = true;
    return KSU.exec(READ_CMD).then(function (res) {
      var got = parseLines(res.stdout);
      if (!got) return false;
      Object.keys(got).forEach(function (id) { values[id] = got[id]; });
      saveCache();
      paintAll(force);
      if (!loaded) { loaded = true; lockUi(false); }
      setChip("bridge OK", "");
      return true;
    }).catch(function () { return false; })
      .then(function (ok) { readBusy = false; return ok; });
  }

  function initialLoad(attempt) {
    attempt = attempt || 0;
    readAll(true).then(function (ok) {
      if (ok) return;
      if (attempt < 8) {
        setChip("loading…", "warn");
        setTimeout(function () { initialLoad(attempt + 1); }, 500 + attempt * 300);
      } else {
        setChip("read failed – tap Refresh", "bad");
      }
    });
  }

  // ---- writing -------------------------------------------------------------
  function commit(f, raw) {
    if (!loaded || !bridgeOk) { toast("Not ready yet"); return; }
    var v = forDisk(f, raw);
    if (v === null) { toast("Invalid value"); paint(f.id, values[f.id]); return; }
    if (inflight[f.id]) { pending[f.id] = v; return; }
    doWrite(f, v);
  }

  function doWrite(f, v) {
    inflight[f.id] = true;
    guardUntil[f.id] = Date.now() + WRITE_GUARD_MS;
    var file = FLAG_DIR + "/" + f.id + ".flag";
    var tmp = file + ".tmp";
    // atomic replace (never leaves an empty/half-written flag for the engine),
    // wake the bridge, then echo the value actually on disk for verification
    var cmd = "printf '%s' " + q(v) + " > " + q(tmp) + " && mv -f " + q(tmp) + " " + q(file) +
              " && chmod 0644 " + q(file) + " ; touch " + q(FORCE_FILE) + " ; cat " + q(file);
    KSU.exec(cmd).then(function (res) {
      var back = String(res.stdout || "").trim();
      if (back === v) {
        values[f.id] = v;
        saveCache();
        toast(f.label + " → " + (f.type === "range" ? shown(f, v) : (v === "1" ? "ON" : "OFF")));
      } else {
        toast("Save failed: " + f.label);
        paint(f.id, values[f.id]);
      }
    }).catch(function () {
      toast("Save failed: " + f.label);
      paint(f.id, values[f.id]);
    }).then(function () {
      inflight[f.id] = false;
      guardUntil[f.id] = Date.now() + WRITE_GUARD_MS;
      if (pending[f.id] !== undefined) {
        var nv = pending[f.id]; delete pending[f.id];
        if (nv !== values[f.id]) doWrite(f, nv);
      }
    });
  }

  // ---- lifecycle -------------------------------------------------------------
  function anyBusy() {
    var k;
    for (k in dragging) if (dragging[k]) return true;
    for (k in inflight) if (inflight[k]) return true;
    return false;
  }

  function init() {
    bridgeOk = !!(window.ksu && typeof window.ksu.exec === "function");
    if (!bridgeOk) setChip("bridge unavailable", "bad"); else setChip("loading…", "warn");

    $("refreshBtn").onclick = function () {
      if (!bridgeOk) { toast("Bridge unavailable"); return; }
      readAll(true).then(function (ok) { toast(ok ? "Refreshed" : "Read failed"); if (!ok && !loaded) initialLoad(0); });
    };

    fetch("flags_manifest.json", { cache: "no-store" }).then(function (r) {
      if (!r.ok) throw new Error("http " + r.status);
      return r.json();
    }).then(function (m) {
      manifest = m;
      buildGroup();
      var cache = loadCache();               // instant paint, still locked
      Object.keys(cache).forEach(function (id) { if (flagsById[id]) { values[id] = cache[id]; } });
      paintAll(true);
      if (bridgeOk) {
        initialLoad(0);
        setInterval(function () { if (loaded && !anyBusy() && !document.hidden) readAll(false); }, POLL_MS);
        document.addEventListener("visibilitychange", function () { if (!document.hidden) readAll(false); });
        window.addEventListener("focus", function () { readAll(false); });
      }
    }).catch(function () { toast("Could not load flags_manifest.json"); });
  }

  document.addEventListener("DOMContentLoaded", init);
})();

// Bundled KernelSU WebUI bridge (compatible with KernelSU's WebViewInterface).
// Loaded as a plain <script>, so it exposes a global `KSU` object instead of
// ES module exports (the previous version used `export function`, which
// throws in a non-module <script> tag and silently breaks every exec() call).
(function (global) {
  let callbackCounter = 0;
  function unique(prefix) {
    return prefix + '_callback_' + Date.now() + '_' + (callbackCounter++);
  }

  function exec(command, options) {
    options = options || {};
    return new Promise(function (resolve, reject) {
      if (!global.ksu || typeof global.ksu.exec !== 'function') {
        reject(new Error('KernelSU WebUI bridge is unavailable'));
        return;
      }
      const name = unique('exec');
      global[name] = function (errno, stdout, stderr) {
        try {
          resolve({ errno: errno, stdout: stdout || '', stderr: stderr || '' });
        } finally {
          try { delete global[name]; } catch (_) {}
        }
      };
      try {
        global.ksu.exec(command, JSON.stringify(options), name);
      } catch (e) {
        try { delete global[name]; } catch (_) {}
        reject(e);
      }
    });
  }

  function toast(message) {
    try {
      if (global.ksu && typeof global.ksu.toast === 'function') {
        global.ksu.toast(String(message));
      }
    } catch (_) {}
  }

  global.KSU = { exec: exec, toast: toast };
})(window);

#!/system/bin/sh
# HyperOS Enhanced Suite - late-start service.
# Merges HyperOS Expert (blur flags) + HyperOS GoodLooks (color matrix,
# Ultimate Black Almond) into one boot service so there is exactly one
# owner of SurfaceFlinger calls and one polling loop on the device.

MODDIR=${0%/*}
FLAG_DIR="$MODDIR/flags"
CONF=/data/adb/hyperos_enhanced.conf
STATUS=/data/adb/hyperos_enhanced.status
ALMOND_STATE=/data/adb/hyperos_enhanced.almond_state
LAST_APPLY_HASH=/data/adb/hyperos_enhanced.last_hash

# ---------------------------------------------------------------------------
# Persistence fix: Contrast/Saturation/Red/Green/Blue/Almond-Intensity are
# WebUI range sliders whose single source of truth is $FLAG_DIR/<id>.flag
# (exactly like every other flag in this suite - never overwritten if it
# already exists, so it always survives a reboot on its own). Previously
# this engine only read them via /data/adb/hyperos_enhanced.conf, which the
# bridge (visual_flags_bridge.sh) mirrors the flag files into on its own
# ~4s cycle - a separate process/file. Reading the .flag files directly
# here removes that extra hop so these six sliders can never be one cycle
# behind (or read a stale value) right after boot. Nothing else about
# CONF or the bridge changes; every other Engine D setting still comes
# from CONF exactly as before.
# ---------------------------------------------------------------------------
read_num_flag() {
    f="$FLAG_DIR/$1.flag"
    [ -f "$f" ] || return 1
    v=$(cat "$f" 2>/dev/null)
    case "$v" in ''|*[!0-9.]*) return 1 ;; esac
    printf '%s' "$v"
}

apply_flag_overrides() {
    v=$(read_num_flag contrast)          && CONTRAST="$v"
    v=$(read_num_flag saturation)        && SATURATION="$v"
    v=$(read_num_flag tint_red)          && TINT_R="$v"
    v=$(read_num_flag tint_green)        && TINT_G="$v"
    v=$(read_num_flag tint_blue)         && TINT_B="$v"
    v=$(read_num_flag almond_intensity)  && ALMOND_INTENSITY="$v"
}

# Late-start service is non-blocking in Magisk; wait without holding boot.
BOOT_WAIT=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$BOOT_WAIT" -lt 60 ]; do
    sleep 1
    BOOT_WAIT=$((BOOT_WAIT + 1))
done

[ -f "$CONF" ] || cp "$MODDIR/hyperos_enhanced.conf" "$CONF" 2>/dev/null
chmod 0644 "$CONF" 2>/dev/null

# Let SurfaceFlinger settle before the first apply.
sleep 8

clamp_num() {
    awk -v x="$1" -v lo="$2" -v hi="$3" 'BEGIN{
        if (x != x || x == "") x=lo
        if (x < lo) x=lo
        if (x > hi) x=hi
        printf "%.6f", x
    }'
}
clamp_int() { clamp_num "$1" "$2" "$3" | cut -d. -f1; }
bool01() { case "$1" in 1) echo 1;; *) echo 0;; esac; }

sanitize_config() {
    # Blur toggles - force to strict 0/1 so a corrupted config can't
    # produce anything other than the two known-good states.
    BLUR_BACKGROUND_SUPPORTED=$(bool01 "${BLUR_BACKGROUND_SUPPORTED:-1}")
    BLUR_STATUS_DEFAULT=$(bool01 "${BLUR_STATUS_DEFAULT:-1}")
    BLUR_NOISE_SUPPORTED=$(bool01 "${BLUR_NOISE_SUPPORTED:-1}")
    BLUR_SF_SUPPORTED=$(bool01 "${BLUR_SF_SUPPORTED:-1}")
    BLUR_SF_DISABLE=$(bool01 "${BLUR_SF_DISABLE:-0}")
    BLUR_DEBUG_SF_DISABLE=$(bool01 "${BLUR_DEBUG_SF_DISABLE:-0}")
    BLUR_MIUI_ENABLE=$(bool01 "${BLUR_MIUI_ENABLE:-1}")
    BLUR_CONTROL_ENABLE=$(bool01 "${BLUR_CONTROL_ENABLE:-1}")
    BLUR_SF_EXPENSIVE=$(bool01 "${BLUR_SF_EXPENSIVE:-0}")
    BLUR_RATIO=$(clamp_int "${BLUR_RATIO:-25}" 0 100)
    BLUR_VERSION=$(clamp_int "${BLUR_VERSION:-2}" 0 5)
    LOW_RAM_APPLY=$(bool01 "${LOW_RAM_APPLY:-0}")
    HG_LOW_RAM_THRESHOLD=$(clamp_int "${HG_LOW_RAM_THRESHOLD:-2}" 1 8)

    # Color matrix (same safe bounds as GoodLooks v2.6).
    CONTRAST=$(clamp_num "${CONTRAST:-2.0}" 1.0 8.0)
    TINT_R=$(clamp_num "${TINT_R:-1.0}" 0.3 2.0)
    TINT_G=$(clamp_num "${TINT_G:-1.0}" 0.3 2.0)
    TINT_B=$(clamp_num "${TINT_B:-1.0}" 0.3 2.0)
    SATURATION=$(clamp_num "${SATURATION:-1.6}" 1.0 8.0)
    BRIGHT=$(clamp_num "${BRIGHT:-1.0}" 0.3 1.0)
    BLACK=$(clamp_num "${BLACK:-0.0}" 0.0 0.3)
    BLACK_ENHANCE=$(clamp_num "${BLACK_ENHANCE:-0.0}" 0.0 2.0)
    COOL=$(clamp_num "${COOL:-0.0}" 0.0 6.0)
    INVERT=$(clamp_num "${INVERT:-0.0}" 0.0 1.0)
    case "$BOOST" in 1) BOOST=1;; *) BOOST=0;; esac
    INTERVAL=$(clamp_int "${BOOST_INTERVAL:-5}" 2 60)
    [ -n "$INTERVAL" ] || INTERVAL=5

    case "$HG_RESPONSIVE_MODE" in 0) HG_RESPONSIVE_MODE=0;; *) HG_RESPONSIVE_MODE=1;; esac
    case "$HG_DEDUP_APPLY" in 0) HG_DEDUP_APPLY=0;; *) HG_DEDUP_APPLY=1;; esac
    case "$HG_SF_GUARD" in 0) HG_SF_GUARD=0;; *) HG_SF_GUARD=1;; esac
    case "$HG_ADAPTIVE_DEBOUNCE" in 0) HG_ADAPTIVE_DEBOUNCE=0;; *) HG_ADAPTIVE_DEBOUNCE=1;; esac
    case "$HG_BOOST_KEEPALIVE" in 1) HG_BOOST_KEEPALIVE=1;; *) HG_BOOST_KEEPALIVE=0;; esac

    case "$ALMOND_AUTO" in 1) ALMOND_AUTO=1;; *) ALMOND_AUTO=0;; esac
    ALMOND_INTENSITY=$(clamp_num "${ALMOND_INTENSITY:-0.60}" 0.0 1.0)
    ALMOND_T_CONTRAST=$(clamp_num "${ALMOND_T_CONTRAST:-2.6}" 1.0 8.0)
    ALMOND_T_TINT_R=$(clamp_num "${ALMOND_T_TINT_R:-1.05}" 0.3 2.0)
    ALMOND_T_TINT_G=$(clamp_num "${ALMOND_T_TINT_G:-0.97}" 0.3 2.0)
    ALMOND_T_TINT_B=$(clamp_num "${ALMOND_T_TINT_B:-0.88}" 0.3 2.0)
    ALMOND_T_BLACK_ENHANCE=$(clamp_num "${ALMOND_T_BLACK_ENHANCE:-1.70}" 0.0 2.0)
    ALMOND_T_SATURATION=$(clamp_num "${ALMOND_T_SATURATION:-1.75}" 1.0 8.0)
}

compute_matrix() {
    awk -v c="$CONTRAST" -v tr="$TINT_R" -v tg="$TINT_G" -v tb="$TINT_B" \
        -v br="$BRIGHT" -v bl="$BLACK" -v ben="$BLACK_ENHANCE" -v cool="$COOL" -v inv="$INVERT" '
BEGIN{
    gr=(tr/c)*br; gg=(tg/c)*br; gb=(tb/c)*br
    cf_lin=cool/6.0; if(cf_lin<0)cf_lin=0; if(cf_lin>1)cf_lin=1
    cf=2*cf_lin-cf_lin*cf_lin
    gr=gr-0.65*cf; gb=gb+0.65*cf
    if(gr<0)gr=0; if(gr>3.0)gr=3.0
    if(gg<0)gg=0; if(gg>3.0)gg=3.0
    if(gb<0)gb=0; if(gb>3.0)gb=3.0
    min_gain=gr; if(gg<min_gain)min_gain=gg; if(gb<min_gain)min_gain=gb
    blk_ceiling=min_gain*0.92; if(blk_ceiling<0)blk_ceiling=0
    ben_norm=ben/2.0; if(ben_norm<0)ben_norm=0; if(ben_norm>1)ben_norm=1
    blk=bl+ben_norm*blk_ceiling
    if(blk<0)blk=0; if(blk>blk_ceiling)blk=blk_ceiling
    orr=-blk; ogg=-blk; obb=-blk
    inv_eff=2*inv-inv*inv; if(inv_eff<0)inv_eff=0; if(inv_eff>1)inv_eff=1
    k=1-2*inv_eff
    ngr=gr*k; ngg=gg*k; ngb=gb*k
    norr=orr*k+inv_eff; nogg=ogg*k+inv_eff; nobb=obb*k+inv_eff
    printf "%.4f %.4f %.4f %.4f %.4f %.4f", ngr, ngg, ngb, norr, nogg, nobb
}'
}

detect_dark_mode() {
    v=$(settings get secure ui_night_mode 2>/dev/null)
    case "$v" in 2) echo 1; return;; 1) echo 0; return;; esac
    m=$(cmd uimode night 2>/dev/null)
    case "$m" in *yes*) echo 1; return;; *no*) echo 0; return;; esac
    echo 0
}

apply_blur_flags() {
    b() { [ "$1" = "1" ] && echo "$2" || echo "$3"; }
    resetprop -n persist.sys.background_blur_supported      "$(b "$BLUR_BACKGROUND_SUPPORTED" true false)"  >/dev/null 2>&1
    resetprop -n persist.sys.background_blur_status_default "$(b "$BLUR_STATUS_DEFAULT" true false)"        >/dev/null 2>&1
    resetprop -n persist.sys.add_blurnoise_supported         "$(b "$BLUR_NOISE_SUPPORTED" true false)"       >/dev/null 2>&1
    resetprop -n ro.surface_flinger.supports_background_blur "$(b "$BLUR_SF_SUPPORTED" 1 0)"                 >/dev/null 2>&1
    resetprop -n persist.sys.sf.disable_blurs                "$(b "$BLUR_SF_DISABLE" 1 0)"                   >/dev/null 2>&1
    resetprop -n debug.sf.disable_blurs                      "$(b "$BLUR_DEBUG_SF_DISABLE" 1 0)"             >/dev/null 2>&1
    resetprop -n persist.sys.miui_blur_enable                "$(b "$BLUR_MIUI_ENABLE" true false)"           >/dev/null 2>&1
    resetprop -n persist.sys.blur.control.enable             "$(b "$BLUR_CONTROL_ENABLE" true false)"        >/dev/null 2>&1
    resetprop -n persist.sys.sf.blurs_are_expensive           "$(b "$BLUR_SF_EXPENSIVE" 1 0)"                >/dev/null 2>&1
    resetprop -n persist.sys.background_blur_version          "$BLUR_VERSION"                                >/dev/null 2>&1
    resetprop -n persist.sys.blur.ratio                       "$BLUR_RATIO"                                  >/dev/null 2>&1
    if [ "$LOW_RAM_APPLY" = "1" ]; then
        resetprop -n ro.config.low_ram.threshold_gb "$HG_LOW_RAM_THRESHOLD" >/dev/null 2>&1
    fi
}

apply_colors() {
    VALS=$(compute_matrix); set -- $VALS
    GR=$1; GG_=$2; GB=$3; OR=$4; OG=$5; OB=$6
    service call SurfaceFlinger 1022 f "$SATURATION" >/dev/null 2>&1
    resetprop -n persist.sys.sf.color_saturation "$SATURATION" >/dev/null 2>&1
    service call SurfaceFlinger 1015 i32 1 \
        f "$GR" f 0 f 0 f "$OR" \
        f 0 f "$GG_" f 0 f "$OG" \
        f 0 f 0 f "$GB" f "$OB" \
        f 0 f 0 f 0 f 1 >/dev/null 2>&1
}

apply_almond_live() {
    ai="$ALMOND_INTENSITY"
    _C=$(awk -v a="$CONTRAST" -v b="$ALMOND_T_CONTRAST" -v i="$ai" 'BEGIN{printf "%.6f", a*(1-i)+b*i}')
    _TR=$(awk -v a="$TINT_R" -v b="$ALMOND_T_TINT_R" -v i="$ai" 'BEGIN{printf "%.6f", a*(1-i)+b*i}')
    _TG=$(awk -v a="$TINT_G" -v b="$ALMOND_T_TINT_G" -v i="$ai" 'BEGIN{printf "%.6f", a*(1-i)+b*i}')
    _TB=$(awk -v a="$TINT_B" -v b="$ALMOND_T_TINT_B" -v i="$ai" 'BEGIN{printf "%.6f", a*(1-i)+b*i}')
    _BE=$(awk -v a="$BLACK_ENHANCE" -v b="$ALMOND_T_BLACK_ENHANCE" -v i="$ai" 'BEGIN{printf "%.6f", a*(1-i)+b*i}')
    _SAT=$(awk -v a="$SATURATION" -v b="$ALMOND_T_SATURATION" -v i="$ai" 'BEGIN{printf "%.6f", a*(1-i)+b*i}')
    _OC=$CONTRAST; _OTR=$TINT_R; _OTG=$TINT_G; _OTB=$TINT_B; _OBE=$BLACK_ENHANCE; _OSAT=$SATURATION
    CONTRAST=$_C; TINT_R=$_TR; TINT_G=$_TG; TINT_B=$_TB; BLACK_ENHANCE=$_BE; SATURATION=$_SAT
    apply_colors
    CONTRAST=$_OC; TINT_R=$_OTR; TINT_G=$_OTG; TINT_B=$_OTB; BLACK_ENHANCE=$_OBE; SATURATION=$_OSAT
}

write_status() {
    magisk_ver=$(magisk -v 2>/dev/null || echo "Not detected")
    magisk_code=$(magisk -V 2>/dev/null || echo "Unknown")
    root_state="Unavailable"; command -v su >/dev/null 2>&1 && root_state="Available"
    selinux=$(getenforce 2>/dev/null || echo "Unknown")
    boot=$(getprop sys.boot_completed 2>/dev/null || echo "Unknown")
    zygisk="Not detected"; [ -f /data/adb/magisk/zygisk ] && zygisk="Enabled"
    denylist="Not detected"; [ -f /data/adb/magisk/denylist ] && denylist="Detected"
    almond_state_now=0; [ -f "$ALMOND_STATE" ] && almond_state_now=$(cat "$ALMOND_STATE" 2>/dev/null)
    {
      printf 'module_version=%s\n' "$(sed -n 's/^version=//p' "$MODDIR/module.prop" | head -n 1)"
      printf 'magisk_version=%s\n' "$magisk_ver"
      printf 'magisk_code=%s\n' "$magisk_code"
      printf 'root=%s\n' "$root_state"
      printf 'selinux=%s\n' "$selinux"
      printf 'boot_completed=%s\n' "$boot"
      printf 'zygisk=%s\n' "$zygisk"
      printf 'denylist=%s\n' "$denylist"
      printf 'config=%s\n' "$([ -f "$CONF" ] && echo persistent || echo missing)"
      printf 'low_ram_apply=%s\n' "${LOW_RAM_APPLY:-0}"
      printf 'almond_auto=%s\n' "${ALMOND_AUTO:-0}"
      printf 'almond_state=%s\n' "$almond_state_now"
      printf 'updated=%s\n' "$(date +%s 2>/dev/null || echo 0)"
    } > "$STATUS"
    chmod 0644 "$STATUS" 2>/dev/null
}

# One-time boot reset+apply, exactly as v2.6/v2.7 did: covers ROMs whose
# compositor ignores the very first matrix if it "looks like" a no-op.
[ -f "$CONF" ] && . "$CONF" 2>/dev/null
apply_flag_overrides
sanitize_config
apply_blur_flags
service call SurfaceFlinger 1015 i32 0 >/dev/null 2>&1
apply_colors
write_status

(
    prev_hash=""
    while true; do
        [ -f "$CONF" ] && . "$CONF" 2>/dev/null
        apply_flag_overrides
        sanitize_config

        # Dedup: only re-issue SurfaceFlinger/resetprop calls when something
        # actually changed since the last cycle, so an idle device never
        # gets repeated no-op writes (HG_DEDUP_APPLY).
        cur_hash="$BLUR_BACKGROUND_SUPPORTED|$BLUR_STATUS_DEFAULT|$BLUR_NOISE_SUPPORTED|$BLUR_SF_SUPPORTED|$BLUR_SF_DISABLE|$BLUR_DEBUG_SF_DISABLE|$BLUR_MIUI_ENABLE|$BLUR_CONTROL_ENABLE|$BLUR_SF_EXPENSIVE|$BLUR_VERSION|$BLUR_RATIO|$LOW_RAM_APPLY|$HG_LOW_RAM_THRESHOLD|$CONTRAST|$TINT_R|$TINT_G|$TINT_B|$SATURATION|$BRIGHT|$BLACK|$BLACK_ENHANCE|$COOL|$INVERT|$ALMOND_AUTO|$ALMOND_INTENSITY"
        # Remember whether anything changed BEFORE prev_hash is refreshed
        # below - the Almond branch needs that answer, and previously it
        # compared the two hashes after they had already been made equal,
        # so slider/intensity changes never re-applied while Almond Auto
        # was on (until Dark Mode itself was toggled).
        hash_changed=0
        [ "$cur_hash" != "$prev_hash" ] && hash_changed=1
        if [ "$HG_DEDUP_APPLY" != "1" ] || [ "$hash_changed" = "1" ]; then
            apply_blur_flags
            if [ "$ALMOND_AUTO" = "1" ]; then
                : # Almond branch below owns the color apply this cycle.
            else
                apply_colors
            fi
            prev_hash="$cur_hash"
            echo "$prev_hash" > "$LAST_APPLY_HASH" 2>/dev/null
        fi

        if [ "$ALMOND_AUTO" = "1" ]; then
            dark_now=$(detect_dark_mode)
            prev_state="0"; [ -f "$ALMOND_STATE" ] && prev_state=$(cat "$ALMOND_STATE" 2>/dev/null)
            if [ "$dark_now" != "$prev_state" ] || [ "$hash_changed" = "1" ]; then
                if [ "$dark_now" = "1" ]; then apply_almond_live; else apply_colors; fi
                echo "$dark_now" > "$ALMOND_STATE" 2>/dev/null
            fi
        fi

        write_status
        sleep "$INTERVAL"

        if [ "$BOOST" = "1" ] && [ "$HG_BOOST_KEEPALIVE" = "1" ]; then
            # Anti-tamper keepalive only: reasserts the exact value already
            # on screen, never adds boost or touches the matrix.
            service call SurfaceFlinger 1022 f "$SATURATION" >/dev/null 2>&1
            resetprop -n persist.sys.sf.color_saturation "$SATURATION" >/dev/null 2>&1
        fi
    done
) &
exit 0

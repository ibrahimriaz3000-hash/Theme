ui_print " "
ui_print "============================================"
ui_print " HyperOS GoodLooks Color Guard (standalone)"
ui_print " 12 flags, live toggle, no reboot"
ui_print "============================================"

REQUIRED_FILES="module.prop service.sh uninstall.sh \
visual_engine.sh visual_flags_bridge.sh hyperos_enhanced.conf \
webroot/index.html webroot/ksu.js webroot/app.js webroot/flags_manifest.json"

for f in $REQUIRED_FILES; do
  if [ ! -f "$MODPATH/$f" ]; then
    ui_print "MISS $f"
    abort "Required file missing: $f"
  fi
done

# Upgrade-safe: keep the user's current slider/toggle values if an older copy
# of this module is already installed (Magisk replaces the whole module folder
# on update, which would otherwise reset every flag to its default).
OLD_FLAGS="/data/adb/modules/hyperos_goodlooks_colorguard/flags"
if [ -d "$OLD_FLAGS" ]; then
  for old in "$OLD_FLAGS"/*.flag; do
    [ -f "$old" ] || continue
    name=${old##*/}
    [ -f "$MODPATH/flags/$name" ] || continue
    val=$(cat "$old" 2>/dev/null)
    case "$val" in ''|*[!0-9.]*) continue ;; esac
    printf '%s' "$val" > "$MODPATH/flags/$name"
  done
  ui_print "OK   previous flag values kept"
fi

flag_count=$(ls "$MODPATH/flags/"*.flag 2>/dev/null | wc -l)
expected_count=$(grep -c '"label":' "$MODPATH/webroot/flags_manifest.json" 2>/dev/null)
case "$expected_count" in ''|*[!0-9]*) expected_count=$flag_count;; esac
[ "$flag_count" -eq "$expected_count" ] || abort "Expected $expected_count flag files, found $flag_count - aborting install."

ui_print "OK   $flag_count flags packaged with your current values"
ui_print "============================================"
ui_print " "

#!/system/bin/sh
# ---------------------------------------------------------------------------
# Visual Flags Bridge - Engine D (HyperOS Enhanced Suite: Blur + GoodLooks)
#
# Every other guard in this suite is switched by a single file under
# $MODDIR/flags/<id>.flag, edited live from the WebUI. Engine D's own
# service (visual_engine.sh) instead reads its settings from
# /data/adb/hyperos_enhanced.conf, with its own clamping/sanitizing logic
# that we do not want to duplicate.
#
# This bridge keeps both worlds honest: $MODDIR/flags/<id>.flag stays the
# single source of truth (exactly like every other flag in this suite), and
# this loop mirrors it into hyperos_enhanced.conf every few seconds.
# visual_engine.sh then re-reads that conf file, sanitizes/clamps it, and
# applies it on its own existing cadence - nothing here talks to
# SurfaceFlinger or resetprop directly, so there is exactly one owner of
# those calls.
# ---------------------------------------------------------------------------

MODDIR=${0%/*}
FLAG_DIR="$MODDIR/flags"
CONF=/data/adb/hyperos_enhanced.conf
BRIDGE_INTERVAL=4

BOOL_MAP="blur_background_supported:BLUR_BACKGROUND_SUPPORTED
blur_status_default:BLUR_STATUS_DEFAULT
blur_noise_supported:BLUR_NOISE_SUPPORTED
blur_sf_supported:BLUR_SF_SUPPORTED
blur_sf_disable:BLUR_SF_DISABLE
blur_debug_sf_disable:BLUR_DEBUG_SF_DISABLE
blur_miui_enable:BLUR_MIUI_ENABLE
blur_control_enable:BLUR_CONTROL_ENABLE
blur_sf_expensive:BLUR_SF_EXPENSIVE
hg_responsive_mode:HG_RESPONSIVE_MODE
hg_dedup_apply:HG_DEDUP_APPLY
hg_sf_guard:HG_SF_GUARD
hg_adaptive_debounce:HG_ADAPTIVE_DEBOUNCE
hg_boost_keepalive:HG_BOOST_KEEPALIVE
almond_auto:ALMOND_AUTO
low_ram_apply:LOW_RAM_APPLY"

NUM_MAP="blur_ratio:BLUR_RATIO
contrast:CONTRAST
saturation:SATURATION
almond_intensity:ALMOND_INTENSITY
tint_red:TINT_R
tint_green:TINT_G
tint_blue:TINT_B"

wait_for_conf() {
  n=0
  while [ ! -f "$CONF" ] && [ "$n" -lt 90 ]; do
    [ -f "$MODDIR/hyperos_enhanced.conf" ] && cp "$MODDIR/hyperos_enhanced.conf" "$CONF" 2>/dev/null
    sleep 1
    n=$((n+1))
  done
  [ -f "$CONF" ] || { [ -f "$MODDIR/hyperos_enhanced.conf" ] && cp "$MODDIR/hyperos_enhanced.conf" "$CONF" 2>/dev/null; }
}

set_conf_key() {
  key="$1"; val="$2"
  [ -f "$CONF" ] || return
  if grep -q "^${key}=" "$CONF" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${val}|" "$CONF" 2>/dev/null
  else
    echo "${key}=${val}" >> "$CONF"
  fi
}

sync_once() {
  [ -f "$CONF" ] || return
  printf '%s\n' "$BOOL_MAP" | while IFS=: read -r id key; do
    [ -n "$id" ] || continue
    f="$FLAG_DIR/${id}.flag"
    [ -f "$f" ] || continue
    v=$(cat "$f" 2>/dev/null)
    case "$v" in 1) sv=1 ;; *) sv=0 ;; esac
    cur=$(grep "^${key}=" "$CONF" 2>/dev/null | tail -n1 | cut -d= -f2-)
    [ "$cur" = "$sv" ] || set_conf_key "$key" "$sv"
  done
  printf '%s\n' "$NUM_MAP" | while IFS=: read -r id key; do
    [ -n "$id" ] || continue
    f="$FLAG_DIR/${id}.flag"
    [ -f "$f" ] || continue
    v=$(cat "$f" 2>/dev/null)
    case "$v" in ''|*[!0-9.]*) continue ;; esac
    cur=$(grep "^${key}=" "$CONF" 2>/dev/null | tail -n1 | cut -d= -f2-)
    [ "$cur" = "$v" ] || set_conf_key "$key" "$v"
  done
}

wait_for_conf
while true; do
  sync_once
  rm -f "$MODDIR/force_refresh_visual"
  n=0
  while [ "$n" -lt "$BRIDGE_INTERVAL" ]; do
    [ -f "$MODDIR/force_refresh_visual" ] && break
    sleep 1
    n=$((n+1))
  done
done

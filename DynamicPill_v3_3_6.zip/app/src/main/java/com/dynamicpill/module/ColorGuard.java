package com.dynamicpill.module;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * HyperOS GoodLooks Color Guard (root part).
 *
 * The unmodified Magisk/KernelSU module (assets/colorguard) is installed into
 * /data/adb/modules by this app through "su", so its engine keeps running at every boot.
 * The settings screen only edits the module's flags/*.flag files; the engine applies them live.
 */
public final class ColorGuard {

    public static final String MODID = "hyperos_goodlooks_colorguard";
    private static final String MODDIR = "/data/adb/modules/" + MODID;

    public interface ReadyListener {
        /** Called on the main thread. values == null means root / install failed (see error). */
        void onResult(Map<String, String> values, String error);
    }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Map<String, String> PENDING = new LinkedHashMap<>();
    private static final long DEBOUNCE_MS = 200;
    private static Context appCtx;
    private static long lastToast;

    private static final Runnable FLUSH = new Runnable() {
        @Override
        public void run() {
            flushNow();
        }
    };

    private ColorGuard() {
    }

    private static class Result {
        int code;
        String out = "";
        String err = "";
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    /** Installs / updates the module through root, starts the engine if needed and reads all flags. */
    public static void start(Context ctx, final ReadyListener l) {
        appCtx = ctx.getApplicationContext();
        IO.execute(new Runnable() {
            @Override
            public void run() {
                Map<String, String> values = null;
                String error = null;
                try {
                    values = installAndRead();
                    if (values.isEmpty()) {
                        values = null;
                        error = "Color Guard: could not read flags";
                    }
                } catch (Exception e) {
                    error = "Root not available: " + e.getMessage();
                }
                final Map<String, String> v = values;
                final String err = error;
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        l.onResult(v, err);
                    }
                });
            }
        });
    }

    /** Queue a flag value; written (all pending flags in one root call) 200 ms after the last change. */
    public static void queue(String id, String value) {
        synchronized (PENDING) {
            PENDING.put(id, value);
        }
        MAIN.removeCallbacks(FLUSH);
        MAIN.postDelayed(FLUSH, DEBOUNCE_MS);
    }

    /** Write whatever is pending right now (also called from onPause so nothing is lost). */
    public static void flushNow() {
        MAIN.removeCallbacks(FLUSH);
        final Map<String, String> snap;
        synchronized (PENDING) {
            if (PENDING.isEmpty()) return;
            snap = new HashMap<>(PENDING);
            PENDING.clear();
        }
        IO.execute(new Runnable() {
            @Override
            public void run() {
                StringBuilder sb = new StringBuilder();
                sb.append("M='").append(MODDIR).append("'\n");
                sb.append("[ -d \"$M/flags\" ] || exit 4\n");
                for (Map.Entry<String, String> e : snap.entrySet()) {
                    String id = e.getKey();
                    String v = e.getValue();
                    if (!id.matches("[a-z0-9_]+") || !v.matches("[0-9.]+")) continue;
                    String f = "\"$M/flags/" + id + ".flag\"";
                    sb.append("printf '%s' '").append(v).append("' > ").append(f).append(".tmp")
                      .append(" && mv -f ").append(f).append(".tmp ").append(f)
                      .append(" && chmod 0644 ").append(f).append("\n");
                }
                sb.append("touch \"$M/force_refresh_visual\"\n");
                try {
                    Result r = runSu(sb.toString());
                    if (r.code != 0) toast("Color Guard: save failed (root / module missing)");
                } catch (Exception ex) {
                    toast("Color Guard: root not available");
                }
            }
        });
    }

    // ------------------------------------------------------------------
    // Install + read
    // ------------------------------------------------------------------
    private static Map<String, String> installAndRead() throws Exception {
        File src = new File(appCtx.getCacheDir(), "colorguard_src");
        deleteRec(src);
        copyAsset(appCtx.getAssets(), "colorguard", src);

        int ver = readVersionCode(new File(src, "module.prop"));
        SharedPreferences sp = appCtx.getSharedPreferences("colorguard", Context.MODE_PRIVATE);
        boolean changed = sp.getInt("ver", -1) != ver;

        String script =
            "SRC='" + src.getAbsolutePath() + "'\n"
          + "M=" + MODDIR + "\n"
          + "RESTART=" + (changed ? "1" : "0") + "\n"
          + "mkdir -p \"$M/flags\" || exit 2\n"
          + "for f in \"$SRC\"/*; do\n"
          + "  b=${f##*/}\n"
          + "  [ \"$b\" = flags ] && continue\n"
          + "  rm -rf \"$M/$b\"\n"
          + "  cp -rf \"$f\" \"$M/$b\" || exit 3\n"
          + "done\n"
          + "cp -n \"$SRC\"/flags/* \"$M/flags/\" >/dev/null 2>&1\n"
          + "chown -R 0:0 \"$M\" >/dev/null 2>&1\n"
          + "find \"$M\" -type d -exec chmod 755 {} + >/dev/null 2>&1\n"
          + "find \"$M\" -type f -exec chmod 644 {} + >/dev/null 2>&1\n"
          + "chmod 755 \"$M\"/*.sh \"$M/META-INF/com/google/android/update-binary\" >/dev/null 2>&1\n"
          + "restorecon -R \"$M\" >/dev/null 2>&1\n"
          + "for f in \"$M\"/flags/*.flag; do\n"
          + "  [ -f \"$f\" ] || continue\n"
          + "  n=${f##*/}\n"
          + "  printf 'CGFLAG:%s=%s\\n' \"${n%.flag}\" \"$(cat \"$f\")\"\n"
          + "done\n"
          + "RUNNING=$(pgrep -f \"$M/visual_engine.sh\" | head -n1)\n"
          + "if [ \"$RESTART\" = 1 ] || [ -z \"$RUNNING\" ]; then\n"
          + "  pkill -f \"$M/visual_engine.sh\" >/dev/null 2>&1\n"
          + "  pkill -f \"$M/visual_flags_bridge.sh\" >/dev/null 2>&1\n"
          + "  sleep 1\n"
          + "  if command -v setsid >/dev/null 2>&1; then\n"
          + "    setsid nohup sh \"$M/service.sh\" </dev/null >/dev/null 2>&1 &\n"
          + "  else\n"
          + "    nohup sh \"$M/service.sh\" </dev/null >/dev/null 2>&1 &\n"
          + "  fi\n"
          + "fi\n"
          + "exit 0\n";

        Result r = runSu(script);
        if (r.code != 0) {
            throw new IOException("install failed (code " + r.code + ")");
        }
        sp.edit().putInt("ver", ver).apply();

        Map<String, String> values = new HashMap<>();
        for (String line : r.out.split("\\r?\\n")) {
            line = line.trim();
            if (!line.startsWith("CGFLAG:")) continue;
            int eq = line.indexOf('=');
            if (eq < 8) continue;
            values.put(line.substring(7, eq), line.substring(eq + 1).trim());
        }
        return values;
    }

    // ------------------------------------------------------------------
    // Root shell
    // ------------------------------------------------------------------
    private static Thread reader(final InputStream in, final StringBuilder sink) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    byte[] buf = new byte[4096];
                    int n;
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    while ((n = in.read(buf)) > 0) {
                        bos.write(buf, 0, n);
                    }
                    sink.append(new String(bos.toByteArray(), StandardCharsets.UTF_8));
                } catch (IOException ignored) {
                }
            }
        });
        t.start();
        return t;
    }

    private static Result runSu(String cmd) throws Exception {
        Process p = new ProcessBuilder("su").start();
        StringBuilder o = new StringBuilder();
        StringBuilder e = new StringBuilder();
        Thread to = reader(p.getInputStream(), o);
        Thread te = reader(p.getErrorStream(), e);

        OutputStream os = p.getOutputStream();
        os.write((cmd + "\nexit $?\n").getBytes(StandardCharsets.UTF_8));
        os.flush();
        os.close();

        boolean done = p.waitFor(30, TimeUnit.SECONDS);
        if (!done) {
            p.destroy();
        }
        to.join(2000);
        te.join(2000);

        Result r = new Result();
        r.code = done ? p.exitValue() : 124;
        r.out = o.toString();
        r.err = e.toString();
        return r;
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    private static void toast(final String msg) {
        long now = System.currentTimeMillis();
        if (now - lastToast < 3000 || appCtx == null) return;
        lastToast = now;
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static int readVersionCode(File prop) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(prop));
            String line;
            try {
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("versionCode=")) {
                        return Integer.parseInt(line.substring(12).trim());
                    }
                }
            } finally {
                br.close();
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    private static void copyAsset(AssetManager am, String path, File dest) throws IOException {
        String[] kids = am.list(path);
        if (kids != null && kids.length > 0) {
            dest.mkdirs();
            for (String k : kids) {
                copyAsset(am, path + "/" + k, new File(dest, k));
            }
            return;
        }
        File parent = dest.getParentFile();
        if (parent != null) parent.mkdirs();
        try {
            InputStream in = am.open(path);
            OutputStream out = new FileOutputStream(dest);
            try {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
            } finally {
                in.close();
                out.close();
            }
        } catch (FileNotFoundException e) {
            dest.mkdirs();
        }
    }

    private static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteRec(k);
        }
        f.delete();
    }
}

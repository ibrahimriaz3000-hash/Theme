package com.dynamicpill.module;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * HyperOS Monet Project (bundled, unmodified zip in assets/monet).
 * The zip is installed through the root manager's own installer (Magisk / KernelSU / APatch),
 * so the module's install script runs exactly as when flashing it by hand. Reboot afterwards.
 */
final class MonetModule {
    static final String MODID = "HyperOSMonetProject";
    private static final String ASSET = "monet/MonetProject-HyperOS.zip";

    private MonetModule() { }

    /** Blocking. Returns null on success, otherwise an error text. Call from a background thread. */
    static String install(Context ctx) {
        try {
            File zip = new File(ctx.getCacheDir(), "MonetProject-HyperOS.zip");
            InputStream in = ctx.getAssets().open(ASSET);
            OutputStream out = new FileOutputStream(zip);
            try {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                in.close();
                out.close();
            }
            zip.setReadable(true, false);
            String z = zip.getAbsolutePath();
            String script =
                  "Z='" + z + "'\n"
                + "cp -f \"$Z\" /data/local/tmp/monet_install.zip || exit 5\n"
                + "chmod 644 /data/local/tmp/monet_install.zip\n"
                + "Z=/data/local/tmp/monet_install.zip\n"
                + "if command -v magisk >/dev/null 2>&1; then magisk --install-module \"$Z\"; R=$?\n"
                + "elif [ -x /data/adb/ksud ]; then /data/adb/ksud module install \"$Z\"; R=$?\n"
                + "elif [ -x /data/adb/apd ]; then /data/adb/apd module install \"$Z\"; R=$?\n"
                + "else R=127; fi\n"
                + "rm -f \"$Z\"\n"
                + "exit $R\n";
            Process p = new ProcessBuilder("su").start();
            OutputStream os = p.getOutputStream();
            os.write(script.getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
            // drain output so the installer never blocks on a full pipe
            final InputStream o = p.getInputStream();
            Thread t = new Thread(() -> {
                try { byte[] b = new byte[4096]; while (o.read(b) > 0) { } } catch (Exception ignored) { }
            });
            t.start();
            if (!p.waitFor(180, TimeUnit.SECONDS)) {
                p.destroy();
                return "Install timed out";
            }
            int code = p.exitValue();
            if (code == 127) return "No Magisk / KernelSU / APatch found";
            if (code != 0) return "Installer failed (code " + code + ")";
            return null;
        } catch (Throwable e) {
            return "Root not available: " + e.getMessage();
        }
    }

    /** Blocking. True when the module folder exists in /data/adb/modules (or is queued for next boot). */
    static boolean isInstalled() {
        try {
            Process p = new ProcessBuilder("su").start();
            OutputStream os = p.getOutputStream();
            os.write(("[ -d /data/adb/modules/" + MODID + " ] || [ -d /data/adb/modules_update/" + MODID
                    + " ]\nexit $?\n").getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
            if (!p.waitFor(10, TimeUnit.SECONDS)) {
                p.destroy();
                return false;
            }
            return p.exitValue() == 0;
        } catch (Throwable t) {
            return false;
        }
    }
}

package com.dynamicpill.module;

import android.content.res.Resources;
import android.content.res.TypedArray;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * One place that answers dimen lookups for System UI AND for the MIUI System UI plug-in
 * (miui.systemui.plugin runs inside the System UI process).
 *
 * Why this exists (3.1.29): the old hooks only covered Resources.getDimension*(id). Almost every size of the
 * Control Center is written in layout XML (android:layout_width="@dimen/..."), and the layout inflater reads
 * those through TypedArray, which was never hooked, so the sliders had no effect. Both paths are hooked now.
 * Group caches are keyed by AssetManager + id because the plug-in and System UI both use package id 0x7f, so a
 * bare id can mean two different dimens (that mixed up the sliders).
 */
final class DimenHook {
    private static boolean done = false;

    /** Cache key: the AssetManager (= one apk) and the resource id. */
    static long key(Resources r, int id) {
        int a;
        try { a = System.identityHashCode(r.getAssets()); } catch (Throwable t) { a = 0; }
        return ((long) a << 32) | (id & 0xffffffffL);
    }

    /** New px value, or NaN when the dimen stays unchanged. */
    static float adjust(Resources r, int id, float original) {
        if (id == 0) return Float.NaN;
        float n = ControlCenterSize.adjust(r, id, original);
        if (!Float.isNaN(n)) return n;
        return StatusBarSize.adjust(r, id, original);
    }

    private static float taAdjust(TypedArray ta, int index, float original) {
        try {
            int id = ta.getResourceId(index, 0);
            if (id == 0) return Float.NaN;
            return adjust(ta.getResources(), id, original);
        } catch (Throwable t) {
            return Float.NaN;
        }
    }

    static synchronized void install() {
        if (done) return;
        done = true;
        try {
            XposedHelpers.findAndHookMethod(Resources.class, "getDimensionPixelSize", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        float n = adjust((Resources) p.thisObject, (Integer) p.args[0], (Integer) p.getResult());
                        if (!Float.isNaN(n)) p.setResult(Math.max(0, Math.round(n)));
                    } catch (Throwable ignored) { }
                }
            });
            XposedHelpers.findAndHookMethod(Resources.class, "getDimensionPixelOffset", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        float n = adjust((Resources) p.thisObject, (Integer) p.args[0], (Integer) p.getResult());
                        if (!Float.isNaN(n)) p.setResult(Math.max(0, (int) n));
                    } catch (Throwable ignored) { }
                }
            });
            XposedHelpers.findAndHookMethod(Resources.class, "getDimension", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        float n = adjust((Resources) p.thisObject, (Integer) p.args[0], (Float) p.getResult());
                        if (!Float.isNaN(n)) p.setResult(Math.max(0f, n));
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: Resources dimen hook failed: " + t);
        }
        try {
            XposedHelpers.findAndHookMethod(TypedArray.class, "getDimensionPixelSize", int.class, int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    float n = taAdjust((TypedArray) p.thisObject, (Integer) p.args[0], (Integer) p.getResult());
                    if (!Float.isNaN(n)) p.setResult(Math.max(0, Math.round(n)));
                }
            });
            XposedHelpers.findAndHookMethod(TypedArray.class, "getDimensionPixelOffset", int.class, int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    float n = taAdjust((TypedArray) p.thisObject, (Integer) p.args[0], (Integer) p.getResult());
                    if (!Float.isNaN(n)) p.setResult(Math.max(0, (int) n));
                }
            });
            XposedHelpers.findAndHookMethod(TypedArray.class, "getDimension", int.class, float.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    float n = taAdjust((TypedArray) p.thisObject, (Integer) p.args[0], (Float) p.getResult());
                    if (!Float.isNaN(n)) p.setResult(Math.max(0f, n));
                }
            });
            // layout_width / layout_height / layout_margin... go through this one (wrap_content / match_parent are negative: untouched)
            XC_MethodHook layoutHook = new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object res = p.getResult();
                    if (!(res instanceof Integer) || (Integer) res < 0) return;
                    float n = taAdjust((TypedArray) p.thisObject, (Integer) p.args[0], (Integer) res);
                    if (!Float.isNaN(n)) p.setResult(Math.max(0, Math.round(n)));
                }
            };
            XposedHelpers.findAndHookMethod(TypedArray.class, "getLayoutDimension", int.class, int.class, layoutHook);
            XposedHelpers.findAndHookMethod(TypedArray.class, "getLayoutDimension", int.class, String.class, layoutHook);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: TypedArray dimen hook failed: " + t);
        }
    }
}

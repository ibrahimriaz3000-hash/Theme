package com.dynamicpill.module;

import android.content.res.Resources;

import de.robv.android.xposed.XSharedPreferences;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Status bar left / right padding (dp). 0 = "Default" (the system value is left untouched).
 * 3.1.29: height, top padding and the clock / icons paddings were removed (they never worked on this ROM).
 * The lookup itself is done by DimenHook; this class only knows which dimens belong to the two sliders.
 */
final class StatusBarSize {
    static final String K_START = "sbs_pad_start_dp";
    static final String K_END = "sbs_pad_end_dp";

    private static final int G_NONE = 0, G_START = 1, G_END = 2;

    private static final ConcurrentHashMap<Long, Integer> GROUP = new ConcurrentHashMap<>();
    private static XSharedPreferences xsp;
    private static volatile int[] vals = new int[3];     // dp per group, 0 = default
    private static volatile long lastLoad = 0;

    private static int groupOf(String name) {
        if (name == null) return G_NONE;
        switch (name) {
            case "status_bar_padding_start":
                return G_START;
            case "status_bar_padding_end":
                return G_END;
            default:
                return G_NONE;
        }
    }

    /** Changes whenever one of the sliders changes (used to re-apply the bar live). */
    static int signature() {
        int[] v = load();
        int h = 17;
        for (int x : v) h = h * 31 + x;
        return h;
    }

    private static int[] load() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastLoad < 700) return vals;
        lastLoad = now;
        try {
            if (xsp == null) xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
            if (xsp.hasFileChanged()) xsp.reload();
            int[] v = new int[3];
            v[G_START] = xsp.getInt(K_START, 0);
            v[G_END] = xsp.getInt(K_END, 0);
            vals = v;
        } catch (Throwable ignored) { }
        return vals;
    }

    /** New px value for the dimen, or NaN when it stays at the system value. */
    static float adjust(Resources r, int id, float original) {
        long key = DimenHook.key(r, id);
        Integer g = GROUP.get(key);
        if (g == null) {
            int gr = G_NONE;
            try { gr = groupOf(r.getResourceEntryName(id)); } catch (Throwable ignored) { }
            g = gr;
            GROUP.put(key, g);
        }
        if (g == G_NONE) return Float.NaN;
        int dp = load()[g];
        if (dp <= 0) return Float.NaN;
        return dp * r.getDisplayMetrics().density;
    }
}

package com.dynamicpill.module;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** Tiny root helper: restarts System UI so every Control Center / status bar value is read again. */
final class RootUtil {
    private RootUtil() { }

    /** Blocking. Call from a background thread. True when su ran the command successfully. */
    static boolean restartSystemUi() {
        try {
            Process p = new ProcessBuilder("su").start();
            OutputStream os = p.getOutputStream();
            os.write(("killall com.android.systemui 2>/dev/null || pkill -f com.android.systemui\nexit $?\n")
                    .getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
            if (!p.waitFor(10, TimeUnit.SECONDS)) {
                p.destroy();
                return false;
            }
            return p.exitValue() == 0;
        } catch (Throwable t) {
            return false;
        }
    }
}

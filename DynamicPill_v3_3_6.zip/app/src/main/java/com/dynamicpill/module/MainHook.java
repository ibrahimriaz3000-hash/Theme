package com.dynamicpill.module;

import android.app.Application;
import android.content.Context;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {
    private static boolean started = false;
    private static final int K_CC = 1, K_BOUNCER = 2, K_BATT = 4, K_SB = 8, K_TILE = 16, K_MEDIAPANEL = 32;
    private static final java.util.concurrent.ConcurrentHashMap<Class<?>, Integer> KINDS =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** Class-name check done once per class (this runs for every view System UI attaches). */
    private static int classKind(Class<?> c) {
        Integer k = KINDS.get(c);
        if (k != null) return k;
        String l = c.getName().toLowerCase();
        int r = 0;
        if (l.contains("controlcenter")) r |= K_CC;
        if (l.contains("securitycontainer") || l.contains("bouncer") || l.contains("keyguardhostview")) r |= K_BOUNCER;
        if (l.contains("batterymeterview")) r |= K_BATT;
        if (l.contains("statusbarview") && !l.contains("controlcenter")) r |= K_SB;   // PhoneStatusBarView, KeyguardStatusBarView ...
        if (l.endsWith(".qstileitemview") || l.endsWith(".qscarditemview")) r |= K_TILE;
        if (l.endsWith(".mediaplayerpanel")) r |= K_MEDIAPANEL;
        KINDS.put(c, r);
        return r;
    }

    /** True when one of the view's parents is a Control Center class. */
    private static boolean insideControlCenter(android.view.View v) {
        android.view.ViewParent p = v.getParent();
        for (int i = 0; i < 25 && p != null; i++) {
            if ((classKind(p.getClass()) & K_CC) != 0) return true;
            p = p.getParent();
        }
        return false;
    }

    /** Topmost Control Center view above v (used as the host of the floating battery %). */
    static android.view.ViewGroup ccRoot(android.view.View v) {
        android.view.ViewGroup top = null;
        android.view.ViewParent p = v.getParent();
        for (int i = 0; i < 25 && p != null; i++) {
            if (p instanceof android.view.ViewGroup && (classKind(p.getClass()) & K_CC) != 0)
                top = (android.view.ViewGroup) p;
            p = p.getParent();
        }
        return top;
    }

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        String pkg = lpparam.packageName;
        if ("miui.systemui.plugin".equals(pkg)) {
            // The real Control Center / volume panel / MiPlay live in this plug-in (loaded inside System UI).
            // Dimens are answered by the process-wide Resources / TypedArray hooks, installed here too in case
            // the plug-in is loaded before System UI's own hooks ran.
            try {
                DimenHook.install();
                TileCard.hookPlugin(lpparam.classLoader);
                XposedBridge.log("DynamicPill: plug-in hooks ready (" + pkg + ")");
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: plug-in hook failed: " + t);
            }
            return;
        }
        if ("android".equals(pkg)) {
            // System Framework is in the scope (as requested); no framework feature is active at the moment.
            XposedBridge.log("DynamicPill: framework scope loaded");
            return;
        }
        if (!"com.android.systemui".equals(pkg)) return;
        try {
            XposedHelpers.findAndHookMethod(android.view.View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        android.view.View v = (android.view.View) param.thisObject;
                        int kind = classKind(v.getClass());
                        if ((kind & K_CC) != 0) PillController.registerControlCenter(v);
                        if ((kind & K_MEDIAPANEL) != 0) TileCard.registerPanel(v);
                        if ((kind & K_BOUNCER) != 0) PillController.registerBouncer(v);
                        if ((kind & K_BATT) != 0) CcBattery.attach(v, insideControlCenter(v));
                        if ((kind & K_SB) != 0 && !insideControlCenter(v)) PillController.registerStatusBar(v);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: bar hook failed: " + t);
        }
        try {
            DimenHook.install();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: status bar size failed: " + t);
        }
        // The Control Center plug-in has its own class loader: hook its tile list the moment that class is loaded.
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (TileCard.LIST_CLASS.equals(param.args[0]) && param.getResult() instanceof Class)
                            TileCard.hookPlugin(((Class<?>) param.getResult()).getClassLoader());
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: class loader hook failed: " + t);
        }
        try {
            PillController.hookShadeWindow(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: shade window hook failed: " + t);
        }
        try {
            PillController.hookNotifications();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: notification hook failed: " + t);
        }
        try {
            PillController.hookNotificationList();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: notification list hook failed: " + t);
        }
        try {
            PillController.hookStatusBarState(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: state hook failed: " + t);
        }
        try {
            PillController.hookKeyguardManager(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: keyguard manager hook failed: " + t);
        }
        try {
            XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Context ctx = (Context) param.thisObject;
                        if (!"com.android.systemui".equals(ctx.getPackageName())) return;
                        if (started) return;
                        started = true;
                        new PillController(ctx).start();
                    } catch (Throwable t) {
                        XposedBridge.log("DynamicPill: start failed: " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: hook failed: " + t);
        }
    }
}

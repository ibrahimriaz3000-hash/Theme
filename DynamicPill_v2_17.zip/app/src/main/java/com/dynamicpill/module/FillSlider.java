package com.dynamicpill.module;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Thick rounded slider (no thumb): grey track with a blue fill, like the iOS Control Center sliders. */
public class FillSlider extends View {
    public interface Listener { void onChanged(int progress, boolean fromUser); }

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private int max = 100, progress = 0;
    private Listener listener;

    public FillSlider(Context c, int trackColor, int fillColor) {
        super(c);
        track.setColor(trackColor);
        fill.setColor(fillColor);
    }

    public void setMax(int m) { max = Math.max(1, m); invalidate(); }

    public void setProgress(int p) {
        p = Math.max(0, Math.min(max, p));
        if (p == progress) return;
        progress = p;
        invalidate();
    }

    public void setListener(Listener l) { listener = l; }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_UP) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(a != MotionEvent.ACTION_UP);
            float w = Math.max(1, getWidth());
            int p = Math.round(Math.max(0f, Math.min(1f, e.getX() / w)) * max);
            if (p != progress) {
                progress = p;
                invalidate();
                if (listener != null) listener.onChanged(p, true);
            }
            return true;
        }
        if (a == MotionEvent.ACTION_CANCEL && getParent() != null) {
            getParent().requestDisallowInterceptTouchEvent(false);
            return true;
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = h / 2f;
        rect.set(0, 0, w, h);
        clip.reset();
        clip.addRoundRect(rect, r, r, Path.Direction.CW);
        canvas.drawPath(clip, track);
        canvas.save();
        canvas.clipPath(clip);
        rect.set(0, 0, w * progress / (float) max, h);
        canvas.drawRect(rect, fill);
        canvas.restore();
    }
}

package com.dynamicpill.module;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Black capsule with an indicator dot (right) and a small charging bolt (left). Every change fades smoothly. */
public class PillView extends View {
    private static final ArgbEvaluator ARGB = new ArgbEvaluator();

    private static final int BOLT_GREEN = 0xFF34C759;
    /** One full blink (dim and back) takes this long. */
    private static final long BLINK_PERIOD_MS = 1000;
    /** Fade time for colour / thickness / icon changes. */
    private static final long FADE_MS = 350;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bolt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path boltPath = new Path();
    private final Path shape = new Path();
    private final Path edgeShape = new Path();
    // dark mode look: thin light rim (+ faint glow) so the black pill does not vanish on a black status bar
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path ringShape = new Path();
    private final Path glowShape = new Path();
    private float ringKeyW = -1, ringKeyH = -1, ringKeyN = -1, glowKeyW = -1, glowKeyH = -1, glowKeyN = -1;
    private boolean darkOn = false;
    private float darkCur = 0f;                 // 0..1, fades when system dark mode toggles
    private int darkStrength = 60;              // 0..100 from the settings
    private ValueAnimator darkAnim;
    private float smoothN = 2f;                 // 2 = plain circular capsule, > 2 = iOS style continuous curve
    private float shapeW = -1, shapeH = -1, shapeIn = -1, shapeNKey = -1;
    private float edgeW = -1, edgeH = -1, edgeIn = -1, edgeNKey = -1;

    // outline: thickness and colour fade to their target values
    private float borderTarget = 0f, borderCur = 0f;
    private int strokeTarget = 0xFFFFFFFF, strokeCur = 0xFFFFFFFF;
    private ValueAnimator borderAnim, strokeAnim;

    // dot: colour fades, blink fades
    private boolean dotOn = true;
    private int dotTarget = 0xFFFFCC00, dotCur = 0xFFFFCC00; // yellow
    private ValueAnimator dotColorAnim;

    // charging bolt fades in and out
    private boolean charging = false;
    private float boltFactor = 0f;
    private ValueAnimator boltAnim;

    private float dotBlink = 1f;     // dot blink (new notification)
    private float strokeBlink = 1f;  // outline blink (call)
    private ValueAnimator dotBlinkAnim, strokeBlinkAnim, dotRestoreAnim;

    public PillView(Context context) {
        super(context);
        paint.setDither(true);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(0xFF000000); // pure dark black, full alpha
        paint.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        dot.setStyle(Paint.Style.FILL);
        bolt.setStyle(Paint.Style.FILL);
        bolt.setColor(BOLT_GREEN);
    }

    /** Dark mode rim: on = system dark mode, strength 0..100 (0 = off). Fades in / out. */
    public void setDarkLook(boolean dark, int strengthPct) {
        int st = Math.max(0, Math.min(100, strengthPct));
        if (st != darkStrength) { darkStrength = st; invalidate(); }
        if (dark == darkOn) return;
        darkOn = dark;
        if (darkAnim != null) darkAnim.cancel();
        darkAnim = ValueAnimator.ofFloat(darkCur, dark ? 1f : 0f);
        darkAnim.setDuration(350);
        darkAnim.addUpdateListener(a -> {
            darkCur = (Float) a.getAnimatedValue();
            invalidate();
        });
        darkAnim.start();
    }

    private void drawDarkRim(Canvas canvas, float w, float h) {
        float dk = darkCur * darkStrength / 100f * (1f - Math.min(1f, borderCur / 2f));
        if (dk < 0.01f) return;
        float d = getResources().getDisplayMetrics().density;
        boolean plain = smoothN <= 2.001f;
        // soft outer glow
        float gw = d * 3f, gin = gw / 2f;
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(0xFFFFFFFF);
        ring.setStrokeWidth(gw);
        ring.setAlpha(Math.round(255f * dk * 0.14f));
        if (plain) {
            rect.set(gin, gin, w - gin, h - gin);
            float rr = Math.max(0f, h / 2f - gin);
            canvas.drawRoundRect(rect, rr, rr, ring);
        } else {
            if (glowKeyW != w || glowKeyH != h || glowKeyN != smoothN) {
                buildCapsule(glowShape, w, h, gin, smoothN);
                glowKeyW = w; glowKeyH = h; glowKeyN = smoothN;
            }
            canvas.drawPath(glowShape, ring);
        }
        // crisp light rim
        float sw = Math.max(1f, d * 1.1f), in = sw / 2f;
        ring.setStrokeWidth(sw);
        ring.setAlpha(Math.round(255f * dk * 0.75f));
        if (plain) {
            rect.set(in, in, w - in, h - in);
            float rr = Math.max(0f, h / 2f - in);
            canvas.drawRoundRect(rect, rr, rr, ring);
        } else {
            if (ringKeyW != w || ringKeyH != h || ringKeyN != smoothN) {
                buildCapsule(ringShape, w, h, in, smoothN);
                ringKeyW = w; ringKeyH = h; ringKeyN = smoothN;
            }
            canvas.drawPath(ringShape, ring);
        }
    }

    /** Corner smoothness 0..100. 0 = circular ends, higher = softer, continuous (iOS style) curvature. */
    public void setSmooth(int percent) {
        float n = 2f + 0.6f * Math.max(0, Math.min(100, percent)) / 100f;
        if (n != smoothN) {
            smoothN = n;
            invalidate();
        }
    }

    /**
     * Capsule whose end caps are superellipse arcs: the curvature changes gradually into the straight
     * edges (no visible "where the circle starts" line), which looks smoother than a plain round rect.
     */
    private static void buildCapsule(Path p, float w, float h, float inset, float n) {
        p.reset();
        float r = h / 2f - inset;
        if (r <= 0f || w <= h) { p.addRoundRect(new RectF(inset, inset, w - inset, h - inset), h / 2f, h / 2f, Path.Direction.CW); return; }
        float e = 2f / n;
        float cy = h / 2f, cxR = w - h / 2f, cxL = h / 2f;
        final int N = 40;
        for (int i = 0; i <= N; i++) {                       // right cap, top -> bottom
            double u = -Math.PI / 2 + Math.PI * i / N;
            float c = (float) Math.pow(Math.max(0.0, Math.cos(u)), e);
            float sn = (float) (Math.signum(Math.sin(u)) * Math.pow(Math.abs(Math.sin(u)), e));
            float x = cxR + r * c, y = cy + r * sn;
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        for (int i = 0; i <= N; i++) {                       // left cap, bottom -> top
            double u = -Math.PI / 2 + Math.PI * i / N;
            float c = (float) Math.pow(Math.max(0.0, Math.cos(u)), e);
            float sn = (float) (Math.signum(Math.sin(u)) * Math.pow(Math.abs(Math.sin(u)), e));
            p.lineTo(cxL - r * c, cy - r * sn);
        }
        p.close();
    }

    /** Border thickness in pixels; 0 = no border. Fades to the new thickness. */
    public void setBorder(float px) {
        px = Math.max(0f, px);
        if (px == borderTarget) return;
        borderTarget = px;
        if (borderAnim != null) borderAnim.cancel();
        final float from = borderCur, to = px;
        borderAnim = ValueAnimator.ofFloat(0f, 1f);
        borderAnim.setDuration(FADE_MS);
        borderAnim.addUpdateListener(a -> {
            borderCur = from + (to - from) * (Float) a.getAnimatedValue();
            invalidate();
        });
        borderAnim.start();
    }

    /** Border colour (white normally, green while charging or in a call). Cross-fades. */
    public void setStrokeColor(int color) {
        if (color == strokeTarget) return;
        strokeTarget = color;
        if (strokeAnim != null) strokeAnim.cancel();
        final int from = strokeCur, to = color;
        strokeAnim = ValueAnimator.ofFloat(0f, 1f);
        strokeAnim.setDuration(FADE_MS);
        strokeAnim.addUpdateListener(a -> {
            strokeCur = (Integer) ARGB.evaluate((Float) a.getAnimatedValue(), from, to);
            invalidate();
        });
        strokeAnim.start();
    }

    /** 0..100 percent; 100 = fully solid black. */
    public void setPillAlpha(int percent) {
        int a = Math.round(255f * Math.max(0, Math.min(100, percent)) / 100f);
        if (paint.getAlpha() != a) {
            paint.setAlpha(a);
            invalidate();
        }
    }

    /** Indicator dot inside the pill: shown or not, and its colour (cross-fades). */
    public void setDot(boolean on, int color) {
        if (on != dotOn) {
            dotOn = on;
            invalidate();
        }
        if (color == dotTarget) return;
        dotTarget = color;
        if (dotColorAnim != null) dotColorAnim.cancel();
        final int from = dotCur, to = color;
        dotColorAnim = ValueAnimator.ofFloat(0f, 1f);
        dotColorAnim.setDuration(FADE_MS);
        dotColorAnim.addUpdateListener(a -> {
            dotCur = (Integer) ARGB.evaluate((Float) a.getAnimatedValue(), from, to);
            invalidate();
        });
        dotColorAnim.start();
    }

    /** Small green lightning bolt on the left side while the phone is charging. Fades in and out. */
    public void setBolt(boolean on) {
        if (on == charging) return;
        charging = on;
        if (boltAnim != null) boltAnim.cancel();
        boltAnim = ValueAnimator.ofFloat(boltFactor, on ? 1f : 0f);
        boltAnim.setDuration(FADE_MS);
        boltAnim.addUpdateListener(a -> {
            boltFactor = (Float) a.getAnimatedValue();
            invalidate();
        });
        boltAnim.start();
    }

    private ValueAnimator startBlink(final boolean forDot) {
        ValueAnimator a = ValueAnimator.ofFloat(1f, 0.1f);
        a.setDuration(BLINK_PERIOD_MS / 2);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.addUpdateListener(v -> {
            if (forDot) dotBlink = (Float) v.getAnimatedValue();
            else strokeBlink = (Float) v.getAnimatedValue();
            invalidate();
        });
        a.start();
        return a;
    }

    /** Makes the dot fade out and in once per second. Stopping fades it back to full smoothly. */
    public void setBlink(boolean on) {
        if (on) {
            if (dotRestoreAnim != null) {
                dotRestoreAnim.cancel();
                dotRestoreAnim = null;
            }
            if (dotBlinkAnim == null) dotBlinkAnim = startBlink(true);
        } else if (dotBlinkAnim != null) {
            dotBlinkAnim.cancel();
            dotBlinkAnim = null;
            final float from = dotBlink;
            if (from >= 0.99f) {
                dotBlink = 1f;
                invalidate();
            } else {
                dotRestoreAnim = ValueAnimator.ofFloat(from, 1f);
                dotRestoreAnim.setDuration(250);
                dotRestoreAnim.addUpdateListener(a -> {
                    dotBlink = (Float) a.getAnimatedValue();
                    invalidate();
                });
                dotRestoreAnim.start();
            }
        }
    }

    /** Makes the outline fade out and in once per second (call). */
    public void setStrokeBlink(boolean on) {
        if (on) {
            if (strokeBlinkAnim == null) strokeBlinkAnim = startBlink(false);
        } else if (strokeBlinkAnim != null) {
            strokeBlinkAnim.cancel();
            strokeBlinkAnim = null;
            strokeBlink = 1f;
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ValueAnimator[] all = {borderAnim, strokeAnim, dotColorAnim, boltAnim, dotBlinkAnim, strokeBlinkAnim, dotRestoreAnim};
        for (ValueAnimator a : all) if (a != null) a.cancel();
        borderAnim = strokeAnim = dotColorAnim = boltAnim = dotBlinkAnim = strokeBlinkAnim = dotRestoreAnim = null;
        // snap to the final values so nothing stays half faded
        borderCur = borderTarget;
        strokeCur = strokeTarget;
        dotCur = dotTarget;
        boltFactor = charging ? 1f : 0f;
        dotBlink = 1f;
        strokeBlink = 1f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = h / 2f;
        boolean plain = smoothN <= 2.001f;
        if (plain) {
            rect.set(0, 0, w, h);
            canvas.drawRoundRect(rect, r, r, paint);
        } else {
            if (shapeW != w || shapeH != h || shapeNKey != smoothN || shapeIn != 0f) {
                buildCapsule(shape, w, h, 0f, smoothN);
                shapeW = w; shapeH = h; shapeNKey = smoothN; shapeIn = 0f;
            }
            canvas.drawPath(shape, paint);
        }
        drawDarkRim(canvas, w, h);
        if (borderCur > 0.05f) {
            stroke.setColor(strokeCur);
            stroke.setAlpha(Math.round(255f * strokeBlink * Math.min(1f, borderCur)));
            stroke.setStrokeWidth(borderCur);
            float in = borderCur / 2f;
            if (plain) {
                rect.set(in, in, w - in, h - in);
                float rr = Math.max(0f, h / 2f - in);
                canvas.drawRoundRect(rect, rr, rr, stroke);
            } else {
                if (edgeW != w || edgeH != h || edgeNKey != smoothN || edgeIn != in) {
                    buildCapsule(edgeShape, w, h, in, smoothN);
                    edgeW = w; edgeH = h; edgeNKey = smoothN; edgeIn = in;
                }
                canvas.drawPath(edgeShape, stroke);
            }
        }

        if (dotOn) {
            dot.setColor(dotCur);
            dot.setAlpha(Math.round(255f * dotBlink));
            canvas.drawCircle(w - h * 0.5f, h / 2f, h * 0.16f, dot);
        }

        if (boltFactor > 0.01f) drawBolt(canvas, h);
    }

    /** Small lightning bolt, centred in the left cap of the pill. */
    private void drawBolt(Canvas canvas, float h) {
        float bh = h * 0.46f;
        float bw = bh * 0.7f;
        float x0 = h * 0.5f - bw / 2f;
        float y0 = h * 0.5f - bh / 2f;
        boltPath.reset();
        boltPath.moveTo(x0 + 0.62f * bw, y0);
        boltPath.lineTo(x0 + 0.08f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.46f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.34f * bw, y0 + bh);
        boltPath.lineTo(x0 + 0.92f * bw, y0 + 0.42f * bh);
        boltPath.lineTo(x0 + 0.54f * bw, y0 + 0.42f * bh);
        boltPath.close();
        bolt.setAlpha(Math.round(255f * boltFactor));
        canvas.drawPath(boltPath, bolt);
    }
}

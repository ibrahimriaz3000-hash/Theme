package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Map;

import de.robv.android.xposed.XposedBridge;

/**
 * Control Center: the media tile (big rounded square under Mobile data / Wi-Fi) loses its content
 * ("No playback history", the play / previous / next buttons, cover art, titles ...) and shows an iPhone style
 * rainbow "hello" that is written stroke by stroke every time the Control Center opens, then stays written.
 * The glass background of the tile is not touched. Everything is undone when the Control Center closes.
 */
final class CcHello {
    private CcHello() { }

    static final String K_ON = "cc_hello_tile";

    private static final float PW = 168f;          // width of the hello path in its own units
    private static final long T_WRITE = 1900;      // writing time

    private static WeakReference<View> tileRef = new WeakReference<>(null);
    private static HelloDrawable drawable;
    private static boolean attached = false;
    private static final Map<View, Float> hidden = new IdentityHashMap<>();
    private static ViewTreeObserver.OnPreDrawListener pre;
    private static ViewTreeObserver preVto;

    private static int lastBy = Integer.MIN_VALUE;
    private static long lastScan = 0, lastTry = 0;
    private static final int[] loc = new int[2];

    // ------------------------------------------------------------------ driven every 40 ms by the Control Center header

    static void tick(ViewGroup host, View battery, View anchor, float a) {
        try {
            if (!CcBattery.flag(K_ON, true) || a < 0.05f) {          // closed (or switched off): put everything back
                if (attached) detach();
                lastBy = Integer.MIN_VALUE;
                return;
            }
            long now = android.os.SystemClock.uptimeMillis();
            if (!attached) {
                if (now - lastTry < 120) return;
                lastTry = now;
                int hb = headerBottom(battery, anchor);
                View t = findTile(host, hb);
                if (t != null) attach(t);
                return;
            }
            View t = tileRef.get();
            if (t == null || !t.isAttachedToWindow() || t.getWidth() <= 0 || t.getHeight() <= 0) {
                detach();
                return;
            }
            drawable.setBounds(0, 0, t.getWidth(), t.getHeight());
            if (!drawable.started && a >= 0.9f) drawable.start();     // write once the Control Center is open
            if (now - lastScan > 400) { lastScan = now; collectHidden(t); }
        } catch (Throwable th) {
            XposedBridge.log("DynamicPill: cc hello tick failed: " + th);
            try { detach(); } catch (Throwable ignored) { }
        }
    }

    private static int headerBottom(View battery, View anchor) {
        float dp = battery.getResources().getDisplayMetrics().density;
        battery.getLocationOnScreen(loc);
        int hb = loc[1] + battery.getHeight();
        if (anchor != null && anchor.isShown()) {
            anchor.getLocationOnScreen(loc);
            hb = Math.max(hb, loc[1] + anchor.getHeight());
        }
        return hb + Math.round(dp * 2f);
    }

    // ------------------------------------------------------------------ finding the media tile

    /** The media tile is the only big, nearly square view in the left half, right under the Wi-Fi / data row. */
    private static View findTile(View root, int hb) {
        android.util.DisplayMetrics dm = root.getResources().getDisplayMetrics();
        ArrayList<View> found = new ArrayList<>();
        scan(root, hb, dm.widthPixels, dm.heightPixels, found, new int[]{0});
        View best = null;
        int bestTop = Integer.MAX_VALUE;
        for (View v : found) {
            v.getLocationOnScreen(loc);
            if (loc[1] < bestTop) { bestTop = loc[1]; best = v; }
        }
        return best;
    }

    private static void scan(View v, int hb, int sw, int sh, ArrayList<View> out, int[] n) {
        if (!(v instanceof ViewGroup)) return;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (n[0]++ > 2500 || c.getVisibility() != View.VISIBLE) continue;
            int w = c.getWidth(), h = c.getHeight();
            if (w > 0 && h > 0) {
                c.getLocationOnScreen(loc);
                if (loc[1] >= hb && loc[1] < sh * 0.5f
                        && w >= sw * 0.28f && w <= sw * 0.46f
                        && Math.abs(w - h) <= Math.max(w, h) * 0.18f
                        && loc[0] + w / 2f < sw * 0.5f) {
                    out.add(c);
                    continue;                                   // do not look inside the tile
                }
            }
            scan(c, hb, sw, sh, out, n);
        }
    }

    // ------------------------------------------------------------------ taking the content away

    private static void attach(View tile) {
        tileRef = new WeakReference<>(tile);
        drawable = new HelloDrawable(tile.getResources().getDisplayMetrics().density);
        drawable.setBounds(0, 0, tile.getWidth(), tile.getHeight());
        tile.getOverlay().add(drawable);                         // drawn on top of the tile's children
        collectHidden(tile);
        lastScan = android.os.SystemClock.uptimeMillis();
        pre = new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                for (View v : hidden.keySet()) {
                    if (v.getAlpha() != 0f) v.setAlpha(0f);     // media code fades its views in again: keep them hidden
                }
                return true;
            }
        };
        preVto = tile.getViewTreeObserver();
        preVto.addOnPreDrawListener(pre);
        attached = true;
        XposedBridge.log("DynamicPill: cc hello tile attached " + tile.getWidth() + "x" + tile.getHeight()
                + " " + tile.getClass().getName() + " hidden=" + hidden.size());
    }

    private static void detach() {
        attached = false;
        View t = tileRef.get();
        try {
            if (preVto != null && pre != null && preVto.isAlive()) preVto.removeOnPreDrawListener(pre);
            else if (t != null && pre != null) t.getViewTreeObserver().removeOnPreDrawListener(pre);
        } catch (Throwable ignored) { }
        pre = null;
        preVto = null;
        if (drawable != null) {
            drawable.stop();
            try { if (t != null) t.getOverlay().remove(drawable); } catch (Throwable ignored) { }
            drawable = null;
        }
        for (Map.Entry<View, Float> e : hidden.entrySet()) {
            try { e.getKey().setAlpha(e.getValue()); } catch (Throwable ignored) { }
        }
        hidden.clear();
        tileRef = new WeakReference<>(null);
    }

    /** Hides everything inside the tile except its glass background (big views covering the whole tile). */
    private static void collectHidden(View tile) {
        if (!(tile instanceof ViewGroup)) return;
        hideIn((ViewGroup) tile, tile.getWidth(), tile.getHeight(), new int[]{0});
    }

    private static void hideIn(ViewGroup g, int tw, int th, int[] n) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (n[0]++ > 400) return;
            if (hidden.containsKey(c)) continue;
            boolean big = c.getWidth() >= tw * 0.9f && c.getHeight() >= th * 0.9f;
            if (c instanceof ViewGroup) {
                if (!big && c.getBackground() != null) hide(c);
                else hideIn((ViewGroup) c, tw, th, n);
            } else if (c instanceof TextView || !big) {          // texts, icons, buttons, cover art; not the glass layer
                hide(c);
            }
        }
    }

    private static void hide(View v) {
        hidden.put(v, v.getAlpha());
        v.setAlpha(0f);
    }

    // ------------------------------------------------------------------ the writing drawable

    static final class HelloDrawable extends Drawable {
        private static final String HELLO_PTS =
            "2.0,64.0,2.1,63.9,2.5,63.8,3.0,63.5,3.6,63.2,4.3,62.8,5.1,62.3,5.9,61.8,6.7,61.2,7.4,60.6,8.0,60.0,8.7,59.1," +
            "9.4,58.1,10.0,57.1,10.7,55.9,11.3,54.7,11.8,53.4,12.4,52.1,13.0,50.8,13.5,49.4,14.0,48.0,14.6,46.2,15.2,44.3," +
            "15.7,42.4,16.2,40.4,16.7,38.3,17.2,36.2,17.6,34.1,18.1,32.0,18.5,30.0,19.0,28.0,19.4,26.1,19.8,24.2,20.2,22.3," +
            "20.5,20.3,20.9,18.4,21.3,16.5,21.6,14.7,22.1,13.0,22.5,11.4,23.0,10.0,23.4,9.1,23.7,8.2,24.1,7.2,24.5,6.3," +
            "24.9,5.5,25.3,4.7,25.7,4.1,26.1,3.6,26.5,3.2,27.0,3.0,27.4,3.0,27.8,3.1,28.3,3.2,28.7,3.5,29.2,3.8,29.6,4.2," +
            "30.0,4.6,30.4,5.0,30.7,5.5,31.0,6.0,31.3,6.9,31.4,8.0,31.4,9.3,31.4,10.6,31.2,12.1,31.0,13.6,30.7,15.2,30.4," +
            "16.8,30.2,18.4,30.0,20.0,29.8,22.0,29.5,24.1,29.2,26.3,28.9,28.5,28.6,30.8,28.3,33.0,28.0,35.3,27.6,37.6,27.3," +
            "39.8,27.0,42.0,26.7,44.1,26.4,46.2,26.1,48.4,25.7,50.5,25.4,52.6,25.1,54.7,24.8,56.7,24.5,58.6,24.2,60.4,24.0," +
            "62.0,23.9,63.0,23.7,64.1,23.6,65.2,23.4,66.2,23.3,67.2,23.2,68.1,23.1,68.9,23.0,69.5,23.0,69.9,23.0,70.0,23.1," +
            "69.8,23.1,69.3,23.3,68.5,23.4,67.4,23.6,66.3,23.8,65.0,24.1,63.6,24.3,62.3,24.7,61.1,25.0,60.0,25.4,58.9,25.9," +
            "57.7,26.4,56.5,27.0,55.3,27.6,54.1,28.2,52.9,28.9,51.8,29.5,50.8,30.3,49.8,31.0,49.0,31.6,48.4,32.3,47.8,33.0," +
            "47.2,33.7,46.7,34.4,46.2,35.2,45.7,35.9,45.4,36.6,45.1,37.3,45.0,38.0,45.0,38.7,45.1,39.3,45.4,40.0,45.7,40.7," +
            "46.2,41.4,46.7,42.0,47.3,42.6,48.0,43.1,48.6,43.6,49.3,44.0,50.0,44.3,50.8,44.6,51.7,44.7,52.7,44.8,53.7,44.9," +
            "54.8,44.9,55.9,44.9,56.9,44.9,58.0,44.9,59.0,45.0,60.0,45.1,60.9,45.1,61.8,45.1,62.7,45.2,63.6,45.2,64.4,45.2," +
            "65.3,45.3,66.1,45.5,66.8,45.7,67.5,46.0,68.0,46.3,68.4,46.6,68.7,47.0,69.0,47.4,69.3,47.9,69.6,48.3,69.8,48.8," +
            "69.9,49.2,70.0,49.6,70.1,50.0,70.0,50.5,69.8,50.9,69.4,51.3,69.0,51.7,68.4,52.1,67.7,52.5,67.0,52.9,66.2,53.3," +
            "65.5,53.6,64.7,54.0,64.0,54.4,63.1,54.8,62.1,55.2,61.1,55.5,60.1,55.9,59.0,56.2,57.9,56.6,56.9,57.0,55.9,57.5," +
            "54.9,58.0,54.0,58.6,53.2,59.2,52.3,59.8,51.5,60.5,50.7,61.2,49.9,61.9,49.1,62.7,48.5,63.5,47.9,64.2,47.4,65.0," +
            "47.0,65.7,46.8,66.4,46.6,67.2,46.4,67.9,46.3,68.7,46.3,69.4,46.3,70.2,46.4,70.8,46.5,71.5,46.7,72.0,47.0,72.5," +
            "47.4,73.0,47.8,73.4,48.4,73.8,49.0,74.2,49.7,74.5,50.3,74.8,51.0,74.9,51.7,75.0,52.4,75.0,53.0,74.9,53.6,74.6," +
            "54.3,74.2,55.0,73.8,55.7,73.2,56.3,72.6,57.0,72.0,57.6,71.3,58.1,70.7,58.6,70.0,59.0,69.2,59.3,68.4,59.5,67.5," +
            "59.6,66.5,59.6,65.5,59.5,64.5,59.5,63.6,59.5,62.6,59.6,61.8,59.7,61.0,60.0,60.3,60.3,59.7,60.7,59.0,61.2,58.4," +
            "61.7,57.8,62.2,57.2,62.8,56.8,63.3,56.4,63.9,56.1,64.5,56.0,65.0,56.0,65.5,56.1,66.0,56.3,66.6,56.5,67.2,56.8," +
            "67.8,57.2,68.3,57.6,68.8,58.1,69.3,58.5,69.7,59.0,70.0,59.6,70.3,60.3,70.5,61.1,70.6,61.9,70.7,62.8,70.7,63.6," +
            "70.7,64.5,70.6,65.4,70.5,66.2,70.3,67.0,70.0,67.9,69.6,68.7,69.2,69.6,68.6,70.4,68.0,71.3,67.3,72.1,66.5,72.8," +
            "65.7,73.6,64.8,74.3,63.9,75.0,63.0,75.8,61.8,76.5,60.5,77.2,59.1,77.8,57.7,78.4,56.1,78.9,54.6,79.5,53.0,80.0," +
            "51.3,80.5,49.7,81.0,48.0,81.6,46.0,82.2,43.9,82.7,41.7,83.2,39.4,83.7,37.1,84.1,34.8,84.6,32.5,85.1,30.3,85.5," +
            "28.1,86.0,26.0,86.4,24.2,86.8,22.3,87.1,20.4,87.5,18.6,87.9,16.8,88.2,15.0,88.6,13.3,89.0,11.8,89.5,10.3,90.0," +
            "9.0,90.4,8.2,90.7,7.4,91.1,6.5,91.6,5.7,92.0,5.0,92.4,4.3,92.8,3.8,93.2,3.4,93.6,3.1,94.0,3.0,94.3,3.1,94.7," +
            "3.3,95.0,3.7,95.4,4.1,95.7,4.7,96.1,5.3,96.3,5.9,96.6,6.6,96.8,7.3,97.0,8.0,97.2,9.2,97.2,10.5,97.1,12.0,96.9," +
            "13.6,96.6,15.2,96.3,17.0,95.9,18.7,95.6,20.5,95.3,22.3,95.0,24.0,94.7,26.1,94.4,28.2,94.1,30.5,93.8,32.7,93.5," +
            "35.0,93.2,37.3,92.9,39.5,92.6,41.8,92.3,43.9,92.0,46.0,91.8,47.7,91.5,49.4,91.2,51.2,91.0,52.8,90.7,54.5,90.5," +
            "56.1,90.3,57.7,90.1,59.2,90.0,60.6,90.0,62.0,90.0,63.0,90.0,63.9,90.0,64.9,90.0,65.9,90.0,66.8,90.0,67.6,90.2," +
            "68.4,90.4,69.1,90.6,69.6,91.0,70.0,91.4,70.2,91.9,70.3,92.5,70.4,93.1,70.3,93.8,70.2,94.4,70.1,95.1,69.8,95.8," +
            "69.6,96.4,69.3,97.0,69.0,97.7,68.6,98.3,68.1,99.0,67.5,99.6,66.9,100.2,66.2,100.8,65.4,101.4,64.6,101.9,63.8," +
            "102.5,62.9,103.0,62.0,103.6,60.7,104.2,59.3,104.8,57.8,105.3,56.2,105.8,54.6,106.2,52.9,106.6,51.2,107.1,49.4," +
            "107.5,47.7,108.0,46.0,108.5,44.1,109.0,42.1,109.6,40.1,110.1,38.1,110.6,36.0,111.1,34.0,111.6,32.0,112.1,29.9," +
            "112.5,27.9,113.0,26.0,113.4,24.2,113.8,22.4,114.2,20.5,114.5,18.7,114.9,16.8,115.2,15.1,115.6,13.4,116.0,11.8," +
            "116.5,10.3,117.0,9.0,117.4,8.2,117.7,7.4,118.1,6.5,118.6,5.7,119.0,5.0,119.4,4.3,119.8,3.8,120.2,3.4,120.6," +
            "3.1,121.0,3.0,121.3,3.1,121.7,3.3,122.0,3.7,122.4,4.1,122.7,4.7,123.1,5.3,123.3,5.9,123.6,6.6,123.8,7.3,124.0," +
            "8.0,124.2,9.2,124.2,10.5,124.1,12.0,123.9,13.6,123.6,15.2,123.3,17.0,122.9,18.7,122.6,20.5,122.3,22.3,122.0," +
            "24.0,121.7,26.1,121.4,28.2,121.1,30.5,120.8,32.7,120.5,35.0,120.2,37.3,119.9,39.5,119.6,41.8,119.3,43.9,119.0," +
            "46.0,118.8,47.7,118.5,49.4,118.2,51.2,118.0,52.8,117.7,54.5,117.5,56.1,117.3,57.7,117.1,59.2,117.0,60.6,117.0," +
            "62.0,117.0,63.0,117.0,63.9,117.0,64.9,117.0,65.9,117.0,66.8,117.0,67.6,117.2,68.4,117.4,69.1,117.6,69.6,118.0," +
            "70.0,118.4,70.2,118.9,70.3,119.5,70.4,120.1,70.4,120.8,70.2,121.5,70.1,122.1,69.9,122.8,69.6,123.4,69.3,124.0," +
            "69.0,124.7,68.5,125.4,67.9,126.0,67.2,126.6,66.4,127.2,65.5,127.8,64.6,128.4,63.7,129.0,62.8,129.5,61.9,130.0," +
            "61.0,130.5,60.1,130.9,59.2,131.2,58.3,131.6,57.3,131.9,56.4,132.3,55.4,132.6,54.5,133.0,53.6,133.5,52.8,134.0," +
            "52.0,134.6,51.2,135.2,50.5,135.9,49.7,136.6,48.9,137.3,48.2,138.0,47.5,138.8,46.9,139.5,46.5,140.3,46.2,141.0," +
            "46.0,141.7,46.0,142.5,46.1,143.2,46.4,144.0,46.7,144.8,47.1,145.6,47.6,146.3,48.2,147.0,48.8,147.5,49.4,148.0," +
            "50.0,148.4,50.8,148.8,51.7,149.0,52.6,149.3,53.7,149.4,54.8,149.5,55.9,149.4,57.0,149.4,58.0,149.2,59.1,149.0," +
            "60.0,148.7,60.9,148.3,61.9,147.8,62.8,147.3,63.7,146.6,64.7,146.0,65.5,145.2,66.3,144.5,67.0,143.8,67.6,143.0," +
            "68.0,142.3,68.3,141.5,68.6,140.7,68.7,139.8,68.8,138.9,68.9,138.0,68.9,137.2,68.8,136.4,68.6,135.6,68.3,135.0," +
            "68.0,134.4,67.5,133.8,66.9,133.2,66.2,132.7,65.4,132.3,64.6,131.9,63.6,131.6,62.7,131.3,61.8,131.1,60.9,131.0," +
            "60.0,131.0,59.1,131.1,58.2,131.2,57.2,131.5,56.2,131.7,55.2,132.1,54.3,132.5,53.4,133.0,52.5,133.5,51.7,134.0," +
            "51.0,134.5,50.4,135.1,49.9,135.8,49.5,136.4,49.0,137.2,48.7,137.9,48.3,138.7,48.0,139.5,47.7,140.2,47.3,141.0," +
            "47.0,141.8,46.6,142.7,46.3,143.6,46.0,144.5,45.7,145.4,45.4,146.4,45.1,147.3,44.9,148.2,44.6,149.1,44.3,150.0," +
            "44.0,150.8,43.7,151.6,43.3,152.5,43.0,153.3,42.6,154.1,42.2,154.9,41.9,155.7,41.6,156.5,41.3,157.2,41.1,158.0," +
            "41.0,158.7,41.0,159.4,41.0,160.2,41.1,161.0,41.3,161.8,41.4,162.5,41.6,163.1,41.7,163.6,41.9,163.9,42.0,164.0," +
            "42.0";
        private static float[] pts;

        private boolean started = false;
        private float p = 0f;                       // 0..1 writing progress
        private ValueAnimator anim;
        private final Path full = new Path();
        private final Path seg = new Path();
        private PathMeasure pm;
        private float pathLen = 0f;
        private int builtW = -1, builtH = -1;
        private final float[] pos = new float[2];
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tip = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float core;
        private final float dp;

        HelloDrawable(float dp) {
            this.dp = dp;
            for (Paint pt : new Paint[]{glow, ink, hi}) {
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeCap(Paint.Cap.ROUND);
                pt.setStrokeJoin(Paint.Join.ROUND);
            }
        }

        void start() {
            if (started) return;
            started = true;
            p = 0f;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(T_WRITE);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator va) {
                    float t = (Float) va.getAnimatedValue();
                    p = 0.5f - 0.5f * (float) Math.cos(Math.PI * t);      // ease in / out
                    invalidateSelf();
                }
            });
            anim.start();
        }

        void stop() {
            if (anim != null) { anim.cancel(); anim = null; }
        }

        private void build(int w, int h) {
            if (pts == null) {
                String[] s = HELLO_PTS.split(",");
                float[] a = new float[s.length];
                for (int i = 0; i < s.length; i++) a[i] = Float.parseFloat(s[i]);
                pts = a;
            }
            float k = w * 0.76f / PW;
            float x0 = (w - PW * k) / 2f;
            float y0 = h * 0.47f - 36.85f * k;       // the path is 3 .. 70.7 high: centre it in the tile
            full.reset();
            for (int i = 0; i + 1 < pts.length; i += 2) {
                float x = x0 + pts[i] * k, y = y0 + pts[i + 1] * k;
                if (i == 0) full.moveTo(x, y);
                else full.lineTo(x, y);
            }
            pm = new PathMeasure(full, false);
            pathLen = pm.getLength();
            core = w * 0.030f;
            ink.setStrokeWidth(core);
            glow.setStrokeWidth(core * 2.2f);
            glow.setMaskFilter(new BlurMaskFilter(core * 1.4f, BlurMaskFilter.Blur.NORMAL));
            hi.setStrokeWidth(core * 0.26f);
            tip.setMaskFilter(new BlurMaskFilter(core * 0.9f, BlurMaskFilter.Blur.NORMAL));
            float gx0 = x0 + 2f * k, gx1 = x0 + 164f * k;
            ink.setShader(new LinearGradient(gx0, 0f, gx1, 0f,
                    new int[]{0xFF2FB5B5, 0xFFF2E100, 0xFFFF9E0A, 0xFFF2557F, 0xFFB07AD8, 0xFF3F83E8},
                    new float[]{0f, 0.14f, 0.32f, 0.52f, 0.76f, 1f}, Shader.TileMode.CLAMP));
            builtW = w;
            builtH = h;
        }

        @Override
        public void draw(Canvas c) {
            if (!started) return;
            Rect b = getBounds();
            int w = b.width(), h = b.height();
            if (w <= 0 || h <= 0) return;
            if (w != builtW || h != builtH) build(w, h);
            float e = p * pathLen;
            if (e < 0.5f) return;
            seg.reset();
            pm.getSegment(0f, e, seg, true);
            c.save();
            c.translate(b.left, b.top);
            glow.setColor(0x59FFFFFF);
            c.drawPath(seg, glow);                                   // soft glassy halo
            ink.setAlpha(255);
            c.drawPath(seg, ink);                                    // rainbow core
            hi.setColor(0xB4FFFFFF);
            c.save();
            c.translate(-core * 0.22f, -core * 0.28f);
            c.drawPath(seg, hi);                                     // specular line
            c.restore();
            if (p < 0.999f) {                                        // glowing pen tip
                pm.getPosTan(e, pos, null);
                tip.setColor(0xE6FFFFFF);
                c.drawCircle(pos[0], pos[1], core * 0.9f, tip);
            }
            c.restore();
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}

package com.dynamicpill.module;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/**
 * iOS style "100%" text next to the battery icon in the Control Center header.
 * The status bar is not touched: whatever the system "Battery indicator" option says
 * (icon only / percentage in icon / percentage outside) still applies there.
 */
final class CcBattery {
    private CcBattery() { }

    static final String K_CC_BATT = "cc_batt_pct";

    private static XSharedPreferences xsp;
    private static long lastReload = 0;

    static synchronized boolean enabled() {
        try {
            if (xsp == null) {
                xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                xsp.makeWorldReadable();
            }
            long now = System.currentTimeMillis();
            if (now - lastReload > 1000) {
                lastReload = now;
                if (xsp.hasFileChanged()) xsp.reload();
            }
            return xsp.getBoolean(K_CC_BATT, true);
        } catch (Throwable t) {
            return true;
        }
    }

    private static final java.util.WeakHashMap<View, PctText> ATTACHED = new java.util.WeakHashMap<>();

    /**
     * Called for every BatteryMeterView that attaches; does nothing outside the Control Center.
     * The % is NOT part of the header layout any more: it is a floating text (ViewOverlay of the Control Center
     * root) placed right above the carrier name ("ZONG"), so the header icons are never touched.
     */
    static void attach(View battery, boolean inControlCenter) {
        try {
            if (!inControlCenter) return;
            ViewGroup host = MainHook.ccRoot(battery);
            if (host == null) {
                XposedBridge.log("DynamicPill: CC root not found, skipped");
                return;
            }
            PctText old = ATTACHED.get(battery);
            if (old != null) {
                if (old.host == host && old.getParent() != null) return; // already added
                old.dispose();
            }
            PctText t = new PctText(battery.getContext(), battery, host);
            host.getOverlay().add(t);
            ATTACHED.put(battery, t);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CC battery attach failed: " + t);
        }
    }

    private static int lastStyleLog = -2;

    /**
     * The system "Battery indicator" option (Settings -> Notifications & status bar):
     * 0 = icon only, 1 = percentage in the icon, 2 = percentage next to the icon.
     * The in-icon number is drawn on a canvas (not a TextView), so it can only be detected from the setting.
     * Returns true when the system already shows the percentage somewhere (then we must stay hidden).
     */
    static boolean settingShowsPercent(Context c) {
        int style = -1;
        try {
            style = android.provider.Settings.System.getInt(c.getContentResolver(), "battery_indicator_style", -1);
        } catch (Throwable ignored) { }
        if (style != lastStyleLog) {
            lastStyleLog = style;
            XposedBridge.log("DynamicPill: battery_indicator_style=" + style);
        }
        if (style > 0) return true;
        if (style == 0) return false;
        try {
            return android.provider.Settings.System.getInt(c.getContentResolver(),
                    "status_bar_show_battery_percent", 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    /** True when the system itself already shows a percentage text inside the battery view. */
    private static boolean systemShowsPercent(View root, View ignore) {
        if (!(root instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) root;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == ignore) continue;
            if (c instanceof TextView) {
                CharSequence s = ((TextView) c).getText();
                if (s != null && s.length() > 0 && c.getVisibility() == View.VISIBLE
                        && c.getWidth() > 0 && c.getAlpha() > 0.1f
                        && Character.isDigit(s.charAt(0))) return true;
            } else if (systemShowsPercent(c, ignore)) {
                return true;
            }
        }
        return false;
    }

    /**
     * The "63%" text. Floating overlay (no layout space at all) shown right above the carrier name.
     * Pure fade in / fade out in place (no sliding). It fades in only after the Control Center header has
     * settled (fully open, opaque, not moving) and fades out the instant the header starts to move / fade.
     */
    static final class PctText extends TextView {
        private final View battery;
        final ViewGroup host;
        private int level = -1;
        private boolean registered = false;

        private boolean baseWant = false;   // setting / system state says "we may show"
        private boolean open = false;       // currently revealed (or revealing)
        private float af = 0f;              // opacity of the text
        private boolean forced = false;
        private boolean first = true;
        private int pend = 0;
        private android.animation.ValueAnimator anim;
        private View carrier;               // the carrier name view ("ZONG"), if found
        private long lastFind = 0;
        private final float dp;
        private final int[] loc = new int[2];
        private final int[] hloc = new int[2];
        private int lastL = Integer.MIN_VALUE, lastT = Integer.MIN_VALUE;
        private float lastSize = -1f;

        private final BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) { read(i); forced = true; sync(); }
        };

        // fires the moment the user changes "Battery indicator" in Settings
        private final android.database.ContentObserver styleObs =
                new android.database.ContentObserver(new android.os.Handler(android.os.Looper.getMainLooper())) {
            @Override
            public void onChange(boolean selfChange) { forced = true; sync(); }
        };

        // follows the battery / carrier every frame, so the text moves exactly with the header
        private final android.view.ViewTreeObserver.OnPreDrawListener pre =
                new android.view.ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() { if (af > 0.003f) place(); return true; }
        };
        private android.view.ViewTreeObserver obs;

        // slow loop: re-evaluates the (expensive) base decision
        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                sync();
                if (isAttachedToWindow()) postDelayed(this, 1000);
            }
        };

        private float lastHf = 0f, lastA = 0f, settledHf = 0f, settledA = 1f;
        private int lastY = Integer.MIN_VALUE, settledY = 0;
        private long stableSince = 0;

        private float effAlpha(View v) {
            float a = 1f;
            View c = v;
            for (int i = 0; i < 16 && c != null; i++) {
                a *= c.getAlpha();
                c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
            }
            return a;
        }

        private final Runnable fast = new Runnable() {
            @Override
            public void run() {
                long delay = 300;
                try {
                    if (!battery.isShown()) {
                        if (open || af > 0f || getVisibility() != View.GONE) hideNow();
                        lastY = Integer.MIN_VALUE;
                    } else {
                        delay = 40;
                        battery.getLocationOnScreen(loc);
                        float hf = PillController.ccHeightFrac;
                        float a = effAlpha(battery);
                        long now = android.os.SystemClock.uptimeMillis();
                        boolean steady = lastY != Integer.MIN_VALUE
                                && Math.abs(loc[1] - lastY) <= 1
                                && Math.abs(a - lastA) < 0.01f
                                && Math.abs(hf - lastHf) < 0.002f;
                        if (!steady) stableSince = now;
                        lastY = loc[1]; lastA = a; lastHf = hf;
                        if (!open) {
                            if (baseWant && steady && a >= 0.95f && hf >= 0.30f && now - stableSince >= 160) {
                                open = true;
                                settledY = loc[1]; settledA = a; settledHf = hf;
                                findCarrier(true);
                                place();
                                animateTo(1f);
                            }
                        } else if (!baseWant || Math.abs(loc[1] - settledY) > 2
                                || a < settledA - 0.03f || hf < settledHf - 0.008f) {
                            open = false;
                            animateTo(0f);
                        }
                    }
                } catch (Throwable ignored) { }
                if (isAttachedToWindow()) postDelayed(this, delay);
            }
        };

        PctText(Context ctx, View battery, ViewGroup host) {
            super(ctx);
            this.battery = battery;
            this.host = host;
            dp = ctx.getResources().getDisplayMetrics().density;
            setTextColor(Color.WHITE);
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            setSingleLine(true);
            setIncludeFontPadding(false);
            setPadding(0, 0, 0, 0);
            setAlpha(0f);
            setVisibility(View.GONE);
        }

        void dispose() {
            try { removeCallbacks(loop); removeCallbacks(fast); } catch (Throwable ignored) { }
            try { if (anim != null) anim.cancel(); } catch (Throwable ignored) { }
            try { host.getOverlay().remove(this); } catch (Throwable ignored) { }
        }

        private void read(Intent i) {
            if (i == null) return;
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
        }

        /** Looks for the carrier name text ("ZONG") in the Control Center, above the battery row. */
        private void findCarrier(boolean force) {
            long now = android.os.SystemClock.uptimeMillis();
            if (!force && carrier != null && carrier.isShown()) return;
            if (!force && now - lastFind < 500) return;
            lastFind = now;
            carrier = null;
            try {
                battery.getLocationOnScreen(loc);
                int battTop = loc[1];
                View[] best = new View[1];
                scan(host, battTop, best, new int[]{0});
                carrier = best[0];
            } catch (Throwable ignored) { }
        }

        private boolean looksLikeCarrier(View v) {
            String cn = v.getClass().getName().toLowerCase();
            if (cn.contains("carrier") || cn.contains("operator")) return true;
            try {
                if (v.getId() != View.NO_ID) {
                    String n = v.getResources().getResourceEntryName(v.getId()).toLowerCase();
                    if (n.contains("carrier") || n.contains("operator") || n.contains("plmn")) return true;
                }
            } catch (Throwable ignored) { }
            return false;
        }

        private void scan(View v, int battTop, View[] best, int[] count) {
            if (best[0] != null || count[0]++ > 4000 || v == this) return;
            if (v instanceof TextView && v != this && looksLikeCarrier(v)) {
                CharSequence t = ((TextView) v).getText();
                if (t != null && t.length() > 0 && v.isShown() && v.getWidth() > 0) {
                    v.getLocationOnScreen(hloc);
                    if (hloc[1] <= battTop) { best[0] = v; return; }
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    scan(g.getChildAt(i), battTop, best, count);
                    if (best[0] != null) return;
                }
            }
        }

        /** Right edge aligned with the carrier name, text sits just above it. */
        private void place() {
            try {
                findCarrier(false);
                host.getLocationOnScreen(hloc);
                int hx = hloc[0], hy = hloc[1];
                int right, top;
                measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                int w = getMeasuredWidth(), h = getMeasuredHeight();
                if (carrier != null && carrier.isShown()) {
                    carrier.getLocationOnScreen(loc);
                    right = loc[0] + carrier.getWidth();
                    top = loc[1] - h - Math.round(dp * 2f);
                } else {
                    battery.getLocationOnScreen(loc);
                    right = loc[0] + battery.getWidth();
                    top = loc[1] - h - Math.round(dp * 26f);
                }
                int l = right - w - hx;
                int t = top - hy;
                if (l != lastL || t != lastT || w != getWidth() || h != getHeight()) {
                    lastL = l; lastT = t;
                    layout(l, t, l + w, t + h);
                }
            } catch (Throwable ignored) { }
        }

        /** Pure fade, in place. In: smoothstep 320 ms. Out: fast 150 ms. */
        private void animateTo(float to) {
            if (anim != null) anim.cancel();
            if (to > 0f && getVisibility() != View.VISIBLE) setVisibility(View.VISIBLE);
            final boolean in = to > 0f;
            final float a0 = af;
            anim = android.animation.ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(in ? 320 : 150);
            anim.setInterpolator(new android.view.animation.LinearInterpolator());
            anim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(android.animation.ValueAnimator va) {
                    float t = (Float) va.getAnimatedValue();
                    float k = t * t * (3f - 2f * t);
                    af = in ? a0 + (1f - a0) * k : a0 * (1f - k);
                    setAlpha(af);
                    invalidate();
                }
            });
            anim.start();
        }

        private void hideNow() {
            if (anim != null) anim.cancel();
            open = false;
            af = 0f;
            setAlpha(0f);
            if (getVisibility() != View.GONE) setVisibility(View.GONE);
        }

        private void sync() {
            try {
                if (!first && !forced && !battery.isShown()) return;
                forced = false;
                if (level >= 0) {
                    String s = level + "%";
                    if (!s.contentEquals(getText())) { setText(s); if (open) place(); }
                }
                boolean bySetting = settingShowsPercent(getContext());
                boolean want = level >= 0 && enabled() && !bySetting && !systemShowsPercent(battery, this);
                if (bySetting || first) {        // system shows %: stay hidden at once
                    first = false;
                    pend = 0;
                    baseWant = want;
                    if (!want) hideNow();
                    return;
                }
                if (want == baseWant) { pend = 0; return; }
                if (++pend >= 2) {               // must stay changed for 2 checks: no flicker
                    pend = 0;
                    baseWant = want;
                    if (!want) hideNow();
                }
            } catch (Throwable ignored) { }
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            try {
                if (!registered) {
                    read(getContext().registerReceiver(rcv, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
                    registered = true;
                }
            } catch (Throwable ignored) { }
            try {
                getContext().getContentResolver().registerContentObserver(
                        android.provider.Settings.System.getUriFor("battery_indicator_style"), false, styleObs);
            } catch (Throwable ignored) { }
            try {
                obs = battery.getViewTreeObserver();
                if (obs.isAlive()) obs.addOnPreDrawListener(pre);
            } catch (Throwable ignored) { }
            removeCallbacks(loop);
            removeCallbacks(fast);
            sync();
            postDelayed(loop, 1000);
            post(fast);
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            removeCallbacks(loop);
            removeCallbacks(fast);
            if (anim != null) anim.cancel();
            try { if (obs != null && obs.isAlive()) obs.removeOnPreDrawListener(pre); } catch (Throwable ignored) { }
            obs = null;
            try { getContext().getContentResolver().unregisterContentObserver(styleObs); } catch (Throwable ignored) { }
            try {
                if (registered) getContext().unregisterReceiver(rcv);
            } catch (Throwable ignored) { }
            registered = false;
        }
    }
}

Dynamic Pill (LSPosed module) v2.2
1. Upload this zip's contents to a GitHub repo (the .github/workflows/build.yml is included).
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot. Open settings from the "Dynamic Pill" Control Center tile (long press) or from LSPosed.

Changes in 2.2
- Status Bar Padding (Left / Right / Top) removed completely: settings section, status bar height hook,
  content insets hook, keyguard/status bar view tracking. System UI status bar is left untouched.
- Pill is centred on the real camera cutout / status bar height again (no padding offset).
- Slider no longer gets stuck capturing touches when the gesture is cancelled.

Changes in 2.3
- New switch "Battery % in Control Center (iOS style)" (settings -> CONTROL CENTER, on by default).
  Shows "66%" before the battery icon in the Control Center header. The status bar is untouched, so with
  Settings -> Notifications & status bar -> Battery indicator = icon only, the status bar has no percentage
  and only the Control Center shows it. If the system already shows a percentage text there, ours hides itself.

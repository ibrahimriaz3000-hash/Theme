package com.dynamicpill.module;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/**
 * iOS style "100%" text next to the battery icon in the Control Center header.
 * The status bar is not touched: whatever the system "Battery indicator" option says
 * (icon only / percentage in icon / percentage outside) still applies there.
 */
final class CcBattery {
    private CcBattery() { }

    static final String K_CC_BATT = "cc_batt_pct";

    private static XSharedPreferences xsp;
    private static long lastReload = 0;

    static synchronized boolean enabled() {
        try {
            if (xsp == null) {
                xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                xsp.makeWorldReadable();
            }
            long now = System.currentTimeMillis();
            if (now - lastReload > 1000) {
                lastReload = now;
                if (xsp.hasFileChanged()) xsp.reload();
            }
            return xsp.getBoolean(K_CC_BATT, true);
        } catch (Throwable t) {
            return true;
        }
    }

    /** Called for every BatteryMeterView that attaches; does nothing outside the Control Center. */
    static void attach(View battery, boolean inControlCenter) {
        try {
            if (!inControlCenter) return;
            ViewGroup host;
            int index;
            if (battery instanceof LinearLayout) {
                host = (ViewGroup) battery;
                index = 0; // text first, icon last: "100% [battery]"
            } else if (battery.getParent() instanceof LinearLayout) {
                host = (ViewGroup) battery.getParent();
                index = host.indexOfChild(battery);
            } else {
                XposedBridge.log("DynamicPill: CC battery host is not a LinearLayout, skipped");
                return;
            }
            for (int i = 0; i < host.getChildCount(); i++) {
                if (host.getChildAt(i) instanceof PctText) return; // already added
            }
            PctText t = new PctText(battery.getContext(), battery);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = android.view.Gravity.CENTER_VERTICAL;
            host.addView(t, Math.max(0, index), lp);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CC battery attach failed: " + t);
        }
    }

    /** True when the system itself already shows a percentage text inside the battery view. */
    private static boolean systemShowsPercent(View root, View ignore) {
        if (!(root instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) root;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == ignore) continue;
            if (c instanceof TextView) {
                CharSequence s = ((TextView) c).getText();
                if (s != null && s.length() > 0 && c.getVisibility() == View.VISIBLE
                        && c.getWidth() > 0 && c.getAlpha() > 0.1f
                        && Character.isDigit(s.charAt(0))) return true;
            } else if (systemShowsPercent(c, ignore)) {
                return true;
            }
        }
        return false;
    }

    static final class PctText extends TextView {
        private final View battery;
        private int level = -1;
        private boolean registered = false;

        private final BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) { read(i); sync(); }
        };

        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                sync();
                if (isAttachedToWindow()) postDelayed(this, 1000);
            }
        };

        PctText(Context ctx, View battery) {
            super(ctx);
            this.battery = battery;
            setTextColor(Color.WHITE);
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            setSingleLine(true);
            setIncludeFontPadding(false);
            int p = Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 3,
                    ctx.getResources().getDisplayMetrics()));
            setPadding(0, 0, p, 0);
            setVisibility(View.GONE);
        }

        private void read(Intent i) {
            if (i == null) return;
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
        }

        private void sync() {
            try {
                boolean show = level >= 0 && enabled() && !systemShowsPercent(battery, this);
                if (show) setText(level + "%");
                int vis = show ? View.VISIBLE : View.GONE;
                if (getVisibility() != vis) setVisibility(vis);
            } catch (Throwable ignored) { }
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            try {
                if (!registered) {
                    read(getContext().registerReceiver(rcv, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
                    registered = true;
                }
            } catch (Throwable ignored) { }
            removeCallbacks(loop);
            post(loop);
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            removeCallbacks(loop);
            try {
                if (registered) getContext().unregisterReceiver(rcv);
            } catch (Throwable ignored) { }
            registered = false;
        }
    }
}

package com.dynamicpill.module;

import android.content.res.Resources;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Status bar height / padding taken over from the Iconify idea: System UI reads its status bar size from
 * a handful of dimen resources (status_bar_height*, status_bar_padding_start / end / top and the icon
 * padding ones). Here those dimens are answered with the values chosen in the settings screen.
 * 0 in a slider = "Default" (the resource is left untouched). Applies when System UI restarts.
 */
final class StatusBarSize {
    static final String K_H = "sbs_height_dp";
    static final String K_START = "sbs_pad_start_dp";
    static final String K_END = "sbs_pad_end_dp";
    static final String K_TOP = "sbs_pad_top_dp";
    static final String K_ICON_START = "sbs_icon_pad_start_dp";
    static final String K_ICON_END = "sbs_icon_pad_end_dp";

    private static final int G_NONE = 0, G_H = 1, G_START = 2, G_END = 3, G_TOP = 4, G_ICON_START = 5, G_ICON_END = 6;

    private static final ConcurrentHashMap<Integer, Integer> GROUP = new ConcurrentHashMap<>();
    private static XSharedPreferences xsp;
    private static volatile int[] vals = new int[7];     // dp per group, 0 = default
    private static volatile long lastLoad = 0;

    /** Dimen names of the AOSP / Iconify / MIUI (MiuiSystemUI) status bar that belong to each slider. */
    private static int groupOf(String name) {
        if (name == null) return G_NONE;
        switch (name) {
            case "status_bar_height":
            case "status_bar_height_default":
            case "status_bar_height_portrait":
                return G_H;
            case "status_bar_padding_start":
                return G_START;
            case "status_bar_padding_end":
                return G_END;
            case "status_bar_padding_top":
                return G_TOP;
            case "status_bar_icons_padding_start":
            case "status_bar_clock_starting_padding":
            case "status_bar_left_clock_starting_padding":
                return G_ICON_START;
            case "status_bar_icons_padding_end":
            case "status_bar_clock_end_padding":
            case "status_bar_left_clock_end_padding":
            case "status_bar_notification_padding_end":
                return G_ICON_END;
            default:
                return G_NONE;
        }
    }

    /** Changes whenever one of the sliders changes (used to re-apply the bar live). */
    static int signature() {
        int[] v = load();
        int h = 17;
        for (int x : v) h = h * 31 + x;
        return h;
    }

    private static int[] load() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastLoad < 1500) return vals;
        lastLoad = now;
        try {
            if (xsp == null) xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
            if (xsp.hasFileChanged()) xsp.reload();
            int[] v = new int[7];
            v[G_H] = xsp.getInt(K_H, 0);
            v[G_START] = xsp.getInt(K_START, 0);
            v[G_END] = xsp.getInt(K_END, 0);
            v[G_TOP] = xsp.getInt(K_TOP, 0);
            v[G_ICON_START] = xsp.getInt(K_ICON_START, 0);
            v[G_ICON_END] = xsp.getInt(K_ICON_END, 0);
            vals = v;
        } catch (Throwable ignored) { }
        return vals;
    }

    private static int group(Resources r, int id) {
        if (id == 0) return G_NONE;
        Integer g = GROUP.get(id);
        if (g != null) return g;
        int gr = G_NONE;
        try { gr = groupOf(r.getResourceEntryName(id)); } catch (Throwable ignored) { }
        GROUP.put(id, gr);
        return gr;
    }

    /** px for the group, or -1 when it stays at the system value. */
    private static int override(Resources r, int id) {
        int g = group(r, id);
        if (g == G_NONE) return -1;
        int dp = load()[g];
        if (dp <= 0) return -1;
        return Math.round(dp * r.getDisplayMetrics().density);
    }

    static void hook() {
        try {
            XposedHelpers.findAndHookMethod(Resources.class, "getDimensionPixelSize", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        int px = override((Resources) p.thisObject, (Integer) p.args[0]);
                        if (px >= 0) p.setResult(px);
                    } catch (Throwable ignored) { }
                }
            });
            XposedHelpers.findAndHookMethod(Resources.class, "getDimensionPixelOffset", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        int px = override((Resources) p.thisObject, (Integer) p.args[0]);
                        if (px >= 0) p.setResult(px);
                    } catch (Throwable ignored) { }
                }
            });
            XposedHelpers.findAndHookMethod(Resources.class, "getDimension", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        int px = override((Resources) p.thisObject, (Integer) p.args[0]);
                        if (px >= 0) p.setResult((float) px);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: status bar size hook failed: " + t);
        }
    }
}

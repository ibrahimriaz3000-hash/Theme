package com.dynamicpill.module;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.WeakHashMap;

/**
 * Tile card: replaces the media player card of the Control Center (MediaPlayerPanel, MIUISystemUIPlugin.apk)
 * with a 2x2 card of round tiles.
 *
 * - The tiles of the card are taken OUT of the main tile list (QSListController.getListItems is filtered), so the
 *   grid closes up and no gap is left. The tile objects stay alive (QSRecord.tile), the card shows their state
 *   (QSTile.getState(): state, icon) and a tap on a circle calls QSTile.click().
 * - Edit screen: the card is shown there too. Tap a tile in the edit grid = put it into the card (max 4),
 *   tap it again (or tap its circle in the card) = take it out of the card.
 * - The chosen tiles are kept in System UI's own preferences. Everything is wrapped in try/catch.
 */
final class TileCard {
    static final String SP_NAME = "dynamicpill_cc_tiles", SP_KEY = "specs";
    private static final String DEFAULT_SPECS = "cell,wifi,airplane";
    private static final int MAX = 4;
    private static final String MODE_CLASS = "miui.systemui.controlcenter.panel.main.MainPanelModeController$MainPanelMode";

    /** spec -> latest QSRecord seen in the tile list (weak). */
    private static final HashMap<String, WeakReference<Object>> RECORDS = new HashMap<>();
    private static final WeakHashMap<View, Card> CARDS = new WeakHashMap<>();
    private static volatile boolean editMode = false;
    private static volatile Context ctx;
    private static boolean tapHooked = false, redistributing = false;
    private static final WeakHashMap<ClassLoader, Boolean> HOOKED = new WeakHashMap<>();
    static final String LIST_CLASS = "miui.systemui.controlcenter.panel.main.qs.QSListController";

    private TileCard() { }

    // ---------------------------------------------------------------- selection (System UI's own prefs)

    private static SharedPreferences sp() {
        Context c = ctx;
        return c == null ? null : c.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
    }

    static LinkedHashSet<String> selected() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try {
            SharedPreferences p = sp();
            String csv = p == null ? DEFAULT_SPECS : p.getString(SP_KEY, DEFAULT_SPECS);
            if (csv == null) csv = DEFAULT_SPECS;
            for (String x : csv.split(",")) if (x.trim().length() > 0) s.add(x.trim());
        } catch (Throwable ignored) { }
        return s;
    }

    private static void save(LinkedHashSet<String> s) {
        try {
            SharedPreferences p = sp();
            if (p == null) return;
            StringBuilder sb = new StringBuilder();
            for (String x : s) { if (sb.length() > 0) sb.append(','); sb.append(x); }
            p.edit().putString(SP_KEY, sb.toString()).apply();
        } catch (Throwable ignored) { }
    }

    /** Put the spec into the card, or take it out when it is already there. */
    private static void toggle(String spec) {
        LinkedHashSet<String> s = selected();
        if (!s.remove(spec)) {
            if (s.size() >= MAX) return;
            s.add(spec);
        }
        save(s);
    }

    // ---------------------------------------------------------------- hooks (plug-in class loader)

    static void hookPlugin(final ClassLoader cl) {
        if (cl == null) return;
        synchronized (HOOKED) {
            if (HOOKED.containsKey(cl)) return;
            HOOKED.put(cl, Boolean.TRUE);
        }
        XposedBridge.log("DynamicPill: tile card hooks go on, class loader " + cl);
        // 1) the tile list: remember every QSRecord, and leave the card's tiles out of the normal grid
        try {
            XposedHelpers.findAndHookMethod("miui.systemui.controlcenter.panel.main.qs.QSListController", cl,
                    "getListItems", new XC_MethodHook() {
                private boolean logged = false;
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (!logged) { logged = true; XposedBridge.log("DynamicPill: tile list hook is running"); }
                        p.setResult(filter(p.thisObject, (List<?>) p.getResult()));
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: tile list hook failed: " + t); }
        // 2) when the mode changes (normal <-> edit) the list is distributed again so the grid is re-filtered
        try {
            XposedHelpers.findAndHookMethod("miui.systemui.controlcenter.panel.main.qs.QSListController", cl,
                    "onModeChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (redistributing || !ControlCenterSize.tileCardOn()) return;
                        redistributing = true;
                        try { XposedHelpers.callMethod(p.thisObject, "distributeTiles"); } finally { redistributing = false; }
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: mode hook failed: " + t); }
        // 3) the media card slot is also shown in the edit screen
        try {
            Class<?> mode = XposedHelpers.findClass(MODE_CLASS, cl);
            XposedHelpers.findAndHookMethod("miui.systemui.controlcenter.panel.main.media.MediaPlayerController", cl,
                    "available", boolean.class, mode, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args[1] != null && p.args[1].toString().contains("EDIT") && ControlCenterSize.tileCardOn())
                            p.setResult(true);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: media slot hook failed: " + t); }
        // 4) edit screen: a tap on a tile puts it into / takes it out of the card
        if (tapHooked) return;
        tapHooked = true;
        try {
            XposedHelpers.findAndHookMethod(View.class, "performClick", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        View v = (View) p.thisObject;
                        String cn = v.getClass().getName();
                        if (!(cn.endsWith("QSTileItemView") || cn.endsWith("QSCardItemView"))) return;
                        if (editTap(v)) p.setResult(true);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: edit tap hook failed: " + t); }
    }

    private static boolean editTap(View v) {
        if (!ControlCenterSize.tileCardOn()) return false;
        Object m = XposedHelpers.getObjectField(v, "mode");
        if (m == null || !m.toString().contains("EDIT")) return false;
        String spec = null;
        for (String f : new String[]{"state", "customizeState"}) {
            try {
                Object st = XposedHelpers.getObjectField(v, f);
                Object sp = st == null ? null : XposedHelpers.getObjectField(st, "spec");
                if (sp instanceof String) { spec = (String) sp; break; }
            } catch (Throwable ignored) { }
        }
        if (spec == null) return false;
        toggle(spec);
        return true;
    }

    /** Called with the controller's own list: records are remembered, the card's tiles are left out. */
    private static List<?> filter(Object controller, List<?> items) {
        if (items == null) return null;
        try {
            Object c = XposedHelpers.getObjectField(controller, "sysUIContext");
            if (c instanceof Context) ctx = (Context) c;
        } catch (Throwable ignored) { }
        boolean edit = false;
        synchronized (RECORDS) {
            for (Object it : items) {
                if (it == null) continue;
                String cn = it.getClass().getName();
                if (cn.contains("EditModeDivider")) edit = true;
                if (cn.endsWith("QSRecord")) {
                    try {
                        Object sp = XposedHelpers.getObjectField(it, "spec");
                        if (sp instanceof String) RECORDS.put((String) sp, new WeakReference<>(it));
                    } catch (Throwable ignored) { }
                }
            }
        }
        editMode = edit;
        if (edit || !ControlCenterSize.tileCardOn()) return items;
        LinkedHashSet<String> sel = selected();
        if (sel.isEmpty()) return items;
        ArrayList<Object> out = new ArrayList<>(items.size());
        for (Object it : items) {
            boolean drop = false;
            if (it != null && it.getClass().getName().endsWith("QSRecord")) {
                try {
                    Object sp = XposedHelpers.getObjectField(it, "spec");
                    drop = sp instanceof String && sel.contains(sp);
                } catch (Throwable ignored) { }
            }
            if (!drop) out.add(it);
        }
        return out;
    }

    // ---------------------------------------------------------------- the card (inside MediaPlayerPanel)

    static void registerPanel(final View p) {
        try {
            if (!(p instanceof ViewGroup) || !ControlCenterSize.tileCardOn()) return;
            hookPlugin(p.getClass().getClassLoader());
            p.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (CARDS.containsKey(p) || !ControlCenterSize.tileCardOn()) return;
                        if (ctx == null) ctx = p.getContext();
                        Card c = new Card(p.getContext(), (ViewGroup) p);
                        CARDS.put(p, c);
                        ((ViewGroup) p).addView(c, new ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    } catch (Throwable t) {
                        XposedBridge.log("DynamicPill: tile card failed: " + t);
                    }
                }
            });
        } catch (Throwable ignored) { }
    }

    /** The real tile (QSRecord.tile) of an added tile, or null. */
    private static Object tileOf(String spec) {
        try {
            WeakReference<Object> r;
            synchronized (RECORDS) { r = RECORDS.get(spec); }
            Object rec = r == null ? null : r.get();
            if (rec == null) return null;
            try { if (!XposedHelpers.getBooleanField(rec, "added")) return null; } catch (Throwable ignored) { }
            return XposedHelpers.getObjectField(rec, "tile");
        } catch (Throwable t) { return null; }
    }

    /** One round tile: draws the tile's own icon (or its first letter) on a light / grey disc. */
    private static final class Circle extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Drawable icon;
        String letter = "";
        boolean active;
        Circle(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), h = getHeight();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(active ? 0xFFF7F4F4 : 0x66808080);
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, paint);
            if (icon != null) {
                int in = Math.round(Math.min(w, h) * 0.27f);
                icon.setBounds(in, in, w - in, h - in);
                icon.draw(cv);
            } else if (letter.length() > 0) {
                paint.setColor(active ? 0xFF3D8BFF : Color.WHITE);
                paint.setTextSize(Math.min(w, h) * 0.4f);
                paint.setTextAlign(Paint.Align.CENTER);
                cv.drawText(letter, w / 2f, h / 2f + paint.getTextSize() * 0.35f, paint);
            }
        }
    }

    private static final class Card extends FrameLayout {
        private final ViewGroup panel;
        private final ArrayList<Circle> circles = new ArrayList<>();
        private final String[] circleSpec = new String[MAX];
        private final WeakHashMap<View, Integer> panelHidden = new WeakHashMap<>();
        private final Runnable tickR = new Runnable() { @Override public void run() { tick(); } };

        Card(Context c, ViewGroup panel) {
            super(c);
            this.panel = panel;
            setClipChildren(false);
            for (int i = 0; i < MAX; i++) {
                final int idx = i;
                Circle ci = new Circle(c);
                ci.setVisibility(GONE);
                ci.setOnClickListener(new OnClickListener() {
                    @Override public void onClick(View v) { tap(idx, false); }
                });
                ci.setOnLongClickListener(new OnLongClickListener() {
                    @Override public boolean onLongClick(View v) { return tap(idx, true); }
                });
                circles.add(ci);
                addView(ci);
            }
        }

        private int dpi(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            removeCallbacks(tickR);
            post(tickR);
        }

        @Override protected void onDetachedFromWindow() {
            removeCallbacks(tickR);
            super.onDetachedFromWindow();
        }

        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l, h = b - t;
            int pad = dpi(12);
            int cell = Math.max(1, Math.min(w - 2 * pad, h - 2 * pad) / 2);
            int d = Math.max(1, Math.round(cell * 0.86f));
            int ox = (w - 2 * cell) / 2, oy = (h - 2 * cell) / 2;
            for (int i = 0; i < MAX; i++) {
                Circle ci = circles.get(i);
                int cx = ox + (i % 2) * cell + cell / 2, cy = oy + (i / 2) * cell + cell / 2;
                ci.measure(MeasureSpec.makeMeasureSpec(d, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(d, MeasureSpec.EXACTLY));
                ci.layout(cx - d / 2, cy - d / 2, cx + d / 2, cy + d / 2);
            }
        }

        /** Normal screen: toggle the real tile. Edit screen: take the tile out of the card. */
        private boolean tap(int idx, boolean longClick) {
            try {
                String spec = circleSpec[idx];
                if (spec == null) return false;
                if (editMode && !longClick) { toggle(spec); return true; }
                Object tile = tileOf(spec);
                if (tile == null) return false;
                XposedHelpers.callMethod(tile, longClick ? "longClick" : "click");
                return true;
            } catch (Throwable t) { return false; }
        }

        private void tick() {
            try {
                if (!isAttachedToWindow()) return;
                if (!ControlCenterSize.tileCardOn()) {
                    setVisibility(GONE);
                    restorePanel();
                    postDelayed(tickR, 1500);
                    return;
                }
                setVisibility(VISIBLE);
                hidePanelChildren();
                update();
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: tile card tick failed: " + t);
            }
            try { postDelayed(tickR, 350); } catch (Throwable ignored) { }
        }

        private void hidePanelChildren() {
            for (int i = 0; i < panel.getChildCount(); i++) {
                View c = panel.getChildAt(i);
                if (c == this) continue;
                if (!panelHidden.containsKey(c)) panelHidden.put(c, c.getVisibility());
                if (c.getVisibility() != GONE) c.setVisibility(GONE);
            }
        }

        private void restorePanel() {
            try {
                for (View c : new ArrayList<>(panelHidden.keySet())) {
                    Integer o = panelHidden.remove(c);
                    c.setVisibility(o == null ? VISIBLE : o);
                }
            } catch (Throwable ignored) { }
        }

        private void update() {
            int n = 0;
            for (String spec : selected()) {
                if (n >= MAX) break;
                Object tile = tileOf(spec);
                if (tile == null) continue;
                Object st;
                try { st = XposedHelpers.callMethod(tile, "getState"); } catch (Throwable t) { continue; }
                if (st == null) continue;
                Circle ci = circles.get(n);
                circleSpec[n] = spec;
                int state = 0;
                try { state = XposedHelpers.getIntField(st, "state"); } catch (Throwable ignored) { }
                boolean active = state == 2;
                Drawable d = iconOf(st);
                CharSequence label = null;
                try { label = (CharSequence) XposedHelpers.getObjectField(st, "label"); } catch (Throwable ignored) { }
                String letter = label != null && label.length() > 0 ? label.toString().substring(0, 1).toUpperCase() : "";
                if (d != null) {
                    try { d = d.mutate(); d.setTint(active ? 0xFF3D8BFF : Color.WHITE); } catch (Throwable ignored) { }
                }
                ci.icon = d;
                ci.letter = letter;
                ci.active = active;
                ci.setAlpha(state == 0 ? 0.4f : 1f);
                ci.setVisibility(VISIBLE);
                ci.invalidate();
                n++;
            }
            for (int i = n; i < MAX; i++) { circleSpec[i] = null; circles.get(i).setVisibility(GONE); }
        }

        private Drawable iconOf(Object st) {
            Object icon = null;
            try { icon = XposedHelpers.getObjectField(st, "icon"); } catch (Throwable ignored) { }
            if (icon == null) {
                try {
                    Object sup = XposedHelpers.getObjectField(st, "iconSupplier");
                    if (sup instanceof java.util.function.Supplier) icon = ((java.util.function.Supplier<?>) sup).get();
                } catch (Throwable ignored) { }
            }
            try {
                if (icon instanceof Drawable) return (Drawable) icon;
                if (icon != null) {
                    Object d = XposedHelpers.callMethod(icon, "getDrawable", getContext());
                    if (d instanceof Drawable) return (Drawable) d;
                }
            } catch (Throwable ignored) { }
            return null;
        }
    }
}

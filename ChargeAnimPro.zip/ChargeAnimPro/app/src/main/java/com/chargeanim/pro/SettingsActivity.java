package com.chargeanim.pro;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

@SuppressWarnings({"deprecation", "SetTextI18n"})
public class SettingsActivity extends Activity {

    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = openPrefs();

        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        root.addView(title("Charging Animation"));
        root.addView(note("Yahan se SystemUI ki charging animation change hoti hai. "
                + "Badlav ke baad \"Apply\" dabao (root se SystemUI restart hota hai)."));

        // ---- Style ----
        root.addView(section("Animation style"));
        final RadioGroup group = new RadioGroup(this);
        final String[] names = {"System default", "Classic", "Video", "Wave", "Particle"};
        final int[] values = {-1, 0, 1, 2, 3};
        int cur = sp.getInt(Cfg.KEY_STYLE, -1);
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(1000 + i);
            group.addView(rb);
            if (values[i] == cur) rb.setChecked(true);
        }
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                sp.edit().putInt(Cfg.KEY_STYLE, values[id - 1000]).apply();
                makeReadable();
            }
        });
        root.addView(group);
        root.addView(note("Video style kuch devices par khali dikh sakti hai, kyunke wired video files "
                + "SystemUI APK mein maujood nahi hoti."));

        // ---- Disable ----
        root.addView(section("Options"));
        root.addView(sw("Charging animation band karo", Cfg.KEY_DISABLE));
        root.addView(sw("Wired charging ripple band karo", Cfg.KEY_NO_RIPPLE));

        // ---- Duration ----
        root.addView(section("Animation ka waqt"));
        final TextView durLabel = new TextView(this);
        int curDur = sp.getInt(Cfg.KEY_DURATION, 0);
        durLabel.setText(durText(curDur));
        root.addView(durLabel);
        SeekBar bar = new SeekBar(this);
        bar.setMax(20); // 0..20 => 0..10000 ms, 500 ms step
        bar.setProgress(curDur / 500);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                durLabel.setText(durText(p * 500));
                if (user) {
                    sp.edit().putInt(Cfg.KEY_DURATION, p * 500).apply();
                    makeReadable();
                }
            }

            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(bar);

        // ---- Apply ----
        Button apply = new Button(this);
        apply.setText("Apply (SystemUI restart)");
        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeReadable();
                try {
                    Runtime.getRuntime().exec(new String[]{"su", "-c",
                            "pkill -f com.android.systemui || killall com.android.systemui"});
                    Toast.makeText(SettingsActivity.this, "SystemUI restart ho raha hai", Toast.LENGTH_SHORT).show();
                } catch (Throwable t) {
                    Toast.makeText(SettingsActivity.this,
                            "Root nahi mila. Phone restart kar do.", Toast.LENGTH_LONG).show();
                }
            }
        });
        root.addView(apply);

        ScrollView sv = new ScrollView(this);
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
    }

    private SharedPreferences openPrefs() {
        try {
            return getSharedPreferences(Cfg.FILE, Context.MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences(Cfg.FILE, Context.MODE_PRIVATE);
        }
    }

    /** Agar LSPosed ka world-readable support na chale to file permissions khud kholo. */
    private void makeReadable() {
        try {
            File data = new File(getApplicationInfo().dataDir);
            File dir = new File(data, "shared_prefs");
            File f = new File(dir, Cfg.FILE + ".xml");
            data.setExecutable(true, false);
            dir.setExecutable(true, false);
            dir.setReadable(true, false);
            f.setReadable(true, false);
        } catch (Throwable ignored) {
        }
    }

    private String durText(int ms) {
        return ms == 0 ? "Default (system ka apna waqt)" : (ms / 1000f) + " second";
    }

    private Switch sw(String label, final String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setChecked(sp.getBoolean(key, false));
        s.setPadding(0, dp(8), 0, dp(8));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean on) {
                sp.edit().putBoolean(key, on).apply();
                makeReadable();
            }
        });
        return s;
    }

    private TextView title(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(24);
        v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    private TextView section(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(16);
        v.setTypeface(null, Typeface.BOLD);
        v.setPadding(0, dp(20), 0, dp(6));
        return v;
    }

    private TextView note(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(13);
        v.setAlpha(0.7f);
        v.setPadding(0, dp(6), 0, dp(6));
        return v;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}

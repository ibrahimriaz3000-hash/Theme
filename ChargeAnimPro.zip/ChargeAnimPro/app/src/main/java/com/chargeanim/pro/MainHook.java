package com.chargeanim.pro;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * ChargeAnimPro
 *
 * SystemUI (com.android.systemui):
 *   ChargeUtils.getChargeAnimationType()       : 0 classic, 1 video, 2 wave, 3 particle
 *   ChargeUtils.supportVideo/Wave/Particle...  : type ke hisaab se true/false
 *   ChargeUtils.isChargeAnimationDisabled()    : true = animation band
 *   MiuiChargeAnimationView.getAnimationDuration()
 *   WiredChargingRippleController.registerCallbacks()  : ripple band
 *
 * Settings (com.android.settings):
 *   Main Settings page par "Charging Animation" entry jodta hai jo module ki settings kholti hai.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[ChargeAnimPro] ";
    private static final String CHARGE_UTILS = "com.android.keyguard.charge.ChargeUtils";
    private static final String ANIM_VIEW = "com.android.keyguard.charge.container.MiuiChargeAnimationView";
    private static final String RIPPLE_CTRL = "com.android.systemui.statusbar.charging.WiredChargingRippleController";
    private static final String ENTRY_KEY = "charge_anim_pro_entry";

    private static XSharedPreferences prefs;

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if ("com.android.systemui".equals(lp.packageName)) {
            hookSystemUi(lp);
        } else if ("com.android.settings".equals(lp.packageName)) {
            hookSettings(lp);
        }
    }

    // ------------------------------------------------------------------ prefs

    private static synchronized XSharedPreferences p() {
        if (prefs == null) {
            prefs = new XSharedPreferences(Cfg.PKG, Cfg.FILE);
            prefs.makeWorldReadable();
        } else if (prefs.hasFileChanged()) {
            prefs.reload();
        }
        return prefs;
    }

    private static int style() {
        try { return p().getInt(Cfg.KEY_STYLE, -1); } catch (Throwable t) { return -1; }
    }

    private static boolean flag(String key) {
        try { return p().getBoolean(key, false); } catch (Throwable t) { return false; }
    }

    private static int duration() {
        try { return p().getInt(Cfg.KEY_DURATION, 0); } catch (Throwable t) { return 0; }
    }

    // ---------------------------------------------------------------- SystemUI

    private void hookSystemUi(LoadPackageParam lp) {
        ClassLoader cl = lp.classLoader;

        // Animation type (0..3)
        try {
            XposedHelpers.findAndHookMethod(CHARGE_UTILS, cl, "getChargeAnimationType", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    int s = style();
                    if (s >= 0) param.setResult(s);
                }
            });
            log("hooked getChargeAnimationType");
        } catch (Throwable t) {
            log("FAILED getChargeAnimationType : " + t);
        }

        // Callers bhi hook karte hain, kyunke chhote static methods inline ho sakte hain.
        hookSupport(cl, "supportVideoChargeAnimation", 1);
        hookSupport(cl, "supportWaveChargeAnimation", 2);
        hookSupport(cl, "supportParticleChargeAnimation", 3);

        // Animation bilkul band
        try {
            XposedHelpers.findAndHookMethod(CHARGE_UTILS, cl, "isChargeAnimationDisabled", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (flag(Cfg.KEY_DISABLE)) param.setResult(true);
                }
            });
            log("hooked isChargeAnimationDisabled");
        } catch (Throwable t) {
            log("FAILED isChargeAnimationDisabled : " + t);
        }

        // Animation ka waqt
        try {
            XposedHelpers.findAndHookMethod(ANIM_VIEW, cl, "getAnimationDuration", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    int d = duration();
                    if (d > 0) param.setResult(d);
                }
            });
            log("hooked getAnimationDuration");
        } catch (Throwable t) {
            log("FAILED getAnimationDuration : " + t);
        }

        // Wired ripple
        try {
            XposedHelpers.findAndHookMethod(RIPPLE_CTRL, cl, "registerCallbacks", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (flag(Cfg.KEY_NO_RIPPLE)) param.setResult(null);
                }
            });
            log("hooked registerCallbacks (ripple)");
        } catch (Throwable t) {
            log("FAILED ripple hook : " + t);
        }
    }

    private void hookSupport(ClassLoader cl, String method, final int wanted) {
        try {
            XposedHelpers.findAndHookMethod(CHARGE_UTILS, cl, method, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    int s = style();
                    if (s >= 0) param.setResult(s == wanted);
                }
            });
            log("hooked " + method);
        } catch (Throwable t) {
            log("FAILED " + method + " : " + t);
        }
    }

    // ---------------------------------------------------------------- Settings

    /**
     * Settings ka main page androidx PreferenceFragmentCompat par bana hota hai.
     * Class ka naam "MainSettings" par khatam ho to ek Preference jod dete hain.
     * NOTE: ye Settings APK dekhe baghair likha hai, isliye device par test zaroori hai.
     */
    private void hookSettings(final LoadPackageParam lp) {
        try {
            XposedHelpers.findAndHookMethod("androidx.preference.PreferenceFragmentCompat", lp.classLoader,
                    "setPreferenceScreen", "androidx.preference.PreferenceScreen", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                Object screen = param.args[0];
                                if (screen == null) return;
                                String fragment = param.thisObject.getClass().getName();
                                if (!fragment.endsWith("MainSettings")) return;

                                Context ctx = (Context) XposedHelpers.callMethod(param.thisObject, "getContext");
                                if (ctx == null) return;
                                if (XposedHelpers.callMethod(screen, "findPreference", ENTRY_KEY) != null) return;

                                Class<?> prefCls = XposedHelpers.findClass("androidx.preference.Preference", lp.classLoader);
                                Object pref = XposedHelpers.newInstance(prefCls, ctx);
                                XposedHelpers.callMethod(pref, "setKey", ENTRY_KEY);
                                XposedHelpers.callMethod(pref, "setTitle", "Charging Animation");
                                XposedHelpers.callMethod(pref, "setSummary", "Charging animation style aur options");

                                Intent i = new Intent();
                                i.setComponent(new ComponentName(Cfg.PKG, Cfg.PKG + ".SettingsActivity"));
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                XposedHelpers.callMethod(pref, "setIntent", i);

                                XposedHelpers.callMethod(screen, "addPreference", pref);
                                log("Settings entry added in " + fragment);
                            } catch (Throwable t) {
                                log("Settings entry FAILED : " + t);
                            }
                        }
                    });
            log("hooked Settings PreferenceFragmentCompat");
        } catch (Throwable t) {
            log("FAILED Settings hook : " + t);
        }
    }

    private static void log(String s) {
        XposedBridge.log(TAG + s);
    }
}

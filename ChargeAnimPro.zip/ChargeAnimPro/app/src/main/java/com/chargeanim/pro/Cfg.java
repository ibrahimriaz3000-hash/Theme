package com.chargeanim.pro;

/** Shared keys. Module app likhta hai, SystemUI hook XSharedPreferences se padhta hai. */
public final class Cfg {
    private Cfg() {}

    public static final String PKG = "com.chargeanim.pro";
    public static final String FILE = "config";

    /** -1 = system default, 0 = Classic, 1 = Video, 2 = Wave, 3 = Particle */
    public static final String KEY_STYLE = "style";
    /** true = charging animation bilkul band */
    public static final String KEY_DISABLE = "disable";
    /** 0 = system default, warna milliseconds */
    public static final String KEY_DURATION = "duration_ms";
    /** true = wired charging ripple band (SystemUI restart chahiye) */
    public static final String KEY_NO_RIPPLE = "no_ripple";
}

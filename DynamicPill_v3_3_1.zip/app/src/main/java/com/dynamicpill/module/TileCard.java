package com.dynamicpill.module;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.WeakHashMap;

/**
 * Tile card: replaces the media player card of the Control Center (MediaPlayerPanel, MIUISystemUIPlugin.apk)
 * with a 2x2 card of round tiles.
 *
 * - The tiles of the card are taken OUT of the main tile list (QSListController.getListItems is filtered), so the
 *   grid closes up and no gap is left. The tile objects stay alive (QSRecord.tile), the card shows their state
 *   (QSTile.getState(): state, icon) and a tap on a circle calls QSTile.click().
 * - Edit screen: the card is shown there too. Tap a tile in the edit grid = put it into the card (max 4),
 *   tap it again (or tap its circle in the card) = take it out of the card.
 * - The chosen tiles are kept in System UI's own preferences. Everything is wrapped in try/catch.
 */
final class TileCard {
    static final String SP_NAME = "dynamicpill_cc_tiles", SP_KEY = "specs2"; // new key in 3.2.4: the old "specs" could be stuck on an empty list
    private static final String DEFAULT_SPECS = "cell,wifi,airplane";
    private static final int MAX = 4;
    /** Card circle colours: an "on" tile gets a yellow disc with a dark icon. */
    private static final int ON_DISC = 0xFFFFC21A, ON_ICON = 0xFF2B2100;
    private static final String MODE_CLASS = "miui.systemui.controlcenter.panel.main.MainPanelModeController$MainPanelMode";

    /** spec -> latest QSRecord seen in the tile list (weak). */
    private static final HashMap<String, WeakReference<Object>> RECORDS = new HashMap<>();
    /** spec -> real QSTile taken from the controller's own added / copied lists (works in the edit screen too). */
    private static final HashMap<String, WeakReference<Object>> TILES = new HashMap<>();
    /** spec -> latest QSTile.State shown by a tile view (QSTileItemView / QSCardItemView); last-resort source for the card. */
    private static final HashMap<String, WeakReference<Object>> STATES = new HashMap<>();
    private static final WeakHashMap<View, Card> CARDS = new WeakHashMap<>();
    /** Original children of the media panel -> the visibility they had before the card hid them (media player "off"). */
    private static final WeakHashMap<View, Integer> HIDDEN = new WeakHashMap<>();
    private static volatile boolean editMode = false;
    private static volatile Context ctx;
    private static volatile ClassLoader pluginCl;
    private static volatile WeakReference<Object> controllerRef;
    private static boolean tapHooked = false, redistributing = false;
    private static final WeakHashMap<ClassLoader, Boolean> HOOKED = new WeakHashMap<>();
    static final String LIST_CLASS = "miui.systemui.controlcenter.panel.main.qs.QSListController";

    private TileCard() { }

    // ---------------------------------------------------------------- selection (System UI's own prefs)

    private static SharedPreferences sp() {
        Context c = ctx;
        return c == null ? null : c.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
    }

    static LinkedHashSet<String> selected() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try {
            SharedPreferences p = sp();
            String csv = p == null ? DEFAULT_SPECS : p.getString(SP_KEY, DEFAULT_SPECS);
            if (csv == null) csv = DEFAULT_SPECS;
            for (String x : csv.split(",")) if (x.trim().length() > 0) s.add(x.trim());
        } catch (Throwable ignored) { }
        return s;
    }

    private static void save(LinkedHashSet<String> s) {
        try {
            SharedPreferences p = sp();
            if (p == null) return;
            StringBuilder sb = new StringBuilder();
            for (String x : s) { if (sb.length() > 0) sb.append(','); sb.append(x); }
            p.edit().putString(SP_KEY, sb.toString()).apply();
        } catch (Throwable ignored) { }
    }

    /** Put the spec into the card, or take it out when it is already there. */
    private static void toggle(String spec) {
        LinkedHashSet<String> s = selected();
        if (!s.remove(spec)) {
            if (s.size() >= MAX) return;
            s.add(spec);
        }
        save(s);
        XposedBridge.log("DynamicPill: tile card now holds " + s);
        refreshCards();
        redistribute();
    }

    /** Build the tile grid again (the tiles that are in the card are left out of it, in the edit screen too). */
    private static void redistribute() {
        try {
            WeakReference<Object> r = controllerRef;
            Object c = r == null ? null : r.get();
            if (c == null || redistributing) return;
            redistributing = true;
            try { XposedHelpers.callMethod(c, "distributeTiles"); } finally { redistributing = false; }
        } catch (Throwable t) { XposedBridge.log("DynamicPill: tile grid refresh failed: " + t); }
    }

    /** Calls tile.click / longClick whatever its signature is (no argument, or the view). */
    private static boolean invokeTile(Object tile, String name, View v) {
        Throwable last = null;
        for (java.lang.reflect.Method m : tile.getClass().getMethods()) {
            if (!m.getName().equals(name)) continue;
            Class<?>[] pt = m.getParameterTypes();
            try {
                m.setAccessible(true);
                if (pt.length == 0) { m.invoke(tile); return true; }
                if (pt.length == 1 && !pt[0].isPrimitive()) {
                    m.invoke(tile, new Object[]{pt[0].isInstance(v) ? v : null});
                    return true;
                }
            } catch (Throwable t) { last = t; }
        }
        XposedBridge.log("DynamicPill: tile " + name + " failed on " + tile.getClass().getName() + ": " + last);
        return false;
    }

    /** Redraw every card at once (no waiting for the next 350 ms tick). */
    private static void refreshCards() {
        try {
            for (Card c : new ArrayList<>(CARDS.values())) c.refreshNow();
        } catch (Throwable ignored) { }
    }

    // ---------------------------------------------------------------- hooks (plug-in class loader)

    static void hookPlugin(final ClassLoader cl) {
        if (cl == null) return;
        pluginCl = cl;
        synchronized (HOOKED) {
            if (HOOKED.containsKey(cl)) return;
            HOOKED.put(cl, Boolean.TRUE);
        }
        XposedBridge.log("DynamicPill: tile card hooks go on, class loader " + cl);
        // 1) the tile list: remember every QSRecord, and leave the card's tiles out of the normal grid
        try {
            XposedHelpers.findAndHookMethod("miui.systemui.controlcenter.panel.main.qs.QSListController", cl,
                    "getListItems", new XC_MethodHook() {
                private boolean logged = false;
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (!logged) { logged = true; XposedBridge.log("DynamicPill: tile list hook is running"); }
                        p.setResult(filter(p.thisObject, (List<?>) p.getResult()));
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: tile list hook failed: " + t); }
        // 2) when the mode changes (normal <-> edit) the list is distributed again so the grid is re-filtered
        try {
            XposedHelpers.findAndHookMethod("miui.systemui.controlcenter.panel.main.qs.QSListController", cl,
                    "onModeChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (redistributing || !ControlCenterSize.tileCardOn()) return;
                        redistributing = true;
                        try { XposedHelpers.callMethod(p.thisObject, "distributeTiles"); } finally { redistributing = false; }
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: mode hook failed: " + t); }
        // 3) the media card slot is also shown in the edit screen
        try {
            Class<?> mode = XposedHelpers.findClass(MODE_CLASS, cl);
            XposedHelpers.findAndHookMethod("miui.systemui.controlcenter.panel.main.media.MediaPlayerController", cl,
                    "available", boolean.class, mode, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args[1] != null && p.args[1].toString().contains("EDIT") && ControlCenterSize.tileCardOn())
                            p.setResult(true);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: media slot hook failed: " + t); }
        // 3a) tile card on = media player off: its own views are kept hidden after every media callback
        hookMediaOff(cl);
        // 3b) remember the State of every tile view (the edit screen's tile views carry the real icon / label / state)
        hookStates(cl);
        // 4) edit screen: a tap on a tile puts it into / takes it out of the card
        if (tapHooked) return;
        tapHooked = true;
        try {
            XposedHelpers.findAndHookMethod(View.class, "performClick", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        View v = (View) p.thisObject;
                        String cn = v.getClass().getName();
                        if (!(cn.endsWith("QSTileItemView") || cn.endsWith("QSCardItemView"))) return;
                        if (editTap(v)) p.setResult(true);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log("DynamicPill: edit tap hook failed: " + t); }
    }

    private static void hookStates(ClassLoader cl) {
        for (String cn : new String[]{"miui.systemui.controlcenter.qs.tileview.QSTileItemView",
                "miui.systemui.controlcenter.qs.tileview.QSCardItemView"}) {
            try {
                Class<?> k = XposedHelpers.findClass(cn, cl);
                XC_MethodHook h = new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            if (p.args != null && p.args.length > 0 && p.args[0] != null) rememberState(p.args[0]);
                        } catch (Throwable ignored) { }
                    }
                };
                XposedBridge.hookAllMethods(k, "updateState", h);
                XposedBridge.hookAllMethods(k, "updateCustomizeState", h);
                if (cn.endsWith("QSCardItemView")) hookCardText(k);
            } catch (Throwable t) { XposedBridge.log("DynamicPill: tile state hook failed (" + cn + "): " + t); }
        }
    }

    /**
     * The wide cards (Wi-Fi / Mobile data) scrolled their title as a marquee inside a very narrow box, so the text
     * ran sideways and was cut hard at the edges (looked like flicker). Marquee is switched off: the title stays
     * still and ends with "..." when it is too long.
     */
    private static void hookCardText(Class<?> k) {
        try {
            XposedBridge.hookAllMethods(k, "startMarquee", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (p.thisObject instanceof View) calmTexts((View) p.thisObject);
                        p.setResult(null);
                    } catch (Throwable ignored) { }
                }
            });
            XC_MethodHook after = new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try { if (p.thisObject instanceof View) calmTexts((View) p.thisObject); } catch (Throwable ignored) { }
                }
            };
            XposedBridge.hookAllMethods(k, "onFinishInflate", after);
            XposedBridge.hookAllMethods(k, "updateState", after);
            XposedBridge.hookAllMethods(k, "onWindowFocusChanged", after);
            XposedBridge.log("DynamicPill: card text marquee hooks on");
        } catch (Throwable t) { XposedBridge.log("DynamicPill: card text hook failed: " + t); }
    }

    private static void calmTexts(View v) {
        if (v instanceof android.widget.TextView) {
            android.widget.TextView t = (android.widget.TextView) v;
            if (t.getEllipsize() == android.text.TextUtils.TruncateAt.MARQUEE) {
                t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                t.setSelected(false);
                t.setHorizontalFadingEdgeEnabled(false);
            }
        } else if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) calmTexts(g.getChildAt(i));
        }
    }

    private static void rememberState(Object st) {
        Object sp = XposedHelpers.getObjectField(st, "spec");
        if (sp instanceof String) synchronized (RECORDS) { STATES.put((String) sp, new WeakReference<>(st)); }
    }

    /** The controller's own added / copied record lists always hold the real tiles, in the edit screen too. */
    private static void harvest(Object controller) {
        for (String f : new String[]{"addedTiles", "copiedTiles"}) {
            try {
                Object l = XposedHelpers.getObjectField(controller, f);
                if (!(l instanceof java.util.Collection)) continue;
                for (Object rec : new ArrayList<Object>((java.util.Collection<?>) l)) {
                    try {
                        if (rec == null) continue;
                        Object sp = XposedHelpers.getObjectField(rec, "spec");
                        Object tile = XposedHelpers.getObjectField(rec, "tile");
                        if (sp instanceof String && tile != null)
                            synchronized (RECORDS) { TILES.put((String) sp, new WeakReference<>(tile)); }
                    } catch (Throwable ignored) { }
                }
            } catch (Throwable ignored) { }
        }
    }

    private static boolean editTap(View v) {
        if (!ControlCenterSize.tileCardOn()) return false;
        Object m = XposedHelpers.getObjectField(v, "mode");
        if (m == null || !m.toString().contains("EDIT")) return false;
        String spec = null;
        for (String f : new String[]{"state", "customizeState"}) {
            try {
                Object st = XposedHelpers.getObjectField(v, f);
                Object sp = st == null ? null : XposedHelpers.getObjectField(st, "spec");
                if (sp instanceof String) { spec = (String) sp; break; }
            } catch (Throwable ignored) { }
        }
        if (spec == null) return false;
        toggle(spec);
        return true;
    }

    /** Called with the controller's own list: records are remembered, the card's tiles are left out. */
    private static List<?> filter(Object controller, List<?> items) {
        if (items == null) return null;
        try {
            Object c = XposedHelpers.getObjectField(controller, "sysUIContext");
            if (c instanceof Context) ctx = (Context) c;
        } catch (Throwable ignored) { }
        harvest(controller);
        controllerRef = new WeakReference<>(controller);
        boolean edit = false;
        synchronized (RECORDS) {
            for (Object it : items) {
                if (it == null) continue;
                String cn = it.getClass().getName();
                if (cn.contains("EditModeDivider")) edit = true;
                if (cn.endsWith("QSRecord")) {
                    try {
                        Object sp = XposedHelpers.getObjectField(it, "spec");
                        if (sp instanceof String) RECORDS.put((String) sp, new WeakReference<>(it));
                    } catch (Throwable ignored) { }
                }
            }
        }
        editMode = edit;
        if (!ControlCenterSize.tileCardOn()) return items;
        LinkedHashSet<String> sel = selected();
        if (sel.isEmpty()) return items;
        ArrayList<Object> out = new ArrayList<>(items.size());
        for (Object it : items) {
            boolean drop = false;
            if (it != null && it.getClass().getName().endsWith("QSRecord")) {
                try {
                    Object sp = XposedHelpers.getObjectField(it, "spec");
                    drop = sp instanceof String && sel.contains(sp);
                } catch (Throwable ignored) { }
            }
            if (!drop) out.add(it);
        }
        return out;
    }

    // ---------------------------------------------------------------- media player off (tile card on)

    /**
     * Keeps every original child of the media panel (cover, title, "No playback history" text ...) GONE while the
     * tile card is on. Called at once when the panel attaches, in front of every frame (pre-draw) and after every
     * media controller callback that can touch those views (expand / spread animation = Control Center opening),
     * so the old media text can never show through the card, not even for one frame.
     */
    static void hideOthers(ViewGroup panel) {
        try {
            if (panel == null || !ControlCenterSize.tileCardOn()) return;
            for (int i = 0; i < panel.getChildCount(); i++) {
                View c = panel.getChildAt(i);
                if (c == null || c instanceof Card) continue;
                synchronized (HIDDEN) { if (!HIDDEN.containsKey(c)) HIDDEN.put(c, c.getVisibility()); }
                if (c.getVisibility() != View.GONE) c.setVisibility(View.GONE);
            }
        } catch (Throwable ignored) { }
    }

    private static void restoreAll(ViewGroup panel) {
        try {
            synchronized (HIDDEN) {
                for (View c : new ArrayList<>(HIDDEN.keySet())) {
                    Integer o = HIDDEN.remove(c);
                    if (c != null && c.getParent() == panel) c.setVisibility(o == null ? View.VISIBLE : o);
                }
            }
        } catch (Throwable ignored) { }
    }

    private static void hideAll() {
        try {
            if (CARDS.isEmpty() || !ControlCenterSize.tileCardOn()) return;
            for (Card c : new ArrayList<>(CARDS.values())) hideOthers(c.panel);
        } catch (Throwable ignored) { }
    }

    /** After these media controller callbacks the original media views are hidden again (no flash while opening). */
    private static void hookMediaOff(ClassLoader cl) {
        try {
            Class<?> k = XposedHelpers.findClass("miui.systemui.controlcenter.panel.main.media.MediaPlayerController", cl);
            XC_MethodHook after = new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) { hideAll(); }
            };
            for (String n : new String[]{"onBindViewHolder", "applyPayload", "onExpandChange", "onSpreadChange",
                    "updateMode", "updateConfiguration", "onUnbindViewHolder"}) {
                try { XposedBridge.hookAllMethods(k, n, after); } catch (Throwable ignored) { }
            }
            XposedBridge.log("DynamicPill: media player off hooks on");
        } catch (Throwable t) { XposedBridge.log("DynamicPill: media off hook failed: " + t); }
    }

    // ---------------------------------------------------------------- the card (inside MediaPlayerPanel)

    static void registerPanel(final View p) {
        try {
            if (!(p instanceof ViewGroup) || !ControlCenterSize.tileCardOn()) return;
            hookPlugin(p.getClass().getClassLoader());
            hideOthers((ViewGroup) p);   // at once: nothing of the media player shows before the card is added
            p.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (CARDS.containsKey(p) || !ControlCenterSize.tileCardOn()) return;
                        if (ctx == null) ctx = p.getContext();
                        Card c = new Card(p.getContext(), (ViewGroup) p);
                        CARDS.put(p, c);
                        ((ViewGroup) p).addView(c, new ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    } catch (Throwable t) {
                        XposedBridge.log("DynamicPill: tile card failed: " + t);
                        restoreAll((ViewGroup) p);   // no card = the media player must not stay hidden
                    }
                }
            });
        } catch (Throwable ignored) { }
    }

    /** The real tile (QSRecord.tile) of an added tile, or null. */
    private static Object tileOf(String spec) {
        try {
            WeakReference<Object> r;
            synchronized (RECORDS) { r = RECORDS.get(spec); }
            Object rec = r == null ? null : r.get();
            if (rec != null) {
                boolean added = true;
                try { added = XposedHelpers.getBooleanField(rec, "added"); } catch (Throwable ignored) { }
                if (added) {
                    Object t = XposedHelpers.getObjectField(rec, "tile");
                    if (t != null) return t;
                }
            }
        } catch (Throwable ignored) { }
        // the edit screen builds its own records: fall back to the tile taken from the controller's added list
        try {
            WeakReference<Object> r;
            synchronized (RECORDS) { r = TILES.get(spec); }
            return r == null ? null : r.get();
        } catch (Throwable t) { return null; }
    }

    /** Current QSTile.State of the spec: from the real tile, else from the last tile view that showed it. */
    private static Object stateOf(String spec) {
        Object tile = tileOf(spec);
        if (tile != null) {
            try {
                Object st = XposedHelpers.callMethod(tile, "getState");
                if (st != null) return st;
            } catch (Throwable ignored) { }
        }
        try {
            WeakReference<Object> r;
            synchronized (RECORDS) { r = STATES.get(spec); }
            return r == null ? null : r.get();
        } catch (Throwable t) { return null; }
    }

    // ---------------------------------------------------------------- theme colours

    private static int mix(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    private static int withAlpha(int c, int a) { return (c & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24); }

    /** Theme colour of the card (settings), 0 = default yellow. */
    private static int themeColor() {
        int t = ControlCenterSize.tileColor();
        return t == 0 ? ON_DISC : (t | 0xFF000000);
    }

    /** Dark icon colour of the same hue as the theme (icons on a lit tile follow the theme). */
    private static int themeIcon(int theme) {
        if (theme == ON_DISC) return ON_ICON;
        float[] hsv = new float[3];
        Color.colorToHSV(theme, hsv);
        hsv[1] = Math.min(1f, hsv[1] * 0.9f + 0.05f);
        hsv[2] = 0.17f;
        return Color.HSVToColor(hsv);
    }

    /**
     * One round tile in the Control Center glass look: translucent body (lit at the top, deeper at the bottom),
     * a soft highlight on the upper half and a thin bright rim. A tile that is ON is tinted with the theme colour,
     * an OFF tile is grey glass with a faint touch of the theme.
     */
    private static final class Circle extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.RectF oval = new android.graphics.RectF();
        private android.graphics.LinearGradient gBody, gSpec, gRim;
        private int builtW = -1, builtH = -1, builtTheme, builtOn = -1;
        Drawable icon;
        String letter = "";
        boolean active;
        int theme = ON_DISC, iconColor = ON_ICON;
        /** What the circle shows now (spec, state, icon object, letter, theme): nothing is rebuilt / redrawn while it stays the same. */
        String key;
        Circle(Context c) { super(c); }

        private void build(int w, int h) {
            builtW = w; builtH = h; builtTheme = theme; builtOn = active ? 1 : 0;
            int body = active ? theme : mix(0xFF8A8A90, theme, 0.12f);
            int baseA = active ? 0xEE : 0x6E;
            int top = withAlpha(mix(body, Color.WHITE, active ? 0.30f : 0.28f), baseA + 0x14);
            int bot = withAlpha(mix(body, Color.BLACK, active ? 0.12f : 0.18f), baseA);
            gBody = new android.graphics.LinearGradient(0, 0, 0, h, top, bot, android.graphics.Shader.TileMode.CLAMP);
            gSpec = new android.graphics.LinearGradient(0, h * 0.04f, 0, h * 0.52f,
                    withAlpha(Color.WHITE, active ? 120 : 80), withAlpha(Color.WHITE, 0), android.graphics.Shader.TileMode.CLAMP);
            gRim = new android.graphics.LinearGradient(0, 0, 0, h,
                    new int[]{withAlpha(Color.WHITE, 200), withAlpha(Color.WHITE, 38), withAlpha(Color.WHITE, 120)},
                    new float[]{0f, 0.55f, 1f}, android.graphics.Shader.TileMode.CLAMP);
        }

        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            if (gBody == null || builtW != w || builtH != h || builtTheme != theme || builtOn != (active ? 1 : 0)) build(w, h);
            float r = Math.min(w, h) / 2f;
            float rim = Math.max(1f, getResources().getDisplayMetrics().density * 1.1f);
            // 1) glass body
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(gBody);
            cv.drawCircle(w / 2f, h / 2f, r, paint);
            // 2) soft light on the upper half
            paint.setShader(gSpec);
            oval.set(w * 0.13f, h * 0.04f, w * 0.87f, h * 0.56f);
            cv.drawOval(oval, paint);
            // 3) thin bright rim
            paint.setShader(gRim);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(rim);
            cv.drawCircle(w / 2f, h / 2f, r - rim / 2f, paint);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            if (icon != null) {
                int in = Math.round(Math.min(w, h) * 0.27f);
                icon.setBounds(in, in, w - in, h - in);
                icon.draw(cv);
            } else if (letter.length() > 0) {
                paint.setColor(active ? iconColor : Color.WHITE);
                paint.setTextSize(Math.min(w, h) * 0.4f);
                paint.setTextAlign(Paint.Align.CENTER);
                cv.drawText(letter, w / 2f, h / 2f + paint.getTextSize() * 0.35f, paint);
            }
        }
    }

    private static final class Card extends FrameLayout {
        private final ViewGroup panel;
        private final ArrayList<Circle> circles = new ArrayList<>();
        private final String[] circleSpec = new String[MAX];
        private final android.view.ViewTreeObserver.OnPreDrawListener keepHidden =
                new android.view.ViewTreeObserver.OnPreDrawListener() {
                    @Override public boolean onPreDraw() { hideOthers(panel); return true; }
                };
        private android.view.ViewTreeObserver preDrawOwner;
        private final Runnable tickR = new Runnable() { @Override public void run() { tick(); } };
        private boolean emptyLogged = false;

        void refreshNow() {
            removeCallbacks(tickR);
            post(tickR);
        }

        Card(Context c, ViewGroup panel) {
            super(c);
            this.panel = panel;
            setClipChildren(false);
            for (int i = 0; i < MAX; i++) {
                final int idx = i;
                Circle ci = new Circle(c);
                ci.setVisibility(GONE);
                ci.setOnClickListener(new OnClickListener() {
                    @Override public void onClick(View v) { tap(idx, false); }
                });
                ci.setOnLongClickListener(new OnLongClickListener() {
                    @Override public boolean onLongClick(View v) { return tap(idx, true); }
                });
                circles.add(ci);
                addView(ci);
            }
        }

        private int dpi(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            removeCallbacks(tickR);
            post(tickR);
            try {
                if (preDrawOwner == null) {
                    preDrawOwner = getViewTreeObserver();
                    preDrawOwner.addOnPreDrawListener(keepHidden);
                }
            } catch (Throwable ignored) { }
        }

        @Override protected void onDetachedFromWindow() {
            removeCallbacks(tickR);
            try {
                if (preDrawOwner != null) {
                    if (preDrawOwner.isAlive()) preDrawOwner.removeOnPreDrawListener(keepHidden);
                    preDrawOwner = null;
                }
            } catch (Throwable ignored) { }
            super.onDetachedFromWindow();
        }

        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l, h = b - t;
            int pad = dpi(12);
            int cell = Math.max(1, Math.min(w - 2 * pad, h - 2 * pad) / 2);
            int d = Math.max(1, Math.round(cell * 0.86f));
            int ox = (w - 2 * cell) / 2, oy = (h - 2 * cell) / 2;
            for (int i = 0; i < MAX; i++) {
                Circle ci = circles.get(i);
                int cx = ox + (i % 2) * cell + cell / 2, cy = oy + (i / 2) * cell + cell / 2;
                ci.measure(MeasureSpec.makeMeasureSpec(d, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(d, MeasureSpec.EXACTLY));
                ci.layout(cx - d / 2, cy - d / 2, cx + d / 2, cy + d / 2);
            }
        }

        /** Normal screen: toggle the real tile. Edit screen: take the tile out of the card. */
        private boolean tap(int idx, boolean longClick) {
            try {
                String spec = circleSpec[idx];
                if (spec == null) return false;
                if (editMode && !longClick) { toggle(spec); return true; }
                Object tile = tileOf(spec);
                if (tile == null) { XposedBridge.log("DynamicPill: tile card tap " + spec + ": no tile"); return false; }
                boolean ok = invokeTile(tile, longClick ? "longClick" : "click", circles.get(idx));
                XposedBridge.log("DynamicPill: tile card tap " + spec + (longClick ? " (long)" : "") + " -> " + ok);
                return ok;
            } catch (Throwable t) { return false; }
        }

        private void tick() {
            try {
                if (!isAttachedToWindow()) return;
                if (!ControlCenterSize.tileCardOn()) {
                    setVisibility(GONE);
                    restorePanel();
                    postDelayed(tickR, 1500);
                    return;
                }
                setVisibility(VISIBLE);
                hidePanelChildren();
                update();
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: tile card tick failed: " + t);
            }
            try { postDelayed(tickR, 350); } catch (Throwable ignored) { }
        }

        private void hidePanelChildren() { hideOthers(panel); }

        private void restorePanel() {
            try {
                synchronized (HIDDEN) {
                    for (View c : new ArrayList<>(HIDDEN.keySet())) {
                        Integer o = HIDDEN.remove(c);
                        if (c != null && c.getParent() == panel) c.setVisibility(o == null ? VISIBLE : o);
                    }
                }
            } catch (Throwable ignored) { }
        }

        private void update() {
            int n = 0;
            for (String spec : selected()) {
                if (n >= MAX) break;
                Object st = stateOf(spec);
                if (st == null) continue;
                Circle ci = circles.get(n);
                circleSpec[n] = spec;
                int state = 0;
                try { state = XposedHelpers.getIntField(st, "state"); } catch (Throwable ignored) { }
                boolean active = state == 2;
                CharSequence label = null;
                try { label = (CharSequence) XposedHelpers.getObjectField(st, "label"); } catch (Throwable ignored) { }
                String letter = label != null && label.length() > 0 ? label.toString().substring(0, 1).toUpperCase() : "";
                Object iconObj = null;
                try { iconObj = XposedHelpers.getObjectField(st, "icon"); } catch (Throwable ignored) { }
                int theme = themeColor(), onIcon = themeIcon(theme);
                String key = iconObj == null ? null : spec + "|" + state + "|" + System.identityHashCode(iconObj) + "|" + letter + "|" + theme;
                if (key == null || !key.equals(ci.key) || (ci.icon == null && ci.letter.length() == 0)) {
                    Drawable d = iconOf(st);
                    if (d != null) {
                        try {
                            Drawable.ConstantState cst = d.getConstantState();
                            d = (cst != null ? cst.newDrawable().mutate() : d.mutate());
                            d.setTint(active ? onIcon : Color.WHITE);
                        } catch (Throwable ignored) { }
                    }
                    ci.icon = d;
                    ci.letter = letter;
                    ci.active = active;
                    ci.theme = theme;
                    ci.iconColor = onIcon;
                    ci.key = d == null ? null : key;   // no icon yet: try again next tick
                    ci.invalidate();
                }
                float al = state == 0 ? 0.4f : 1f;
                if (ci.getAlpha() != al) ci.setAlpha(al);
                if (ci.getVisibility() != VISIBLE) ci.setVisibility(VISIBLE);
                n++;
            }
            for (int i = n; i < MAX; i++) {
                circleSpec[i] = null;
                circles.get(i).key = null;
                if (circles.get(i).getVisibility() != GONE) circles.get(i).setVisibility(GONE);
            }
            if (n == 0 && editMode && !emptyLogged) {
                emptyLogged = true;
                synchronized (RECORDS) {
                    XposedBridge.log("DynamicPill: tile card empty in edit screen, specs=" + selected() + " records="
                            + RECORDS.keySet() + " tiles=" + TILES.keySet() + " states=" + STATES.keySet());
                }
            } else if (n > 0) emptyLogged = false;
        }

        private Object helperIconView;

        /** Last resort: let the plug-in's own icon view (the one the tile grid uses) load the icon for this State. */
        private Drawable viaIconView(Object st) {
            try {
                ClassLoader cl = pluginCl;
                if (cl == null) return null;
                if (helperIconView == null) {
                    Class<?> k = XposedHelpers.findClass("miui.systemui.controlcenter.qs.tileview.QSTileItemIconView", cl);
                    try { helperIconView = XposedHelpers.newInstance(k, ctx != null ? ctx : getContext(), getContext()); }
                    catch (Throwable t) { helperIconView = XposedHelpers.newInstance(k, getContext()); }
                }
                XposedHelpers.callMethod(helperIconView, "setIcon", st, false);
                Object iv = XposedHelpers.callMethod(helperIconView, "getIcon");
                if (iv instanceof android.widget.ImageView) return ((android.widget.ImageView) iv).getDrawable();
            } catch (Throwable t) {
                if (iconLogged.add("iconview")) XposedBridge.log("DynamicPill: tile card icon view failed: " + t);
            }
            return null;
        }

        private final java.util.HashSet<String> iconLogged = new java.util.HashSet<>();

        /**
         * The tile's icon. QSTile.Icon.getDrawable(context) needs the SYSTEM UI context (its resource ids belong to
         * System UI, not to the plug-in), so that one is tried first; the plug-in views' context only as a fallback.
         */
        private Drawable iconOf(Object st) {
            Object icon = null;
            try { icon = XposedHelpers.getObjectField(st, "icon"); } catch (Throwable ignored) { }
            if (icon == null) {
                try {
                    Object sup = XposedHelpers.getObjectField(st, "iconSupplier");
                    if (sup instanceof java.util.function.Supplier) icon = ((java.util.function.Supplier<?>) sup).get();
                } catch (Throwable ignored) { }
            }
            if (icon instanceof Drawable) return (Drawable) icon;
            Throwable last = null;
            if (icon != null) {
                ArrayList<Context> cs = new ArrayList<>();
                if (ctx != null) cs.add(ctx);
                cs.add(getContext());
                try { cs.add(getContext().getApplicationContext()); } catch (Throwable ignored) { }
                for (Context c : cs) {
                    if (c == null) continue;
                    try {
                        Object d = XposedHelpers.callMethod(icon, "getDrawable", c);
                        if (d instanceof Drawable) return (Drawable) d;
                    } catch (Throwable t) { last = t; }
                }
            }
            Drawable viaView = viaIconView(st);
            if (viaView != null) return viaView;
            String key = String.valueOf(icon == null ? null : icon.getClass().getName());
            if (iconLogged.add(key)) {
                XposedBridge.log("DynamicPill: tile card icon not found, icon=" + key + " error=" + last);
            }
            return null;
        }
    }
}

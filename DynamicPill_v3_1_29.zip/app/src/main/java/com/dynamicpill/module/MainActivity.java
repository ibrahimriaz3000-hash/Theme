package com.dynamicpill.module;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** iOS style settings screen. Values are read live by System UI (under a second). */
public class MainActivity extends Activity {
    private static final int BLUE = 0xFF2979FF;
    private static final int GREEN = 0xFF34C759;
    private static final int GRAY = 0xFF8E8E93;
    // light / dark follow the system setting
    private boolean night;
    private int BG, CARD, TEXT, DIVIDER, TRACK;
    private static final int UNIT_MM = 0, UNIT_PCT = 1, UNIT_SEC = 2, UNIT_DP = 3, UNIT_COLS = 4;

    private SharedPreferences sp;
    private java.util.ArrayList<Runnable> resets;                       // collects the reset action of every slider of the tab being built
    private final java.util.ArrayList<Runnable> resetsSb = new java.util.ArrayList<>();
    private final java.util.ArrayList<Runnable> resetsCc = new java.util.ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String, Integer> pendingInts = new HashMap<>();
    private final Runnable flushPrefs = new Runnable() { @Override public void run() { flushPrefsNow(); } };

    /** Slider values are written at most every ~90 ms (and once more at the end), not on every touch event. */
    private void putThrottled(String key, int v) {
        pendingInts.put(key, v);
        if (!ui.hasCallbacks(flushPrefs)) ui.postDelayed(flushPrefs, 90);
    }

    private void flushPrefsNow() {
        ui.removeCallbacks(flushPrefs);
        if (pendingInts.isEmpty() || sp == null) return;
        SharedPreferences.Editor ed = sp.edit();
        for (Map.Entry<String, Integer> e : pendingInts.entrySet()) ed.putInt(e.getKey(), e.getValue());
        pendingInts.clear();
        ed.apply();
    }

    // ---- GoodLooks Color Guard (root) ----
    private LockableLayout cgCard;
    private TextView cgNote;
    private final Map<String, CgSlider> cgSliders = new HashMap<>();
    private final Map<String, IosSwitch> cgSwitches = new HashMap<>();

    private static class CgSlider {
        FillSlider bar;
        TextView val;
        float min, step;
        int dec;
    }

    /** Card that ignores all touches while locked (until the root read finished). */
    private static class LockableLayout extends LinearLayout {
        boolean locked;

        LockableLayout(Context c) {
            super(c);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            return locked || super.onInterceptTouchEvent(e);
        }
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        night = (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        BG = night ? 0xFF000000 : 0xFFF2F2F7;
        CARD = night ? 0xFF1C1C1E : 0xFFFFFFFF;
        TEXT = night ? 0xFFFFFFFF : 0xFF000000;
        DIVIDER = night ? 0xFF38383A : 0xFFE5E5EA;
        TRACK = night ? 0xFF363636 : 0xFFE5E5EA;
        try {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_WORLD_READABLE);
        } catch (Throwable t) {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_PRIVATE);
            Toast.makeText(this, "Activate the module in LSPosed first", Toast.LENGTH_LONG).show();
        }

        // root holds the pages; only the page of the selected tab is visible (tab bar is built at the end)
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), 0, dp(16), dp(32));
        final String[] tabNames = {"Pill", "Indicators", "Status Bar", "Animations", "Preview", "Line",
                "Control Center", "Color Guard"};
        final LinearLayout[] pages = new LinearLayout[tabNames.length];
        for (int k = 0; k < pages.length; k++) {
            pages[k] = new LinearLayout(this);
            pages[k].setOrientation(LinearLayout.VERTICAL);
        }
        final LinearLayout pPill = pages[0], pInd = pages[1], pSb = pages[2], pAnim = pages[3], pPrev = pages[4],
                pLine = pages[5], pCc = pages[6], pCg = pages[7];

        TextView title = new TextView(this);
        title.setText("Dynamic Pill");
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(TEXT);
        title.setPadding(dp(20), dp(48), dp(16), dp(4));

        // ---- Pill
        LinearLayout pill = section(pPill, "PILL");
        switchRow(pill, "Show pill", PillController.K_ENABLED, true);
        switchRow(pill, "Show on lock screen", PillController.K_LOCK, true);
        sliderRow(pill, "Width", PillController.K_WIDTH, PillController.D_WIDTH, 40, 300, 0, UNIT_MM);
        sliderRow(pill, "Height", PillController.K_HEIGHT, PillController.D_HEIGHT, 20, 120, 0, UNIT_MM);
        switchRow(pill, "Auto-center on camera cut-out", PillController.K_AUTOX, true);
        sliderRow(pill, "Horizontal offset", PillController.K_XOFF, PillController.D_XOFF, 0, 300, -150, UNIT_MM);
        sliderRow(pill, "Vertical offset", PillController.K_YOFF, PillController.D_YOFF, 0, 300, -150, UNIT_MM);
        switchRow(pill, "Liquid glass pill (frosted glass look, off = black)", PillController.K_GLASS, false);
        sliderRow(pill, "Opacity", PillController.K_ALPHA, 100, 0, 100, 0, UNIT_PCT);
        sliderRow(pill, "White border (0 = off)", PillController.K_BORDER, 4, 0, 20, 0, UNIT_MM);
        sliderRow(pill, "Corner smoothness (0 = circle)", PillController.K_SMOOTH, 30, 0, 100, 0, UNIT_PCT);

        // ---- Status Bar tab (own page): left / right padding of the System UI status bar, 0 = system default
        resets = resetsSb;
        LinearLayout sbs = section(pSb, "STATUS BAR PADDING (0 = DEFAULT)");
        sliderRow(sbs, "Padding start (left)", StatusBarSize.K_START, 0, 0, 80, 0, UNIT_DP);
        sliderRow(sbs, "Padding end (right)", StatusBarSize.K_END, 0, 0, 80, 0, UNIT_DP);
        actionCard(pSb, resetsSb);
        resets = null;

        // ---- Indicators
        LinearLayout ind = section(pInd, "INDICATORS (INSIDE THE PILL)");
        switchRow(ind, "Yellow dot (always on)", PillController.K_IND_DOT, true);
        swapRow(ind, "Dot side (bolt goes to the other side)", PillController.K_DOT_LEFT);
        colorRow(ind, "Dot colour", PillController.K_DOT_COLOR);
        sliderRow(ind, "Dot size", PillController.K_DOT_PCT, 100, 40, 250, 0, UNIT_PCT);
        switchRow(ind, "Dot turns green in WhatsApp", PillController.K_IND_WA, true);
        switchRow(ind, "Call: green blinking outline (only if call pill is off)", PillController.K_IND_CALL, true);
        switchRow(ind, "Charging: green bolt icon", PillController.K_IND_CHARGE, true);
        switchRow(ind, "Blink dot every 15 s while a notification is waiting", PillController.K_IND_NOTIF, true);

        // ---- Animations (expanding pill)
        LinearLayout an = section(pAnim, "ANIMATIONS (EXPANDING PILL)");
        switchRow(an, "Pill animations (master switch)", PillController.K_ANIM, true);
        switchRow(an, "Charging pill", PillController.K_ANIM_CHARGE, true);
        switchRow(an, "Silent / Vibrate / Ring pill", PillController.K_ANIM_RINGER, true);
        switchRow(an, "Incoming call pill (caller + ringing handset)", PillController.K_ANIM_INCOMING, true);
        switchRow(an, "Call pill (Ringing, then timer + waveform)", PillController.K_ANIM_CALL, true);
        switchRow(an, "Lock pill (screen wakes locked)", PillController.K_ANIM_LOCK, true);
        switchRow(an, "Unlock pill (open lock + neon ring)", PillController.K_ANIM_UNLOCK, true);
        switchRow(an, "Torch on / off pill", PillController.K_ANIM_TORCH, true);
        switchRow(an, "Flight mode on / off pill", PillController.K_ANIM_FLIGHT, true);
        switchRow(an, "Hotspot on / off pill", PillController.K_ANIM_HOTSPOT, true);
        switchRow(an, "Location on / off pill", PillController.K_ANIM_LOC, true);
        switchRow(an, "WhatsApp neon outline", PillController.K_WA_NEON, true);
        switchRow(an, "Hide status bar while the pill animates", PillController.K_SB_HIDE, true);
        sliderRow(an, "Expanded width", PillController.K_EXP_W, PillController.D_EXP_W, 100, 400, 0, UNIT_MM);
        sliderRow(an, "Show time", PillController.K_HOLD, PillController.D_HOLD, 10, 60, 0, UNIT_SEC);
        sliderRow(an, "Text size", PillController.K_TXT_PCT, 100, 60, 150, 0, UNIT_PCT);
        sliderRow(an, "Icon size", PillController.K_ICO_PCT, 100, 60, 140, 0, UNIT_PCT);

        LinearLayout pv = section(pPrev, "PREVIEW (TAP TO PLAY ON THE PILL)");
        previewRow(pv, "Charging", "charge");
        previewRow(pv, "Silent", "silent");
        previewRow(pv, "Vibrate", "vibrate");
        previewRow(pv, "Ring", "ring");
        previewRow(pv, "Incoming call", "incoming");
        previewRow(pv, "Call", "call");
        previewRow(pv, "Lock", "lock");
        previewRow(pv, "Unlock", "unlock");
        previewRow(pv, "Torch on", "torch_on");
        previewRow(pv, "Torch off", "torch_off");
        previewRow(pv, "Flight mode on", "flight_on");
        previewRow(pv, "Flight mode off", "flight_off");
        previewRow(pv, "Hotspot on", "hotspot_on");
        previewRow(pv, "Hotspot off", "hotspot_off");
        previewRow(pv, "Location on", "location_on");
        previewRow(pv, "Location off", "location_off");

        // ---- Line
        LinearLayout line = section(pLine, "LINE (iOS GRABBER)");
        switchRow(line, "Show line", PillController.K_LINE_ON, true);
        sliderRow(line, "Width", PillController.K_LINE_W, PillController.D_LINE_W, 30, 600, 0, UNIT_MM);
        sliderRow(line, "Thickness", PillController.K_LINE_H, 6, 2, 30, 0, UNIT_MM);
        sliderRow(line, "Center from right edge", PillController.K_LINE_X, PillController.D_LINE_X, 0, 700, 0, UNIT_MM);
        sliderRow(line, "Distance from top", PillController.K_LINE_Y, PillController.D_LINE_Y, 0, 300, 0, UNIT_MM);
        sliderRow(line, "Opacity", PillController.K_LINE_ALPHA, 70, 5, 100, 0, UNIT_PCT);

        // ---- Control Center
        LinearLayout cc = section(pCc, "CONTROL CENTER");
        switchRow(cc, "Battery % + estimated time in Control Center", CcBattery.K_CC_BATT, true);
        switchRow(cc, "Swap: ZONG + battery info right, hello left", CcBattery.K_CC_SWAP, true);
        switchRow(cc, "Hello in the header (carrier name moves up-left)", CcBattery.K_CC_HELLO, true);

        resets = resetsCc;
        actionCard(pCc, resetsCc);
        LinearLayout ccs = section(pCc, "TILES (100 % = DEFAULT)");
        sliderRow(ccs, "Tile size", ControlCenterSize.K_TILE, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccs, "Big tile size (Wi-Fi, Bluetooth ...)", ControlCenterSize.K_BIG, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccs, "Text size", ControlCenterSize.K_TEXT, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccs, "Tile spacing", ControlCenterSize.K_SPACE, 100, 0, 300, 0, UNIT_PCT);
        sliderRow(ccs, "Custom / edit tile size", ControlCenterSize.K_CUSTOM, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccs, "Tile columns (0 = default)", ControlCenterSize.K_COLUMNS, 0, 0, 8, 0, UNIT_COLS);
        LinearLayout ccp = section(pCc, "PANEL (100 % = DEFAULT)");
        sliderRow(ccp, "Side margin", ControlCenterSize.K_MARGIN, 100, 0, 300, 0, UNIT_PCT);
        sliderRow(ccp, "Corner radius", ControlCenterSize.K_CORNER, 100, 0, 250, 0, UNIT_PCT);
        sliderRow(ccp, "Brightness slider", ControlCenterSize.K_BRIGHT, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccp, "Header (clock, date, buttons)", ControlCenterSize.K_HEADER, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccp, "Header top offset", ControlCenterSize.K_HEADER_TOP, 0, 0, 80, 0, UNIT_DP);
        sliderRow(ccp, "Detail panels (Wi-Fi / Bluetooth lists)", ControlCenterSize.K_DETAIL, 100, 50, 200, 0, UNIT_PCT);

        LinearLayout ccm = section(pCc, "MORE PARTS (100 % = DEFAULT)");
        sliderRow(ccm, "Media player", ControlCenterSize.K_MEDIA, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccm, "Footer and bottom area", ControlCenterSize.K_FOOT, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccm, "Page dots", ControlCenterSize.K_PAGE, 100, 50, 300, 0, UNIT_PCT);
        sliderRow(ccm, "Edit screen (tile customizer)", ControlCenterSize.K_EDIT, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccm, "Expanded tile view", ControlCenterSize.K_EXPAND, 100, 50, 200, 0, UNIT_PCT);

        LinearLayout ccx = section(pCc, "PLUGIN PARTS (MIUISystemUIPlugin, 100 % = DEFAULT)");
        sliderRow(ccx, "Volume panel", ControlCenterSize.K_VOLUME, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccx, "MiPlay / media cards", ControlCenterSize.K_MIPLAY, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccx, "Device controls / device center", ControlCenterSize.K_DEVICE, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccx, "Universal cards (control center)", ControlCenterSize.K_UNIV, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccx, "Notification panel header (time, date)", ControlCenterSize.K_NOTIF, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccx, "Focus notifications", ControlCenterSize.K_FOCUS, 100, 50, 200, 0, UNIT_PCT);
        sliderRow(ccx, "Power menu (reboot / shutdown)", ControlCenterSize.K_POWER, 100, 50, 200, 0, UNIT_PCT);
        resets = null;

        // ---- GoodLooks Color Guard (needs root, engine runs as a Magisk/KernelSU module)
        LinearLayout cg = section(pCg, "GOODLOOKS COLOR GUARD (ROOT)");
        cgCard = (LockableLayout) cg;
        cgCard.locked = true;
        cgCard.setAlpha(0.5f);
        cgSliderRow(cg, "Contrast", "contrast", 1.0f, 8.0f, 0.1f, 2.0f);
        cgSliderRow(cg, "Saturation", "saturation", 1.0f, 8.0f, 0.1f, 1.6f);
        cgSliderRow(cg, "Red", "tint_red", 0.3f, 2.0f, 0.05f, 1.0f);
        cgSliderRow(cg, "Green", "tint_green", 0.3f, 2.0f, 0.05f, 1.0f);
        cgSliderRow(cg, "Blue", "tint_blue", 0.3f, 2.0f, 0.05f, 1.0f);
        cgSwitchRow(cg, "Responsive Mode", "hg_responsive_mode");
        cgSwitchRow(cg, "Dedup Apply", "hg_dedup_apply");
        cgSwitchRow(cg, "SurfaceFlinger Guard", "hg_sf_guard");
        cgSwitchRow(cg, "Adaptive Debounce", "hg_adaptive_debounce");
        cgSwitchRow(cg, "Boost Keepalive (anti-tamper)", "hg_boost_keepalive");
        cgSwitchRow(cg, "Ultimate Black Almond - Auto (dark mode)", "almond_auto");
        cgSliderRow(cg, "Black Almond Intensity", "almond_intensity", 0.0f, 1.0f, 0.05f, 0.60f);

        cgNote = new TextView(this);
        cgNote.setText("Connecting to root...");
        cgNote.setTextSize(12);
        cgNote.setTextColor(GRAY);
        cgNote.setPadding(dp(16), dp(8), dp(16), 0);
        pCg.addView(cgNote);

        for (LinearLayout pg : pages) {
            root.addView(pg, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        final ScrollView sv = new ScrollView(this);
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- tab bar (scrolls sideways, selected tab is a dark pill)
        final TextView[] tabs = new TextView[tabNames.length];
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(dp(16), dp(10), dp(16), dp(10));
        for (int k = 0; k < tabs.length; k++) {
            final int idx = k;
            TextView tv = new TextView(this);
            tv.setText(tabNames[k]);
            tv.setTextSize(16);
            tv.setSingleLine(true);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(16), dp(10), dp(16), dp(10));
            tv.setOnClickListener(x -> selectTab(idx, tabs, pages, sv));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.rightMargin = dp(4);
            tabRow.addView(tv, tlp);
            tabs[k] = tv;
        }
        tabScroll = new android.widget.HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        tabScroll.addView(tabRow, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(BG);
        screen.addView(title);
        screen.addView(tabScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        screen.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(screen);
        selectTab(b == null ? 0 : b.getInt("tab", 0), tabs, pages, sv);

        ColorGuard.start(this, (values, error) -> {
            if (isFinishing() || isDestroyed()) return;
            if (values == null) {
                cgNote.setText(error == null ? "Root access is required." : error
                        + "\nGrant root to Dynamic Pill in Magisk / KernelSU, then reopen settings.");
                return;
            }
            for (Map.Entry<String, String> e : values.entrySet()) {
                CgSlider cs = cgSliders.get(e.getKey());
                IosSwitch sw = cgSwitches.get(e.getKey());
                try {
                    if (cs != null) {
                        float v = Float.parseFloat(e.getValue());
                        cs.bar.setProgress(Math.round((v - cs.min) / cs.step));
                        cs.val.setText(String.format(Locale.US, "%." + cs.dec + "f", v));
                    } else if (sw != null) {
                        sw.snap("1".equals(e.getValue().trim()));
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            cgCard.locked = false;
            cgCard.setAlpha(1f);
            cgNote.setText("Color Guard engine is active. Changes apply live, no reboot.");
        });
    }

    private int selTab = 0;
    private android.widget.HorizontalScrollView tabScroll;

    /** Shows the page of tab idx, styles the tabs (selected = dark pill, bold) and scrolls the tab into view. */
    private void selectTab(int idx, final TextView[] tabs, LinearLayout[] pages, ScrollView sv) {
        idx = Math.max(0, Math.min(tabs.length - 1, idx));
        selTab = idx;
        for (int k = 0; k < tabs.length; k++) {
            boolean on = k == idx;
            pages[k].setVisibility(on ? View.VISIBLE : View.GONE);
            tabs[k].setTextColor(on ? TEXT : GRAY);
            tabs[k].setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            GradientDrawable g = new GradientDrawable();
            g.setColor(on ? (night ? 0xFF2C2C2E : 0xFFE0E0E6) : 0);
            g.setCornerRadius(dp(14));
            tabs[k].setBackground(g);
        }
        sv.scrollTo(0, 0);
        final TextView cur = tabs[idx];
        cur.post(() -> {
            if (tabScroll != null) tabScroll.smoothScrollTo(Math.max(0, cur.getLeft() - dp(24)), 0);
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", selTab);
    }

    @Override
    protected void onPause() {
        super.onPause();
        flushPrefsNow();
        ColorGuard.flushNow();
    }

    private void cgSwitchRow(LinearLayout card, String name, final String id) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        IosSwitch sw = new IosSwitch(this, TRACK, GREEN);
        sw.snap(true);
        sw.setListener(on -> ColorGuard.queue(id, on ? "1" : "0"));
        cgSwitches.put(id, sw);
        row.addView(sw);
        card.addView(row);
    }

    /** Decimal slider backed by the module's flag file (value = min + progress * step). */
    private void cgSliderRow(LinearLayout card, String name, final String id,
                             float min, float max, float step, float def) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(this);
        val.setTextSize(15);
        val.setTextColor(GRAY);
        top.addView(val);
        final TextView cgReset = resetButton();
        top.addView(cgReset, resetLp());
        row.addView(top);

        final CgSlider cs = new CgSlider();
        cs.min = min;
        cs.step = step;
        cs.dec = step < 0.1f ? 2 : 1;
        cs.val = val;
        val.setText(String.format(Locale.US, "%." + cs.dec + "f", def));

        final FillSlider bar = new FillSlider(this, TRACK, BLUE);
        bar.setMax(Math.round((max - min) / step));
        bar.setProgress(Math.round((def - min) / step));
        bar.setListener((p, user) -> {
            String v = String.format(Locale.US, "%." + cs.dec + "f", cs.min + p * cs.step);
            val.setText(v);
            if (user) ColorGuard.queue(id, v);
        });
        cs.bar = bar;
        cgSliders.put(id, cs);
        final float defV = def;
        cgReset.setOnClickListener(v -> {
            if (cgCard != null && cgCard.locked) return;
            bar.setProgress(Math.round((defV - cs.min) / cs.step));
            String dv = String.format(Locale.US, "%." + cs.dec + "f", defV);
            val.setText(dv);
            ColorGuard.queue(id, dv);
        });

        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        blp.topMargin = dp(10);
        blp.bottomMargin = dp(8);
        row.addView(bar, blp);
        card.addView(row);
    }

    private LinearLayout section(LinearLayout root, String name) {
        TextView h = new TextView(this);
        h.setText(name);
        h.setTextSize(12);
        h.setTextColor(GRAY);
        h.setPadding(dp(16), dp(20), 0, dp(6));
        root.addView(h);

        LinearLayout card = new LockableLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(12));
        card.setBackground(g);
        root.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void divider(LinearLayout card) {
        if (card.getChildCount() == 0) return;
        View d = new View(this);
        d.setBackgroundColor(DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.leftMargin = dp(16);
        card.addView(d, lp);
    }

    private void switchRow(LinearLayout card, String name, final String key, boolean def) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        IosSwitch sw = new IosSwitch(this, TRACK, GREEN);
        sw.snap(sp.getBoolean(key, def));
        sw.setListener(on -> sp.edit().putBoolean(key, on).apply());
        row.addView(sw);
        card.addView(row);
    }

    /** Dot colour: Auto (yellow) + preset swatches + a hue slider for any custom colour. */
    private void colorRow(LinearLayout card, String name, final String key) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(6));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t);

        final int[] cols = {0, 0xFFFFCC00, 0xFF34C759, 0xFFFF3B30, 0xFFFF9500, 0xFF0A84FF, 0xFF5AC8FA,
                0xFFBF5AF2, 0xFFFF375F, 0xFFFFFFFF};
        final View[] sw = new View[cols.length];
        final int[] cur = {sp.getInt(key, 0)};
        final Runnable[] refresh = new Runnable[1];

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setPadding(0, dp(10), 0, dp(4));
        for (int i = 0; i < cols.length; i++) {
            final int c = cols[i];
            TextView v = new TextView(this);
            v.setGravity(Gravity.CENTER);
            v.setTextSize(11);
            v.setTextColor(TEXT);
            if (c == 0) v.setText("Auto");
            v.setOnClickListener(x -> {
                cur[0] = c;
                sp.edit().putInt(key, c).apply();
                refresh[0].run();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
            lp.rightMargin = dp(10);
            strip.addView(v, lp);
            sw[i] = v;
        }
        hs.addView(strip);
        row.addView(hs);

        refresh[0] = () -> {
            for (int i = 0; i < cols.length; i++) {
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(cols[i] == 0 ? TRACK : cols[i]);
                boolean sel = (cols[i] == 0 && cur[0] == 0) || (cols[i] != 0 && cur[0] == cols[i]);
                g.setStroke(dp(sel ? 3 : 1), sel ? BLUE : DIVIDER);
                sw[i].setBackground(g);
            }
        };
        refresh[0].run();

        TextView hl = new TextView(this);
        hl.setText("Custom colour (slide)");
        hl.setTextSize(13);
        hl.setTextColor(GRAY);
        hl.setPadding(0, dp(8), 0, 0);
        row.addView(hl);

        float[] hsv = new float[3];
        android.graphics.Color.colorToHSV(cur[0] != 0 ? cur[0] : 0xFFFFCC00, hsv);
        final FillSlider bar = new FillSlider(this, TRACK, BLUE);
        bar.setMax(360);
        bar.setProgress(Math.round(hsv[0]));
        bar.setListener((p, user) -> {
            if (!user) return;
            int col = android.graphics.Color.HSVToColor(new float[]{p, 1f, 1f}) | 0xFF000000;
            cur[0] = col;
            putThrottled(key, col);
            refresh[0].run();
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        blp.topMargin = dp(8);
        blp.bottomMargin = dp(8);
        row.addView(bar, blp);
        card.addView(row);
    }

    /** Row with a button that swaps the dot between the right (default) and the left side of the pill. */
    private void swapRow(LinearLayout card, String name, final String key) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final TextView btn = new TextView(this);
        btn.setTextSize(15);
        btn.setTextColor(BLUE);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(TRACK);
        g.setCornerRadius(dp(20));
        btn.setBackground(g);
        final boolean[] left = {sp.getBoolean(key, false)};
        btn.setText(left[0] ? "\u21C4  Left" : "\u21C4  Right");
        btn.setOnClickListener(v -> {
            left[0] = !left[0];
            sp.edit().putBoolean(key, left[0]).apply();
            btn.setText(left[0] ? "\u21C4  Left" : "\u21C4  Right");
        });
        row.addView(btn);
        card.addView(row);
    }

    /** Small round "reset" button shown next to the value of every slider. */
    private TextView resetButton() {
        TextView b = new TextView(this);
        b.setText("\u21BA");
        b.setTextSize(20);
        b.setTextColor(BLUE);
        b.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(TRACK);
        g.setCornerRadius(dp(16));
        b.setBackground(g);
        return b;
    }

    private LinearLayout.LayoutParams resetLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(32));
        lp.leftMargin = dp(10);
        return lp;
    }

    /** value = progress + min + shift; mm sliders store 0.1 mm units. */
    private void sliderRow(LinearLayout card, final String name, final String key, final int def,
                           final int min, int max, final int shift, final int unit) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(this);
        val.setTextSize(15);
        val.setTextColor(GRAY);
        top.addView(val);
        final TextView reset = resetButton();
        top.addView(reset, resetLp());
        row.addView(top);

        final int cur = sp.getInt(key, def);
        val.setText(fmt(cur, unit));
        reset.setAlpha(cur == def ? 0.35f : 1f);

        final FillSlider bar = new FillSlider(this, TRACK, BLUE);
        bar.setMax(max - min);
        bar.setProgress(cur - shift - min);
        bar.setListener((p, user) -> {
            int v = p + min + shift;
            val.setText(fmt(v, unit));
            reset.setAlpha(v == def ? 0.35f : 1f);
            if (user) putThrottled(key, v);
        });
        final Runnable doReset = () -> {
            pendingInts.remove(key);
            sp.edit().putInt(key, def).apply();
            bar.setProgress(def - shift - min);
            val.setText(fmt(def, unit));
            reset.setAlpha(0.35f);
        };
        reset.setOnClickListener(v -> doReset.run());
        if (resets != null) resets.add(doReset);

        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        blp.topMargin = dp(10);
        blp.bottomMargin = dp(8);
        row.addView(bar, blp);
        card.addView(row);
    }

    /** "Apply now" (restarts System UI with root, so everything is read again) + "Reset this tab". */
    private void actionCard(LinearLayout page, final java.util.ArrayList<Runnable> tabResets) {
        LinearLayout card = section(page, "ACTIONS");
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView apply = actionButton("Apply now", BLUE);
        apply.setOnClickListener(v -> applyNow());
        TextView rst = actionButton("Reset this tab", 0xFFFF3B30);
        rst.setOnClickListener(v -> {
            for (Runnable r : tabResets) r.run();
            Toast.makeText(this, "Reset to default", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        l1.rightMargin = dp(6);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        l2.leftMargin = dp(6);
        row.addView(apply, l1);
        row.addView(rst, l2);
        card.addView(row);

        TextView note = new TextView(this);
        note.setText("Values are saved at once. \"Apply now\" restarts System UI (root) so the Control Center is rebuilt with the new sizes.");
        note.setTextSize(12);
        note.setTextColor(GRAY);
        note.setPadding(dp(16), 0, dp(16), dp(12));
        card.addView(note);
    }

    private TextView actionButton(String text, int color) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(color);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(TRACK);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        return b;
    }

    private void applyNow() {
        flushPrefsNow();
        Toast.makeText(this, "Restarting System UI...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try { Thread.sleep(500); } catch (InterruptedException ignored) { }   // let the prefs file reach the disk
            final boolean ok = RootUtil.restartSystemUi();
            ui.post(() -> {
                if (!ok && !isFinishing()) Toast.makeText(this,
                        "Root not available. Reopen the Control Center or reboot to apply.", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    /** Row with a "Play" label: asks the pill (inside System UI) to play one animation right now. */
    private void previewRow(LinearLayout card, String name, final String scene) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView go = new TextView(this);
        go.setText("Play");
        go.setTextSize(16);
        go.setTextColor(BLUE);
        row.addView(go);

        row.setOnClickListener(v -> sp.edit()
                .putString(PillController.K_PREVIEW, scene + ":" + System.currentTimeMillis()).apply());
        card.addView(row);
    }

    private String fmt(int v, int unit) {
        if (unit == UNIT_PCT) return v + " %";
        if (unit == UNIT_SEC) return (v / 10f) + " s";
        if (unit == UNIT_COLS) return v <= 1 ? "Default" : String.valueOf(v);
        if (unit == UNIT_DP) return v <= 0 ? "Default" : v + " dp";
        return (v / 10f) + " mm";
    }
}

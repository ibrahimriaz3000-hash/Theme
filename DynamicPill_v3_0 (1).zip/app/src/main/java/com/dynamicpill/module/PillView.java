package com.dynamicpill.module;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Black capsule with an indicator dot (right) and a small charging bolt (left). Every change fades smoothly. */
public class PillView extends View {
    private static final ArgbEvaluator ARGB = new ArgbEvaluator();

    private static final int BOLT_GREEN = 0xFF34C759;
    /** One full blink (dim and back) takes this long. */
    private static final long BLINK_PERIOD_MS = 1000;
    /** Fade time for colour / thickness / icon changes. */
    private static final long FADE_MS = 350;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bolt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path boltPath = new Path();
    private final Path shape = new Path();
    private final Path edgeShape = new Path();
    private float smoothN = 2f;                 // 2 = plain circular capsule, > 2 = iOS style continuous curve
    private float shapeW = -1, shapeH = -1, shapeIn = -1, shapeNKey = -1;
    private float edgeW = -1, edgeH = -1, edgeIn = -1, edgeNKey = -1;

    // outline: thickness and colour fade to their target values
    private float borderTarget = 0f, borderCur = 0f;
    private int strokeTarget = 0xFFFFFFFF, strokeCur = 0xFFFFFFFF;
    private ValueAnimator borderAnim, strokeAnim;

    // dot: colour fades, blink fades
    private boolean dotOn = true;
    private int dotTarget = 0xFFFFCC00, dotCur = 0xFFFFCC00; // yellow
    private ValueAnimator dotColorAnim;

    // charging bolt fades in and out
    private boolean charging = false;
    private float boltFactor = 0f;
    private ValueAnimator boltAnim;

    private float dotBlink = 1f;     // dot blink (new notification)
    private float strokeBlink = 1f;  // outline blink (call)
    private ValueAnimator dotBlinkAnim, strokeBlinkAnim, dotRestoreAnim;

    // ---------------------------------------------------------------- island (expanding pill) state
    public static final int EV_NONE = 0, EV_CHARGE = 1, EV_SILENT = 2, EV_VIBRATE = 3;
    private static final int RED = 0xFFFF3B30, ORANGE = 0xFFFF9F0A;
    private static final int CHARGE_GREEN = 0xFF34C759, CHARGE_TEAL = 0xFF00C7B0, CHARGE_DARK = 0xFF2E6B3A;
    private static final int NEON = 0xFF39FF14;

    private final float density;
    /** Window is wider / taller than the pill so the pill can grow and the glow has room: pill is drawn centred. */
    private float baseW = 100, baseH = 40, expW = 300, expH = 50;
    private float expCur = 0f;                 // 0 = normal pill, 1 = fully expanded (can overshoot a little)
    private int evType = EV_NONE, evLevel = 0;
    private float swapFactor = 1f;             // content cross-fade when the event type changes while expanded
    private ValueAnimator expAnim, swapAnim;
    private final Runnable collapseRun = new Runnable() { @Override public void run() { collapse(); } };

    // neon glow (WhatsApp)
    private boolean glowOn = false;
    private float glowFactor = 0f;             // fade in / out
    private float glowPulse = 1f;              // breathing
    private ValueAnimator glowFadeAnim, glowPulseAnim;
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private BlurMaskFilter glowBlurBig, glowBlurMid;

    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint battPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path iconPath = new Path();
    private final RectF tmp = new RectF();
    private final Path glowShape = new Path();
    private float glowW = -1, glowH = -1, glowIn = -1, glowNKey = -1;

    public PillView(Context context) {
        super(context);
        paint.setDither(true);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(0xFF000000); // pure dark black, full alpha
        paint.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        dot.setStyle(Paint.Style.FILL);
        bolt.setStyle(Paint.Style.FILL);
        bolt.setColor(BOLT_GREEN);
        density = context.getResources().getDisplayMetrics().density;
        glowPaint.setStyle(Paint.Style.STROKE);
        glowBlurBig = new BlurMaskFilter(density * 11f, BlurMaskFilter.Blur.NORMAL);
        glowBlurMid = new BlurMaskFilter(density * 5f, BlurMaskFilter.Blur.NORMAL);
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        iconPaint.setStrokeCap(Paint.Cap.ROUND);
        iconPaint.setStrokeJoin(Paint.Join.ROUND);
        battPaint.setStyle(Paint.Style.FILL);
        setLayerType(LAYER_TYPE_SOFTWARE, null);   // BlurMaskFilter (glow) needs a software layer
    }

    /** Pill size at rest and when expanded (pixels). The window is centred on the pill. */
    public void setGeometry(float baseWidth, float baseHeight, float expandedWidth, float expandedHeight) {
        if (baseWidth == baseW && baseHeight == baseH && expandedWidth == expW && expandedHeight == expH) return;
        baseW = baseWidth; baseH = baseHeight; expW = expandedWidth; expH = expandedHeight;
        invalidate();
    }

    public boolean isExpanded() { return evType != EV_NONE; }

    // ------------------------------------------------------------------ expand / collapse events

    /** Grows the pill into a wide island with the event content, holds, then shrinks back. */
    public void showEvent(int type, int level, long holdMs) {
        if (type == EV_NONE) return;
        boolean wasShown = evType != EV_NONE && expCur > 0.6f;
        evLevel = level;
        removeCallbacks(collapseRun);
        if (wasShown && evType != type) {          // already open: cross-fade the content
            evType = type;
            if (swapAnim != null) swapAnim.cancel();
            swapAnim = ValueAnimator.ofFloat(0f, 1f);
            swapAnim.setDuration(220);
            swapAnim.addUpdateListener(a -> { swapFactor = (Float) a.getAnimatedValue(); invalidate(); });
            swapAnim.start();
        } else {
            evType = type;
            swapFactor = 1f;
        }
        if (expAnim != null) expAnim.cancel();
        if (expCur < 1f) {
            expAnim = ValueAnimator.ofFloat(expCur, 1f);
            expAnim.setDuration(520);
            expAnim.setInterpolator(new OvershootInterpolator(0.9f));
            expAnim.addUpdateListener(a -> { expCur = (Float) a.getAnimatedValue(); invalidate(); });
            expAnim.start();
        }
        postDelayed(collapseRun, holdMs);
    }

    private void collapse() {
        if (expAnim != null) expAnim.cancel();
        expAnim = ValueAnimator.ofFloat(expCur, 0f);
        expAnim.setDuration(380);
        expAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        expAnim.addUpdateListener(a -> { expCur = Math.max(0f, (Float) a.getAnimatedValue()); invalidate(); });
        expAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(android.animation.Animator an) { cancelled = true; }
            @Override public void onAnimationEnd(android.animation.Animator an) {
                if (!cancelled) { evType = EV_NONE; expCur = 0f; invalidate(); }
            }
        });
        expAnim.start();
    }

    // ------------------------------------------------------------------ neon glow (WhatsApp open)

    /** Green neon outline that breathes for as long as it is on. Fades in and out. */
    public void setGlow(boolean on) {
        if (on == glowOn) return;
        glowOn = on;
        if (glowFadeAnim != null) glowFadeAnim.cancel();
        glowFadeAnim = ValueAnimator.ofFloat(glowFactor, on ? 1f : 0f);
        glowFadeAnim.setDuration(on ? 450 : 350);
        glowFadeAnim.addUpdateListener(a -> { glowFactor = (Float) a.getAnimatedValue(); invalidate(); });
        glowFadeAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator an) {
                if (!glowOn && glowPulseAnim != null) { glowPulseAnim.cancel(); glowPulseAnim = null; }
            }
        });
        glowFadeAnim.start();
        if (on && glowPulseAnim == null) {
            glowPulseAnim = ValueAnimator.ofFloat(0.45f, 1f);
            glowPulseAnim.setDuration(1100);
            glowPulseAnim.setRepeatCount(ValueAnimator.INFINITE);
            glowPulseAnim.setRepeatMode(ValueAnimator.REVERSE);
            glowPulseAnim.setInterpolator(new AccelerateDecelerateInterpolator());
            glowPulseAnim.addUpdateListener(a -> { glowPulse = (Float) a.getAnimatedValue(); invalidate(); });
            glowPulseAnim.start();
        }
    }

    /** Corner smoothness 0..100. 0 = circular ends, higher = softer, continuous (iOS style) curvature. */
    public void setSmooth(int percent) {
        float n = 2f + 0.6f * Math.max(0, Math.min(100, percent)) / 100f;
        if (n != smoothN) {
            smoothN = n;
            invalidate();
        }
    }

    /**
     * Capsule whose end caps are superellipse arcs: the curvature changes gradually into the straight
     * edges (no visible "where the circle starts" line), which looks smoother than a plain round rect.
     */
    private static void buildCapsule(Path p, float w, float h, float inset, float n) {
        p.reset();
        float r = h / 2f - inset;
        if (r <= 0f || w <= h) { p.addRoundRect(new RectF(inset, inset, w - inset, h - inset), h / 2f, h / 2f, Path.Direction.CW); return; }
        float e = 2f / n;
        float cy = h / 2f, cxR = w - h / 2f, cxL = h / 2f;
        final int N = 40;
        for (int i = 0; i <= N; i++) {                       // right cap, top -> bottom
            double u = -Math.PI / 2 + Math.PI * i / N;
            float c = (float) Math.pow(Math.max(0.0, Math.cos(u)), e);
            float sn = (float) (Math.signum(Math.sin(u)) * Math.pow(Math.abs(Math.sin(u)), e));
            float x = cxR + r * c, y = cy + r * sn;
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        for (int i = 0; i <= N; i++) {                       // left cap, bottom -> top
            double u = -Math.PI / 2 + Math.PI * i / N;
            float c = (float) Math.pow(Math.max(0.0, Math.cos(u)), e);
            float sn = (float) (Math.signum(Math.sin(u)) * Math.pow(Math.abs(Math.sin(u)), e));
            p.lineTo(cxL - r * c, cy - r * sn);
        }
        p.close();
    }

    /** Border thickness in pixels; 0 = no border. Fades to the new thickness. */
    public void setBorder(float px) {
        px = Math.max(0f, px);
        if (px == borderTarget) return;
        borderTarget = px;
        if (borderAnim != null) borderAnim.cancel();
        final float from = borderCur, to = px;
        borderAnim = ValueAnimator.ofFloat(0f, 1f);
        borderAnim.setDuration(FADE_MS);
        borderAnim.addUpdateListener(a -> {
            borderCur = from + (to - from) * (Float) a.getAnimatedValue();
            invalidate();
        });
        borderAnim.start();
    }

    /** Border colour (white normally, green while charging or in a call). Cross-fades. */
    public void setStrokeColor(int color) {
        if (color == strokeTarget) return;
        strokeTarget = color;
        if (strokeAnim != null) strokeAnim.cancel();
        final int from = strokeCur, to = color;
        strokeAnim = ValueAnimator.ofFloat(0f, 1f);
        strokeAnim.setDuration(FADE_MS);
        strokeAnim.addUpdateListener(a -> {
            strokeCur = (Integer) ARGB.evaluate((Float) a.getAnimatedValue(), from, to);
            invalidate();
        });
        strokeAnim.start();
    }

    /** 0..100 percent; 100 = fully solid black. */
    public void setPillAlpha(int percent) {
        int a = Math.round(255f * Math.max(0, Math.min(100, percent)) / 100f);
        if (paint.getAlpha() != a) {
            paint.setAlpha(a);
            invalidate();
        }
    }

    /** Indicator dot inside the pill: shown or not, and its colour (cross-fades). */
    public void setDot(boolean on, int color) {
        if (on != dotOn) {
            dotOn = on;
            invalidate();
        }
        if (color == dotTarget) return;
        dotTarget = color;
        if (dotColorAnim != null) dotColorAnim.cancel();
        final int from = dotCur, to = color;
        dotColorAnim = ValueAnimator.ofFloat(0f, 1f);
        dotColorAnim.setDuration(FADE_MS);
        dotColorAnim.addUpdateListener(a -> {
            dotCur = (Integer) ARGB.evaluate((Float) a.getAnimatedValue(), from, to);
            invalidate();
        });
        dotColorAnim.start();
    }

    /** Small green lightning bolt on the left side while the phone is charging. Fades in and out. */
    public void setBolt(boolean on) {
        if (on == charging) return;
        charging = on;
        if (boltAnim != null) boltAnim.cancel();
        boltAnim = ValueAnimator.ofFloat(boltFactor, on ? 1f : 0f);
        boltAnim.setDuration(FADE_MS);
        boltAnim.addUpdateListener(a -> {
            boltFactor = (Float) a.getAnimatedValue();
            invalidate();
        });
        boltAnim.start();
    }

    private ValueAnimator startBlink(final boolean forDot) {
        ValueAnimator a = ValueAnimator.ofFloat(1f, 0.1f);
        a.setDuration(BLINK_PERIOD_MS / 2);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.addUpdateListener(v -> {
            if (forDot) dotBlink = (Float) v.getAnimatedValue();
            else strokeBlink = (Float) v.getAnimatedValue();
            invalidate();
        });
        a.start();
        return a;
    }

    /** Makes the dot fade out and in once per second. Stopping fades it back to full smoothly. */
    public void setBlink(boolean on) {
        if (on) {
            if (dotRestoreAnim != null) {
                dotRestoreAnim.cancel();
                dotRestoreAnim = null;
            }
            if (dotBlinkAnim == null) dotBlinkAnim = startBlink(true);
        } else if (dotBlinkAnim != null) {
            dotBlinkAnim.cancel();
            dotBlinkAnim = null;
            final float from = dotBlink;
            if (from >= 0.99f) {
                dotBlink = 1f;
                invalidate();
            } else {
                dotRestoreAnim = ValueAnimator.ofFloat(from, 1f);
                dotRestoreAnim.setDuration(250);
                dotRestoreAnim.addUpdateListener(a -> {
                    dotBlink = (Float) a.getAnimatedValue();
                    invalidate();
                });
                dotRestoreAnim.start();
            }
        }
    }

    /** Makes the outline fade out and in once per second (call). */
    public void setStrokeBlink(boolean on) {
        if (on) {
            if (strokeBlinkAnim == null) strokeBlinkAnim = startBlink(false);
        } else if (strokeBlinkAnim != null) {
            strokeBlinkAnim.cancel();
            strokeBlinkAnim = null;
            strokeBlink = 1f;
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(collapseRun);
        ValueAnimator[] all = {borderAnim, strokeAnim, dotColorAnim, boltAnim, dotBlinkAnim, strokeBlinkAnim, dotRestoreAnim,
                expAnim, swapAnim, glowFadeAnim, glowPulseAnim};
        for (ValueAnimator a : all) if (a != null) a.cancel();
        borderAnim = strokeAnim = dotColorAnim = boltAnim = dotBlinkAnim = strokeBlinkAnim = dotRestoreAnim = null;
        expAnim = swapAnim = glowFadeAnim = glowPulseAnim = null;
        expCur = 0f; evType = EV_NONE; swapFactor = 1f; glowFactor = glowOn ? 1f : 0f; glowPulse = 1f;
        // snap to the final values so nothing stays half faded
        borderCur = borderTarget;
        strokeCur = strokeTarget;
        dotCur = dotTarget;
        boltFactor = charging ? 1f : 0f;
        dotBlink = 1f;
        strokeBlink = 1f;
    }

    private float contentAlpha() {
        float a = (expCur - 0.55f) / 0.45f;
        return Math.max(0f, Math.min(1f, a)) * swapFactor;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float winW = getWidth(), winH = getHeight();
        float e = expCur;
        float w = baseW + (expW - baseW) * e;
        float h = baseH + (expH - baseH) * Math.min(e, 1.04f);
        float left = (winW - w) / 2f, top = (winH - h) / 2f;
        float ca = contentAlpha();

        canvas.save();
        canvas.translate(left, top);

        boolean plain = smoothN <= 2.001f;
        if (plain) {
            rect.set(0, 0, w, h);
            canvas.drawRoundRect(rect, h / 2f, h / 2f, paint);
        } else {
            if (shapeW != w || shapeH != h || shapeNKey != smoothN || shapeIn != 0f) {
                buildCapsule(shape, w, h, 0f, smoothN);
                shapeW = w; shapeH = h; shapeNKey = smoothN; shapeIn = 0f;
            }
            canvas.drawPath(shape, paint);
        }
        if (borderCur > 0.05f) {
            stroke.setColor(strokeCur);
            stroke.setAlpha(Math.round(255f * strokeBlink * Math.min(1f, borderCur)));
            stroke.setStrokeWidth(borderCur);
            float in = borderCur / 2f;
            if (plain) {
                rect.set(in, in, w - in, h - in);
                float rr = Math.max(0f, h / 2f - in);
                canvas.drawRoundRect(rect, rr, rr, stroke);
            } else {
                if (edgeW != w || edgeH != h || edgeNKey != smoothN || edgeIn != in) {
                    buildCapsule(edgeShape, w, h, in, smoothN);
                    edgeW = w; edgeH = h; edgeNKey = smoothN; edgeIn = in;
                }
                canvas.drawPath(edgeShape, stroke);
            }
        }

        if (glowFactor > 0.01f) drawGlow(canvas, w, h, plain);

        float rest = 1f - Math.min(1f, ca * 1.6f);       // normal indicators fade out while the island content shows
        if (dotOn && rest > 0.01f) {
            dot.setColor(dotCur);
            dot.setAlpha(Math.round(255f * dotBlink * rest));
            canvas.drawCircle(w - h * 0.5f, h / 2f, h * 0.16f, dot);
        }
        if (boltFactor > 0.01f && rest > 0.01f) drawBolt(canvas, h, rest);

        if (evType != EV_NONE && ca > 0.01f) {
            if (evType == EV_CHARGE) drawCharge(canvas, w, h, ca);
            else drawRinger(canvas, w, h, ca, evType == EV_SILENT);
        }
        canvas.restore();
    }

    /** Layered blur strokes = neon tube. Breathes with glowPulse. */
    private void drawGlow(Canvas canvas, float w, float h, boolean plain) {
        float a = glowFactor * glowPulse;
        float sw = density * 2f;
        float in = sw / 2f;
        if (glowW != w || glowH != h || glowIn != in || glowNKey != smoothN) {
            if (plain) {
                glowShape.reset();
                glowShape.addRoundRect(new RectF(in, in, w - in, h - in), h / 2f - in, h / 2f - in, Path.Direction.CW);
            } else {
                buildCapsule(glowShape, w, h, in, smoothN);
            }
            glowW = w; glowH = h; glowIn = in; glowNKey = smoothN;
        }
        glowPaint.setColor(NEON);
        glowPaint.setMaskFilter(glowBlurBig);
        glowPaint.setStrokeWidth(density * 6f);
        glowPaint.setAlpha(Math.round(200f * a));
        canvas.drawPath(glowShape, glowPaint);
        glowPaint.setMaskFilter(glowBlurMid);
        glowPaint.setStrokeWidth(density * 3.5f);
        glowPaint.setAlpha(Math.round(230f * a));
        canvas.drawPath(glowShape, glowPaint);
        glowPaint.setMaskFilter(null);
        glowPaint.setStrokeWidth(sw);
        glowPaint.setColor(0xFFB6FFA8);                   // bright core of the tube
        glowPaint.setAlpha(Math.round(255f * (0.6f + 0.4f * glowPulse) * glowFactor));
        canvas.drawPath(glowShape, glowPaint);
    }

    private float textBaseline(float h) {
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        return h / 2f - (fm.ascent + fm.descent) / 2f;
    }

    /** "Charging" on the left, "75%" + battery on the right (like the iOS island). */
    private void drawCharge(Canvas canvas, float w, float h, float ca) {
        float H = expH;
        float pad = H * 0.55f;
        textPaint.setTextSize(H * 0.40f);

        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setColor(0xFFFFFFFF);
        textPaint.setAlpha(Math.round(255f * ca));
        canvas.drawText("Charging", pad, textBaseline(h), textPaint);

        // battery icon
        float bodyH = H * 0.46f, bodyW = H * 0.98f;
        float nubW = bodyH * 0.13f, nubH = bodyH * 0.36f, gap = nubW * 0.7f;
        float right = w - pad;
        float bodyRight = right - nubW - gap;
        float bodyLeft = bodyRight - bodyW;
        float bt = h / 2f - bodyH / 2f, bb = bt + bodyH;
        float r = bodyH * 0.34f;
        int al = Math.round(255f * ca);

        battPaint.setShader(null);
        battPaint.setColor(CHARGE_DARK);
        battPaint.setAlpha(al);
        tmp.set(bodyLeft, bt, bodyRight, bb);
        canvas.drawRoundRect(tmp, r, r, battPaint);                 // empty part
        tmp.set(bodyRight + gap, h / 2f - nubH / 2f, bodyRight + gap + nubW, h / 2f + nubH / 2f);
        canvas.drawRoundRect(tmp, nubW / 2f, nubW / 2f, battPaint); // nub

        float lvl = Math.max(0.04f, Math.min(1f, evLevel / 100f));
        battPaint.setShader(new LinearGradient(bodyLeft, 0, bodyRight, 0,
                CHARGE_TEAL, CHARGE_GREEN, Shader.TileMode.CLAMP));
        battPaint.setAlpha(al);
        canvas.save();
        canvas.clipRect(bodyLeft, bt, bodyLeft + bodyW * lvl, bb);
        tmp.set(bodyLeft, bt, bodyRight, bb);
        canvas.drawRoundRect(tmp, r, r, battPaint);                 // filled part
        canvas.restore();
        battPaint.setShader(null);

        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setColor(CHARGE_GREEN);
        textPaint.setAlpha(al);
        canvas.drawText(evLevel + "%", bodyLeft - H * 0.17f, textBaseline(h), textPaint);
    }

    /** Coloured rounded icon on the left, coloured label on the right: "Silent" / "Vibration". */
    private void drawRinger(Canvas canvas, float w, float h, float ca, boolean silent) {
        float H = expH;
        int col = silent ? RED : ORANGE;
        int al = Math.round(255f * ca);

        float ph = H * 0.74f, pw = H * 1.45f;
        float pl = H * 0.13f, pt = h / 2f - ph / 2f;
        battPaint.setShader(null);
        battPaint.setColor(col);
        battPaint.setAlpha(al);
        tmp.set(pl, pt, pl + pw, pt + ph);
        canvas.drawRoundRect(tmp, ph / 2f, ph / 2f, battPaint);

        float cx = pl + pw / 2f, cy = h / 2f, s = ph * 0.62f;
        iconPaint.setColor(0xFFFFFFFF);
        iconPaint.setAlpha(al);
        if (silent) drawBellSlash(canvas, cx, cy, s, col, al);
        else drawVibrate(canvas, cx, cy, s, al);

        textPaint.setTextSize(H * 0.40f);
        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setColor(col);
        textPaint.setAlpha(al);
        canvas.drawText(silent ? "Silent" : "Vibration", w - H * 0.55f, textBaseline(h), textPaint);
    }

    private void drawBellSlash(Canvas canvas, float cx, float cy, float s, int bg, int al) {
        iconPaint.setStyle(Paint.Style.FILL);
        float L = cx - 0.40f * s, R = cx + 0.40f * s;
        iconPath.reset();
        iconPath.moveTo(L, cy + 0.28f * s);
        iconPath.cubicTo(L + 0.10f * s, cy + 0.20f * s, L + 0.12f * s, cy + 0.05f * s, L + 0.14f * s, cy - 0.10f * s);
        iconPath.cubicTo(L + 0.16f * s, cy - 0.28f * s, cx - 0.24f * s, cy - 0.40f * s, cx, cy - 0.40f * s);
        iconPath.cubicTo(cx + 0.24f * s, cy - 0.40f * s, R - 0.16f * s, cy - 0.28f * s, R - 0.14f * s, cy - 0.10f * s);
        iconPath.cubicTo(R - 0.12f * s, cy + 0.05f * s, R - 0.10f * s, cy + 0.20f * s, R, cy + 0.28f * s);
        iconPath.close();
        canvas.drawPath(iconPath, iconPaint);
        tmp.set(cx - 0.13f * s, cy + 0.32f * s, cx + 0.13f * s, cy + 0.50f * s);
        canvas.drawOval(tmp, iconPaint);                              // clapper
        canvas.drawCircle(cx, cy - 0.45f * s, 0.05f * s, iconPaint);  // top knob
        // slash: coloured gap first, then the white line
        iconPaint.setStyle(Paint.Style.STROKE);
        iconPaint.setColor(bg);
        iconPaint.setAlpha(al);
        iconPaint.setStrokeWidth(0.24f * s);
        canvas.drawLine(cx - 0.50f * s, cy - 0.50f * s, cx + 0.50f * s, cy + 0.50f * s, iconPaint);
        iconPaint.setColor(0xFFFFFFFF);
        iconPaint.setAlpha(al);
        iconPaint.setStrokeWidth(0.09f * s);
        canvas.drawLine(cx - 0.50f * s, cy - 0.50f * s, cx + 0.50f * s, cy + 0.50f * s, iconPaint);
        iconPaint.setStyle(Paint.Style.FILL);
    }

    private void drawVibrate(Canvas canvas, float cx, float cy, float s, int al) {
        iconPaint.setStyle(Paint.Style.STROKE);
        iconPaint.setStrokeWidth(0.075f * s);
        tmp.set(cx - 0.16f * s, cy - 0.36f * s, cx + 0.16f * s, cy + 0.36f * s);
        canvas.drawRoundRect(tmp, 0.07f * s, 0.07f * s, iconPaint);
        for (int side = -1; side <= 1; side += 2) {
            iconPaint.setStrokeWidth(0.07f * s);
            iconPath.reset();
            iconPath.moveTo(cx + side * 0.28f * s, cy - 0.15f * s);
            iconPath.quadTo(cx + side * 0.38f * s, cy, cx + side * 0.28f * s, cy + 0.15f * s);
            canvas.drawPath(iconPath, iconPaint);
            iconPath.reset();
            iconPath.moveTo(cx + side * 0.41f * s, cy - 0.26f * s);
            iconPath.quadTo(cx + side * 0.60f * s, cy, cx + side * 0.41f * s, cy + 0.26f * s);
            canvas.drawPath(iconPath, iconPaint);
        }
        iconPaint.setStyle(Paint.Style.FILL);
    }

    /** Small lightning bolt, centred in the left cap of the pill. */
    private void drawBolt(Canvas canvas, float h, float rest) {
        float bh = h * 0.46f;
        float bw = bh * 0.7f;
        float x0 = h * 0.5f - bw / 2f;
        float y0 = h * 0.5f - bh / 2f;
        boltPath.reset();
        boltPath.moveTo(x0 + 0.62f * bw, y0);
        boltPath.lineTo(x0 + 0.08f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.46f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.34f * bw, y0 + bh);
        boltPath.lineTo(x0 + 0.92f * bw, y0 + 0.42f * bh);
        boltPath.lineTo(x0 + 0.54f * bw, y0 + 0.42f * bh);
        boltPath.close();
        bolt.setAlpha(Math.round(255f * boltFactor * rest));
        canvas.drawPath(boltPath, bolt);
    }
}

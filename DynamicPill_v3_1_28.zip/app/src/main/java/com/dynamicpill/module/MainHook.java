package com.dynamicpill.module;

import android.app.Application;
import android.content.Context;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {
    private static boolean started = false;
    private static final int K_CC = 1, K_BOUNCER = 2, K_BATT = 4, K_SB = 8;
    private static final java.util.concurrent.ConcurrentHashMap<Class<?>, Integer> KINDS =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** Class-name check done once per class (this runs for every view System UI attaches). */
    private static int classKind(Class<?> c) {
        Integer k = KINDS.get(c);
        if (k != null) return k;
        String l = c.getName().toLowerCase();
        int r = 0;
        if (l.contains("controlcenter")) r |= K_CC;
        if (l.contains("securitycontainer") || l.contains("bouncer") || l.contains("keyguardhostview")) r |= K_BOUNCER;
        if (l.contains("batterymeterview")) r |= K_BATT;
        if (l.contains("statusbarview") && !l.contains("controlcenter")) r |= K_SB;   // PhoneStatusBarView, KeyguardStatusBarView ...
        KINDS.put(c, r);
        return r;
    }

    /** True when one of the view's parents is a Control Center class. */
    private static boolean insideControlCenter(android.view.View v) {
        android.view.ViewParent p = v.getParent();
        for (int i = 0; i < 25 && p != null; i++) {
            if ((classKind(p.getClass()) & K_CC) != 0) return true;
            p = p.getParent();
        }
        return false;
    }

    /** Topmost Control Center view above v (used as the host of the floating battery %). */
    static android.view.ViewGroup ccRoot(android.view.View v) {
        android.view.ViewGroup top = null;
        android.view.ViewParent p = v.getParent();
        for (int i = 0; i < 25 && p != null; i++) {
            if (p instanceof android.view.ViewGroup && (classKind(p.getClass()) & K_CC) != 0)
                top = (android.view.ViewGroup) p;
            p = p.getParent();
        }
        return top;
    }

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        try {
            XposedHelpers.findAndHookMethod(android.view.View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        android.view.View v = (android.view.View) param.thisObject;
                        int kind = classKind(v.getClass());
                        if ((kind & K_CC) != 0) PillController.registerControlCenter(v);
                        if ((kind & K_BOUNCER) != 0) PillController.registerBouncer(v);
                        if ((kind & K_BATT) != 0) CcBattery.attach(v, insideControlCenter(v));
                        if ((kind & K_SB) != 0 && !insideControlCenter(v)) PillController.registerStatusBar(v);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: bar hook failed: " + t);
        }
        try {
            StatusBarSize.hook();
            ControlCenterSize.hook();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: status bar size failed: " + t);
        }
        try {
            PillController.hookShadeWindow(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: shade window hook failed: " + t);
        }
        try {
            PillController.hookNotifications();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: notification hook failed: " + t);
        }
        try {
            PillController.hookNotificationList();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: notification list hook failed: " + t);
        }
        try {
            PillController.hookStatusBarState(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: state hook failed: " + t);
        }
        try {
            PillController.hookKeyguardManager(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: keyguard manager hook failed: " + t);
        }
        try {
            XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Context ctx = (Context) param.thisObject;
                        if (!"com.android.systemui".equals(ctx.getPackageName())) return;
                        if (started) return;
                        started = true;
                        new PillController(ctx).start();
                    } catch (Throwable t) {
                        XposedBridge.log("DynamicPill: start failed: " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: hook failed: " + t);
        }
    }
}

package com.dynamicpill.module;

import android.content.res.Resources;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Control Center sizes, taken from the MIUI System UI dimens (MiuiSystemUI.apk, qs_control_* / qs_*).
 * Each slider scales a whole family of dimens by a percentage (100 = system value), so it works for every
 * screen density / layout variant. Header top offset adds dp; columns replaces the tile column count.
 * Read again when the Control Center is rebuilt (reopen it, or restart System UI).
 */
final class ControlCenterSize {
    static final String K_TILE = "cc_s_tile", K_BIG = "cc_s_big", K_TEXT = "cc_s_text", K_SPACE = "cc_s_space",
            K_MARGIN = "cc_s_margin", K_CORNER = "cc_s_corner", K_BRIGHT = "cc_s_bright", K_HEADER = "cc_s_header",
            K_DETAIL = "cc_s_detail", K_CUSTOM = "cc_s_custom", K_HEADER_TOP = "cc_header_top_dp", K_COLUMNS = "cc_columns",
            K_MEDIA = "cc_s_media", K_FOOT = "cc_s_foot", K_PAGE = "cc_s_page", K_EDIT = "cc_s_edit", K_EXPAND = "cc_s_expand",
            K_VOLUME = "cc_s_volume", K_MIPLAY = "cc_s_miplay", K_DEVICE = "cc_s_device", K_NOTIF = "cc_s_notif",
            K_FOCUS = "cc_s_focus", K_UNIV = "cc_s_univ", K_POWER = "cc_s_power";

    private static final String[] KEYS = {null, K_TILE, K_BIG, K_TEXT, K_SPACE, K_MARGIN, K_CORNER, K_BRIGHT,
            K_HEADER, K_DETAIL, K_CUSTOM, K_HEADER_TOP, K_MEDIA, K_FOOT, K_PAGE, K_EDIT, K_EXPAND,
            K_VOLUME, K_MIPLAY, K_DEVICE, K_NOTIF, K_FOCUS, K_UNIV, K_POWER};
    private static final int G_NONE = 0, G_HEADER_TOP = 11, G_MEDIA = 12, G_FOOT = 13, G_PAGE = 14, G_EDIT = 15, G_EXPAND = 16,
            G_VOLUME = 17, G_MIPLAY = 18, G_DEVICE = 19, G_NOTIF = 20, G_FOCUS = 21, G_UNIV = 22, G_POWER = 23;
    private static final int GROUPS = 24;

    /** Every other control center dimen is sorted into a family by its name (MIUI qs_* naming). */
    private static int prefixGroup(String n) {
        if (n == null) return G_NONE;
        if (n.contains("seekbar_progress") || n.contains("falsing") || n.contains("elevation")
                || n.contains("stroke_width") || n.contains("overfling") || n.contains("alpha")) return G_NONE;
        // MIUISystemUIPlugin.apk (the real Control Center / volume panel / MiPlay live in this plugin)
        if (n.contains("thresh") || n.contains("velocity")) return G_NONE;
        if (n.startsWith("miui_volume_")) return G_VOLUME;
        if (n.startsWith("miplay_") || n.startsWith("window_card_")) return G_MIPLAY;
        if (n.startsWith("miui_controls_") || n.startsWith("device_controls_") || n.startsWith("controls_app")
                || n.startsWith("controls_management") || n.startsWith("device_center_") || n.startsWith("external_entry_")
                || n.startsWith("control_center_device_controls")) return G_DEVICE;
        if (n.startsWith("notification_panel_")) return G_NOTIF;
        if (n.startsWith("focus_notify_")) return G_FOCUS;
        if (n.startsWith("control_center_universal_") || n.startsWith("qs_card_") || n.startsWith("control_center_qs_item")) return G_UNIV;
        if (n.startsWith("reboot_shutdown_")) return G_POWER;
        if (n.startsWith("media_player_")) return G_MEDIA;
        if (n.startsWith("header_privacy_") || n.startsWith("control_center_status_bar_padding")
                || n.startsWith("control_center_toggle_slider")) return 8;
        if (n.startsWith("control_center_detail_max_height")) return 9;
        if (n.startsWith("control_center_panel_width") || n.startsWith("control_center_horizontal_margin")
                || n.startsWith("control_center_force_vertical") || n.startsWith("control_center_align_end")) return 5;
        if (n.startsWith("qs_media_")) return G_MEDIA;
        if (n.startsWith("qs_page_indicator_") || n.startsWith("qs_control_tiles_indicator_")) return G_PAGE;
        if (n.startsWith("qs_footer") || n.startsWith("qs_control_footer") || n.startsWith("qs_security_footer")
                || n.startsWith("qs_control_foot_panel") || n.startsWith("qs_control_bottom_")
                || n.equals("control_center_bottom_area_height")) return G_FOOT;
        if (n.startsWith("qs_control_expand_") || n.startsWith("qs_control_content_view")) return G_EXPAND;
        if (n.startsWith("qs_customize") || n.startsWith("qs_control_customizer_")
                || n.startsWith("qs_customer_added")) return G_EDIT;
        if (n.contains("corner_radius") || n.endsWith("_radius")) return 6;
        if (n.startsWith("qs_control_detail_") || n.startsWith("qs_detail_") || n.contains("_detail_height")
                || n.startsWith("qs_control_mi_play_detail")) return 9;
        if (n.startsWith("qs_control_brightness_") || n.startsWith("qs_brightness_")) return 7;
        if (n.startsWith("qs_control_header_") || n.startsWith("qs_header_") || n.startsWith("notch_expanded_header")
                || n.startsWith("qs_time_")) return 8;
        if (n.startsWith("qs_control_big_tile") || n.startsWith("qs_control_smart")) return 2;
        if (n.startsWith("qs_control_center_tile") || n.startsWith("qs_control_tile_") || n.startsWith("qs_control_custom_tile")
                || n.startsWith("qs_quick_tile")) return 1;
        if (n.startsWith("qs_control_tiles_") || n.startsWith("qs_control_land_") || n.startsWith("qs_tile_")
                || n.startsWith("qs_quick_panel_") || n.startsWith("qs_dual_tile")) return 4;
        if (n.startsWith("qs_control_panel") || n.startsWith("qs_panel_") || n.startsWith("qs_tiles_page")
                || n.startsWith("qs_control_center_horizontal")) return 5;
        return G_NONE;
    }

    private static final HashMap<String, Integer> NAMES = new HashMap<>();
    private static void add(int g, String... names) { for (String n : names) NAMES.put(n, g); }
    static {
        add(1, "qs_control_center_tile_width", "qs_control_center_tile_height", "qs_control_tile_icon_bg_size",
                "qs_control_custom_tile_icon_inner_size", "qs_quick_tile_size", "qs_quick_tile_icon_bg_size",
                "qs_tile_height", "qs_tile_icon_bg_size", "qs_tile_icon_size");
        add(2, "qs_control_big_tile_width", "qs_control_big_tile_height", "qs_control_big_tile_icon_size",
                "qs_control_smart_tile_height", "qs_control_smart_tile_width");
        add(3, "qs_control_tile_label_text_size", "qs_control_big_tile_title_size", "qs_control_big_tile_sub_title_size",
                "qs_tile_label_text_size", "qs_tile_text_size", "qs_control_footer_text_size");
        add(4, "qs_control_center_tile_margin_start", "qs_control_center_tile_margin_top",
                "qs_control_tiles_container_margin_top", "qs_control_tiles_container_margin_bottom",
                "qs_control_big_tiles_interval_vertical", "qs_control_big_tiles_margin_bottom",
                "qs_control_big_tiles_padding_top", "qs_tile_margin_horizontal", "qs_tile_margin_vertical",
                "qs_control_tile_label_padding_top");
        add(5, "qs_control_panel_margin_horizontal", "qs_control_center_horizontal_margin_start",
                "qs_content_horizontal_padding", "qs_horizontal_margin", "qs_panel_padding", "qs_control_title_margin_end");
        add(6, "qs_control_corner_general_radius", "qs_control_big_tile_corner_radius", "qs_control_brightness_corner_radius",
                "qs_corner_radius", "qs_control_customizer_others_bg_radius", "qs_control_mi_play_detail_corner_radius");
        add(7, "qs_control_brightness_width", "qs_control_brightness_dialog_height", "qs_control_brightness_icon_size",
                "qs_control_brightness_margin_top", "qs_brightness_dialog_height");
        add(8, "qs_control_header_clock_size", "qs_control_header_date_size", "qs_control_header_button_size",
                "qs_control_header_tiles_height", "qs_header_row_min_height");
        add(9, "qs_control_detail_width", "qs_control_detail_header_height", "qs_control_detail_item_height",
                "qs_control_detail_wifi_bt_height", "qs_detail_item_height", "qs_detail_header_height");
        add(10, "qs_control_customizer_tile_width", "qs_control_customizer_tile_height");
        add(G_HEADER_TOP, "qs_control_center_header_paddingTop", "qs_header_top_padding");
    }

    private static final ConcurrentHashMap<Integer, Integer> GROUP = new ConcurrentHashMap<>();
    private static XSharedPreferences xsp;
    private static volatile int[] vals = new int[GROUPS];
    private static volatile int columns = 0;
    private static volatile long lastLoad = 0;

    private static void load() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastLoad < 1500) return;
        lastLoad = now;
        try {
            if (xsp == null) xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
            if (xsp.hasFileChanged()) xsp.reload();
            int[] v = new int[GROUPS];
            for (int g = 1; g < GROUPS; g++) if (g != G_HEADER_TOP) v[g] = xsp.getInt(KEYS[g], 100);
            v[G_HEADER_TOP] = xsp.getInt(K_HEADER_TOP, 0);
            vals = v;
            columns = xsp.getInt(K_COLUMNS, 0);
        } catch (Throwable ignored) { }
    }

    private static int group(Resources r, int id) {
        if (id == 0) return G_NONE;
        Integer g = GROUP.get(id);
        if (g != null) return g;
        int gr = G_NONE;
        try {
            String nm = r.getResourceEntryName(id);
            Integer x = NAMES.get(nm);
            gr = x != null ? x : prefixGroup(nm);
        } catch (Throwable ignored) { }
        GROUP.put(id, gr);
        return gr;
    }

    /** New px value for a dimen, or Float.NaN when it stays unchanged. */
    private static float adjust(Resources r, int id, float original) {
        int g = group(r, id);
        if (g == G_NONE) return Float.NaN;
        load();
        int v = vals[g];
        if (g == G_HEADER_TOP) {
            if (v <= 0) return Float.NaN;
            return original + v * r.getDisplayMetrics().density;
        }
        if (v == 100) return Float.NaN;
        return original * v / 100f;
    }

    static void hook() {
        try {
            XposedHelpers.findAndHookMethod(Resources.class, "getDimensionPixelSize", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        float n = adjust((Resources) p.thisObject, (Integer) p.args[0], (Integer) p.getResult());
                        if (!Float.isNaN(n)) p.setResult(Math.max(0, Math.round(n)));
                    } catch (Throwable ignored) { }
                }
            });
            XposedHelpers.findAndHookMethod(Resources.class, "getDimensionPixelOffset", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        float n = adjust((Resources) p.thisObject, (Integer) p.args[0], (Integer) p.getResult());
                        if (!Float.isNaN(n)) p.setResult(Math.max(0, (int) n));
                    } catch (Throwable ignored) { }
                }
            });
            XposedHelpers.findAndHookMethod(Resources.class, "getDimension", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        float n = adjust((Resources) p.thisObject, (Integer) p.args[0], (Float) p.getResult());
                        if (!Float.isNaN(n)) p.setResult(Math.max(0f, n));
                    } catch (Throwable ignored) { }
                }
            });
            XposedHelpers.findAndHookMethod(Resources.class, "getInteger", int.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        Resources r = (Resources) p.thisObject;
                        int id = (Integer) p.args[0];
                        if (id == 0) return;
                        Integer g = GROUP.get(id);
                        if (g == null) {
                            String n = null;
                            try { n = r.getResourceEntryName(id); } catch (Throwable ignored) { }
                            g = "qs_control_tiles_columns".equals(n) ? -1 : 0;
                            GROUP.put(id, g);
                        }
                        if (g == -1) {
                            load();
                            if (columns >= 2) p.setResult(columns);
                        }
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: control center size hook failed: " + t);
        }
    }
}

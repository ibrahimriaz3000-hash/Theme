package com.dynamicpill.module;

import android.content.ContentUris;
import android.content.Context;
import android.content.res.XModuleResources;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Status bar logo (merged from the SB Logo Hook module, logic taken from Iconify v8.0.0 StatusbarLogo).
 *
 *  - hook  PhoneStatusBarView.onFinishInflate -> add one ImageView
 *  - LEFT  : parent id/status_bar_start_side_except_heads_up (fallback id/status_bar_left_side), child index 1 (after the clock)
 *  - RIGHT : parent id/status_bar_end_side_content, appended at the end
 *  - tint  : follows Clock.onDarkChanged
 *
 * Settings live in the same prefs file as the pill (pill_prefs), keys below. Applied when System UI starts
 * (settings screen has an "Apply now" row that restarts System UI). Everything is wrapped in try / catch:
 * a failure here can never break the pill.
 */
final class StatusLogo {
    private StatusLogo() { }

    // ---- prefs (same file as the pill)
    static final String K_ON = "logo_enabled";           // boolean, default true
    static final String K_POS = "logo_position";         // int: 0 = left, 1 = right
    static final String K_STYLE = "logo_style";          // String: style name or "custom"
    static final String K_SIZE = "logo_size";            // int dp
    static final String K_TINT = "logo_tint";            // boolean, follow status bar icon colour
    static final String K_MS = "logo_margin_start";      // int dp, -1 = system dimen
    static final String K_ME = "logo_margin_end";        // int dp, -1 = system dimen

    static final int POS_LEFT = 0, POS_RIGHT = 1;
    static final String CUSTOM = "custom";
    static final String DEFAULT_STYLE = "android";
    static final int DEFAULT_SIZE = 14;

    /** drawable name = "ic_statusbar_logo_" + style */
    static final String[] STYLES = {
            "adidas", "alien", "amogus", "android", "apple", "avengers", "batman", "batman_tdk", "beats",
            "biohazard", "blackberry", "cannabis", "captain_america", "emoticon_cool", "emoticon_devil",
            "fire", "flash", "ghost", "heart", "ironman", "mint", "nike", "ninja", "pac_man", "puma",
            "robot", "rog", "spiderman", "superman", "tux", "ubuntu", "windows", "xbox"
    };

    private static final String TAG = "DynamicPill-Logo: ";
    private static final String SYSTEMUI = "com.android.systemui";
    private static final String VIEW_TAG = "sblogo_view";   // same tag as the old SB Logo Hook: never two logos

    // parent container ids, first match wins (AOSP first, then MIUI / HyperOS guesses)
    private static final String[] LEFT_IDS = {
            "status_bar_start_side_except_heads_up", "status_bar_left_side",
            "phone_status_bar_left_container", "status_bar_left_container"
    };
    private static final String[] RIGHT_IDS = {
            "status_bar_end_side_content", "status_bar_end_side_container", "phone_status_bar_right_container"
    };

    private static volatile XModuleResources modRes;
    private static final List<WeakReference<LogoView>> LOGOS = new ArrayList<>();
    private static final Set<Member> HOOKED = Collections.synchronizedSet(new HashSet<Member>());
    private static volatile int sTint = Color.WHITE;

    // ------------------------------------------------------------------ entry (called from MainHook)

    static void initZygote(String modulePath) {
        try {
            modRes = XModuleResources.createInstance(modulePath, null);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "initZygote: " + t);
        }
    }

    static void hook(ClassLoader cl) {
        try {
            hookInflate(cl);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookInflate failed: " + t);
        }
        try {
            hookClockTint(cl);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookClockTint failed: " + t);
        }
    }

    // ------------------------------------------------------------------ hooks

    private static void hookInflate(ClassLoader cl) {
        String[] names = {
                "com.android.systemui.statusbar.phone.MiuiPhoneStatusBarView",
                "com.android.systemui.statusbar.phone.PhoneStatusBarView"
        };
        int count = 0;
        for (String n : names) {
            Class<?> c = XposedHelpers.findClassIfExists(n, cl);
            if (c == null) continue;
            for (Method m : methodsNamed(c, "onFinishInflate")) {
                if (!HOOKED.add(m)) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            inject((ViewGroup) param.thisObject);
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + "inject failed: " + t);
                        }
                    }
                });
                count++;
            }
        }
        XposedBridge.log(TAG + "onFinishInflate hooks: " + count);
    }

    private static void hookClockTint(ClassLoader cl) {
        String[] names = {
                "com.android.systemui.statusbar.policy.Clock",
                "com.android.systemui.statusbar.views.MiuiClock",
                "com.android.systemui.statusbar.policy.MiuiClock"
        };
        for (String n : names) {
            Class<?> c = XposedHelpers.findClassIfExists(n, cl);
            if (c == null) continue;
            for (Method m : methodsNamed(c, "onDarkChanged")) {
                if (!HOOKED.add(m)) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            if (param.thisObject instanceof TextView) {
                                updateTint(((TextView) param.thisObject).getCurrentTextColor());
                            }
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + "tint failed: " + t);
                        }
                    }
                });
            }
        }
    }

    /** Declared methods called {@code name}: the nearest class in the hierarchy that declares it. */
    private static List<Method> methodsNamed(Class<?> c, String name) {
        List<Method> out = new ArrayList<>();
        for (Class<?> k = c; k != null && k != Object.class; k = k.getSuperclass()) {
            for (Method m : k.getDeclaredMethods()) {
                if (m.getName().equals(name)) {
                    m.setAccessible(true);
                    out.add(m);
                }
            }
            if (!out.isEmpty()) break;
        }
        return out;
    }

    // ------------------------------------------------------------------ inject

    private static final class Config {
        boolean enabled = true;
        int position = POS_LEFT;
        String style = DEFAULT_STYLE;
        int size = DEFAULT_SIZE;
        boolean tint = true;
        int marginStart = -1;
        int marginEnd = -1;

        static Config load() {
            Config cfg = new Config();
            try {
                XSharedPreferences p = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                p.makeWorldReadable();
                p.reload();
                cfg.enabled = p.getBoolean(K_ON, true);
                cfg.position = p.getInt(K_POS, POS_LEFT);
                cfg.style = p.getString(K_STYLE, DEFAULT_STYLE);
                cfg.size = p.getInt(K_SIZE, DEFAULT_SIZE);
                cfg.tint = p.getBoolean(K_TINT, true);
                cfg.marginStart = p.getInt(K_MS, -1);
                cfg.marginEnd = p.getInt(K_ME, -1);
            } catch (Throwable t) {
                XposedBridge.log(TAG + "prefs load failed, defaults used: " + t);
            }
            if (cfg.style == null) cfg.style = DEFAULT_STYLE;
            if (cfg.size < 8) cfg.size = 8;
            if (cfg.size > 64) cfg.size = 64;
            return cfg;
        }
    }

    private static void inject(ViewGroup root) {
        Config cfg = Config.load();
        if (!cfg.enabled) return;
        if (root.findViewWithTag(VIEW_TAG) != null) return;   // already added

        Context ctx = root.getContext();
        boolean left = cfg.position != POS_RIGHT;

        ViewGroup parent = findGroup(root, ctx, left ? LEFT_IDS : RIGHT_IDS);
        int index;
        if (parent != null) {
            index = left ? Math.min(1, parent.getChildCount()) : parent.getChildCount();
        } else {
            // last resort
            parent = findGroup(root, ctx, new String[]{"status_bar_contents"});
            index = (parent == null || left) ? 0 : parent.getChildCount();
            XposedBridge.log(TAG + "container id not found, fallback status_bar_contents=" + (parent != null));
            dumpChildren(root);
        }
        if (parent == null) {
            XposedBridge.log(TAG + "no parent found at all, logo not added");
            return;
        }

        Drawable d = loadDrawable(ctx, cfg);
        if (d == null) {
            XposedBridge.log(TAG + "drawable not found for style=" + cfg.style);
            return;
        }

        int px = dp(ctx, cfg.size);
        int ms = cfg.marginStart >= 0 ? dp(ctx, cfg.marginStart)
                : dimen(ctx, left ? "status_bar_left_clock_starting_padding" : "status_bar_clock_starting_padding", 4);
        int me = cfg.marginEnd >= 0 ? dp(ctx, cfg.marginEnd)
                : dimen(ctx, left ? "status_bar_left_clock_end_padding" : "status_bar_clock_end_padding", 4);

        ViewGroup.MarginLayoutParams lp;
        if (parent instanceof LinearLayout) {
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(px, px);
            l.gravity = Gravity.END | Gravity.CENTER_VERTICAL;   // 8388629
            lp = l;
        } else {
            lp = new ViewGroup.MarginLayoutParams(px, px);
        }
        lp.setMarginStart(ms);
        lp.setMarginEnd(me);

        LogoView iv = new LogoView(ctx);
        iv.setTag(VIEW_TAG);
        iv.setLayoutParams(lp);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.tintEnabled = cfg.tint;
        iv.tintColor = sTint;
        iv.setImageDrawable(d);
        iv.refreshTint();

        parent.addView(iv, Math.max(0, Math.min(index, parent.getChildCount())));
        synchronized (LOGOS) {
            LOGOS.add(new WeakReference<>(iv));
        }
        XposedBridge.log(TAG + "logo added: pos=" + (left ? "left" : "right")
                + " style=" + cfg.style + " size=" + cfg.size + "dp index=" + index);
    }

    private static ViewGroup findGroup(View root, Context ctx, String[] ids) {
        for (String name : ids) {
            try {
                int id = ctx.getResources().getIdentifier(name, "id", ctx.getPackageName());
                if (id == 0) continue;
                View v = root.findViewById(id);
                if (v instanceof ViewGroup) {
                    XposedBridge.log(TAG + "container matched: " + name);
                    return (ViewGroup) v;
                }
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    /** Debug helper: logs children (3 levels) so the right container ids can be found on a new ROM. */
    private static void dumpChildren(ViewGroup root) {
        try {
            StringBuilder sb = new StringBuilder(TAG + "view tree: ");
            dump(root, sb, 0);
            XposedBridge.log(sb.toString());
        } catch (Throwable ignored) {
        }
    }

    private static void dump(View v, StringBuilder sb, int depth) {
        String n = v.getClass().getSimpleName();
        try {
            if (v.getId() != View.NO_ID) n += "#" + v.getResources().getResourceEntryName(v.getId());
        } catch (Throwable ignored) {
        }
        sb.append(n);
        if (v instanceof ViewGroup && depth < 3) {
            ViewGroup g = (ViewGroup) v;
            sb.append('[');
            for (int i = 0; i < g.getChildCount(); i++) {
                if (i > 0) sb.append(", ");
                dump(g.getChildAt(i), sb, depth + 1);
            }
            sb.append(']');
        }
    }

    // ------------------------------------------------------------------ drawables

    private static Drawable loadDrawable(Context ctx, Config cfg) {
        try {
            if (CUSTOM.equals(cfg.style)) {
                Drawable d = loadCustom(ctx);
                return d != null ? d : ring(ctx, cfg.size);
            }
            XModuleResources r = modRes;
            if (r == null) return null;
            int id = r.getIdentifier("ic_statusbar_logo_" + cfg.style, "drawable", PillController.MODULE_PKG);
            if (id == 0) {   // unknown / old style name: fall back to the default logo
                id = r.getIdentifier("ic_statusbar_logo_" + DEFAULT_STYLE, "drawable", PillController.MODULE_PKG);
            }
            if (id == 0) return null;
            Drawable d = r.getDrawable(id, null);
            return d == null ? null : d.mutate();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "loadDrawable: " + t);
            return null;
        }
    }

    /** Same as Iconify: image from MediaStore Downloads: Download/SBLogo/statusbar_logo.png */
    private static Drawable loadCustom(Context ctx) {
        try {
            Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            String sel = MediaStore.MediaColumns.DISPLAY_NAME + " = ? AND "
                    + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
            String[] args = {"statusbar_logo.png", "Download/SBLogo%"};
            try (Cursor c = ctx.getContentResolver().query(collection,
                    new String[]{MediaStore.MediaColumns._ID}, sel, args, null)) {
                if (c != null && c.moveToFirst()) {
                    Uri uri = ContentUris.withAppendedId(collection, c.getLong(0));
                    return ImageDecoder.decodeDrawable(ImageDecoder.createSource(ctx.getContentResolver(), uri));
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "custom logo failed: " + t);
        }
        return null;
    }

    /** Placeholder when the custom file is missing: oval ring, 2dp stroke. */
    private static Drawable ring(Context ctx, int sizeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setStroke(dp(ctx, 2), 0xFF444444);
        g.setColor(Color.TRANSPARENT);
        g.setSize(dp(ctx, sizeDp), dp(ctx, sizeDp));
        return g;
    }

    // ------------------------------------------------------------------ tint

    private static void updateTint(int color) {
        sTint = color;
        synchronized (LOGOS) {
            for (int i = LOGOS.size() - 1; i >= 0; i--) {
                LogoView v = LOGOS.get(i).get();
                if (v == null) {
                    LOGOS.remove(i);
                } else {
                    v.tintColor = color;
                    v.refreshTint();
                }
            }
        }
    }

    /** ImageView that remembers its tint. */
    static final class LogoView extends ImageView {
        boolean tintEnabled = true;
        int tintColor = Color.WHITE;

        LogoView(Context c) {
            super(c);
        }

        void refreshTint() {
            Drawable d = getDrawable();
            if (d == null) return;
            if (tintEnabled) d.setTint(tintColor);
            else d.setTintList(null);
            invalidate();
        }
    }

    // ------------------------------------------------------------------ utils

    private static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    private static int dimen(Context c, String name, int fallbackDp) {
        try {
            int id = c.getResources().getIdentifier(name, "dimen", c.getPackageName());
            if (id != 0) return c.getResources().getDimensionPixelSize(id);
        } catch (Throwable ignored) {
        }
        return dp(c, fallbackDp);
    }
}

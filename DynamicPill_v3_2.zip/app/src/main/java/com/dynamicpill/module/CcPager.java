package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

/**
 * Two page Control Center (like the example video).
 *   Page 1: Mobile data / Wi-Fi, media, sliders and the first two rows of icons.
 *   Page 2: the remaining icon rows + "Edit".   Swipe left = page 2, swipe right = page 1.
 * The header (pill, "UNTIL" line, date, status icons) never moves.
 *
 * Nothing about the HyperOS classes is assumed: the icon rows are found by their shape (round, same size),
 * the page split is "above / below the 3rd icon row", and the biggest views that lie fully on one page are slid.
 * Everything is wrapped in try / catch and undone (restore) if anything looks wrong.
 */
final class CcPager {
    private CcPager() { }

    static final String K_PAGER = "cc_pager";

    private static final class Unit {
        final View v; final boolean p2; final float ox, oy, oa;
        Unit(View v, boolean p2) { this.v = v; this.p2 = p2; ox = v.getTranslationX(); oy = v.getTranslationY(); oa = v.getAlpha(); }
    }

    private static WeakReference<ViewGroup> hostRef = new WeakReference<>(null);
    private static final ArrayList<Unit> units = new ArrayList<>();
    private static boolean ready = false;
    private static int page = 0;               // 0 or 1
    private static float prog = 0f;            // 0 = page 1, 1 = page 2
    private static float width = 1080f, shiftY = 0f;
    private static ValueAnimator anim;

    // settle detection
    private static int lastBy = Integer.MIN_VALUE, capBy = 0;
    private static long steadySince = 0;
    private static final int[] loc = new int[2];

    // gesture
    private static float startX, startY, baseP;
    private static boolean dragging = false;
    private static VelocityTracker vt;

    // ------------------------------------------------------------------ driven every 40 ms by the header view

    static void tick(ViewGroup host, View battery, View anchor, float a) {
        try {
            if (!CcBattery.flag(K_PAGER, true)) { if (ready) restore(); return; }
            if (ready && hostRef.get() != host) return;       // another header view reporting: ignore
            long now = android.os.SystemClock.uptimeMillis();
            int by = Integer.MIN_VALUE;
            if (a > 0f) { battery.getLocationOnScreen(loc); by = loc[1]; }
            boolean steady = a >= 0.97f && Math.abs(by - lastBy) <= 1;
            lastBy = by;
            if (!steady) steadySince = now;
            if (!ready) {
                if (steady && now - steadySince >= 250) capture(host, battery, anchor);
            } else if (a < 0.9f || Math.abs(by - capBy) > 3) {
                restore();
            }
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: pager tick failed: " + t);
            try { restore(); } catch (Throwable ignored) { }
        }
    }

    // ------------------------------------------------------------------ finding the pages

    private static void capture(ViewGroup host, View battery, View anchor) {
        float dp = host.getResources().getDisplayMetrics().density;
        width = host.getResources().getDisplayMetrics().widthPixels;
        int hb = 0;
        battery.getLocationOnScreen(loc);
        hb = Math.max(hb, loc[1] + battery.getHeight());
        if (anchor != null && anchor.isShown()) {
            anchor.getLocationOnScreen(loc);
            hb = Math.max(hb, loc[1] + anchor.getHeight());
        }
        hb += Math.round(dp * 2f);

        // 1) icon rows: round-ish, same size, 10..24 % of the screen width
        ArrayList<Integer> tops = new ArrayList<>();
        findTiles(host, hb, tops, new int[]{0});
        java.util.Collections.sort(tops);
        ArrayList<Integer> rows = new ArrayList<>();
        for (int t : tops) {
            if (rows.isEmpty() || t - rows.get(rows.size() - 1) > Math.round(dp * 8f)) rows.add(t);
        }
        if (rows.size() < 3) return;                       // nothing to split: leave the Control Center alone
        int split = rows.get(2);                           // page 2 starts at the 3rd icon row

        // 2) units: biggest views that lie completely on one page
        ArrayList<Unit> list = new ArrayList<>();
        collect(host, hb, split, list, new int[]{0});
        int minTop1 = Integer.MAX_VALUE, p2count = 0;
        for (Unit u : list) {
            u.v.getLocationOnScreen(loc);
            if (!u.p2) minTop1 = Math.min(minTop1, loc[1]); else p2count++;
        }
        if (p2count == 0 || minTop1 == Integer.MAX_VALUE) return;
        units.clear();
        units.addAll(list);
        shiftY = -(split - minTop1);
        hostRef = new WeakReference<>(host);
        battery.getLocationOnScreen(loc);
        capBy = loc[1];
        page = 0; prog = 0f; dragging = false;
        ready = true;
        apply(0f);
        XposedBridge.log("DynamicPill: pager ready, units=" + units.size() + " split=" + split + " rows=" + rows.size());
    }

    private static void findTiles(View v, int hb, ArrayList<Integer> tops, int[] n) {
        if (n[0]++ > 2500 || v.getVisibility() != View.VISIBLE) return;
        int w = v.getWidth(), h = v.getHeight();
        if (w > 0 && h > 0) {
            v.getLocationOnScreen(loc);
            float sw = v.getResources().getDisplayMetrics().widthPixels;
            if (loc[1] >= hb && w >= sw * 0.10f && w <= sw * 0.24f
                    && Math.abs(w - h) <= Math.max(w, h) * 0.12f) {
                tops.add(loc[1]);
                return;                                    // do not look inside a tile
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) findTiles(g.getChildAt(i), hb, tops, n);
        }
    }

    private static void collect(View v, int hb, int split, ArrayList<Unit> out, int[] n) {
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (n[0]++ > 2500 || c.getVisibility() != View.VISIBLE || c.getWidth() <= 0 || c.getHeight() <= 0) continue;
            c.getLocationOnScreen(loc);
            int top = loc[1], bottom = top + c.getHeight();
            if (bottom <= hb) continue;                                    // header
            boolean overHeader = top < hb;
            boolean overSplit = top < split - 4 && bottom > split + 4;
            if (overHeader || overSplit) {
                if (c instanceof ViewGroup) collect(c, hb, split, out, n); // container: look inside
                continue;                                                  // big background leaf: leave alone
            }
            out.add(new Unit(c, top >= split - 4));
        }
    }

    // ------------------------------------------------------------------ moving the pages

    private static float smooth(float e0, float e1, float x) {
        float t = Math.max(0f, Math.min(1f, (x - e0) / (e1 - e0)));
        return t * t * (3f - 2f * t);
    }

    private static void apply(float p) {
        prog = p;
        float a1 = 1f - smooth(0f, 0.7f, p), a2 = smooth(0.3f, 1f, p);
        for (Unit u : units) {
            try {
                if (u.p2) {
                    u.v.setTranslationX(u.ox + (1f - p) * width);
                    u.v.setTranslationY(u.oy + p * shiftY);
                    u.v.setAlpha(u.oa * a2);
                } else {
                    u.v.setTranslationX(u.ox - p * width);
                    u.v.setAlpha(u.oa * a1);
                }
            } catch (Throwable ignored) { }
        }
    }

    private static void restore() {
        if (anim != null) { anim.cancel(); anim = null; }
        for (Unit u : units) {
            try { u.v.setTranslationX(u.ox); u.v.setTranslationY(u.oy); u.v.setAlpha(u.oa); } catch (Throwable ignored) { }
        }
        units.clear();
        ready = false; page = 0; prog = 0f; dragging = false;
        if (vt != null) { vt.recycle(); vt = null; }
        hostRef = new WeakReference<>(null);
    }

    private static void animateTo(final int target) {
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(prog, target);
        anim.setDuration(300);
        anim.setInterpolator(new DecelerateInterpolator(1.6f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                if (ready) apply((Float) va.getAnimatedValue());
            }
        });
        anim.start();
        page = target;
    }

    // ------------------------------------------------------------------ touch (called from the ViewGroup.dispatchTouchEvent hook)

    static boolean isHost(Object o) { return ready && o != null && hostRef.get() == o; }

    static boolean onTouch(MotionEvent e, XC_MethodHook.MethodHookParam param) {
        try {
            ViewGroup host = hostRef.get();
            if (!ready || host == null) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = e.getRawX(); startY = e.getRawY(); dragging = false;
                    if (vt != null) vt.recycle();
                    vt = VelocityTracker.obtain(); vt.addMovement(e);
                    if (anim != null && anim.isRunning()) { anim.cancel(); }
                    return false;
                case MotionEvent.ACTION_MOVE: {
                    if (vt == null) return false;
                    vt.addMovement(e);
                    float dx = e.getRawX() - startX, dy = e.getRawY() - startY;
                    if (!dragging) {
                        int slop = ViewConfiguration.get(host.getContext()).getScaledTouchSlop();
                        boolean dirOk = (page == 0 && dx < 0) || (page == 1 && dx > 0);
                        if (dirOk && Math.abs(dx) > slop * 1.5f && Math.abs(dx) > Math.abs(dy) * 1.6f) {
                            dragging = true;
                            baseP = prog;
                            startX = e.getRawX();                       // measure from here, no jump
                            MotionEvent c = MotionEvent.obtain(e);
                            c.setAction(MotionEvent.ACTION_CANCEL);     // stop the tile / slider under the finger
                            try { XposedBridge.invokeOriginalMethod(param.method, host, new Object[]{c}); }
                            catch (Throwable ignored) { }
                            c.recycle();
                            if (host.getParent() != null) host.getParent().requestDisallowInterceptTouchEvent(true);
                        } else return false;
                    }
                    apply(Math.max(0f, Math.min(1f, baseP - (e.getRawX() - startX) / (width * 0.8f))));
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    boolean was = dragging;
                    if (was) {
                        vt.addMovement(e);
                        vt.computeCurrentVelocity(1000);
                        float vx = vt.getXVelocity();
                        int target = prog > 0.5f ? 1 : 0;
                        if (vx < -900f) target = 1; else if (vx > 900f) target = 0;
                        animateTo(target);
                    }
                    dragging = false;
                    if (vt != null) { vt.recycle(); vt = null; }
                    return was;
                }
                default:
                    return dragging;
            }
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: pager touch failed: " + t);
            try { restore(); } catch (Throwable ignored) { }
            return false;
        }
    }
}

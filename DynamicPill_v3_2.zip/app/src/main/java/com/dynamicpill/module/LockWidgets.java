package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.util.Calendar;
import java.util.Locale;

import de.robv.android.xposed.XposedBridge;

/**
 * Lock screen: iPhone style "hello" writing animation under the clock (liquid glass look) and, below it,
 * glass widgets for battery, weather and steps. One overlay window, shown only while the phone is locked.
 */
final class LockWidgets {
    static final String K_ON = "lw_on";
    static final String K_HELLO = "lw_hello";
    static final String K_WIDGETS = "lw_widgets";
    static final String K_BATT = "lw_batt";
    static final String K_WEATHER = "lw_weather";
    static final String K_STEPS = "lw_steps";
    static final String K_Y = "lw_y_mm10";      // vertical offset, 0.1 mm units (can be negative)

    private static final int STEP_GOAL = 6000;

    private final Context ctx;
    private final WindowManager wm;
    private final Handler handler;
    private LockView view;
    private boolean added = false;
    private boolean shown = false;
    private int lastY = Integer.MIN_VALUE;
    private int winW, winH;

    LockWidgets(Context ctx, WindowManager wm, Handler handler) {
        this.ctx = ctx;
        this.wm = wm;
        this.handler = handler;
    }

    // ------------------------------------------------------------------ window

    private WindowManager.LayoutParams params(int y, int type) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                winW, winH, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.x = 0;
        lp.y = y;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.setTitle("DynamicPillLock");
        return lp;
    }

    private int curType = 0;
    private int curTypeY = Integer.MIN_VALUE;

    private boolean ensureAdded(int y, int[] types) {
        int sw = ctx.getResources().getDisplayMetrics().widthPixels;
        int sh = wm.getCurrentWindowMetrics().getBounds().height();
        int ww = sw;
        int hh = Math.round(sw * 0.56f);
        if (added && (ww != winW || hh != winH || y != lastY)) {
            winW = ww; winH = hh; lastY = y;
            try { wm.updateViewLayout(view, params(y, curType)); } catch (Throwable ignored) { }
            return true;
        }
        if (added) return true;
        winW = ww; winH = hh; lastY = y;
        view = new LockView(ctx);
        for (int type : types) {
            try {
                wm.addView(view, params(y, type));
                curType = type;
                added = true;
                break;
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: lock widgets window type " + type + " failed: " + t);
                view = new LockView(ctx);
            }
        }
        return added;
    }

    /** Called from the controller's tick. yOff = extra vertical offset in px. */
    void update(boolean show, int yOff, boolean hello, boolean widgets, boolean batt, boolean weather,
                boolean steps, int[] types) {
        if (!show) {
            if (shown) hide();
            return;
        }
        int sh = wm.getCurrentWindowMetrics().getBounds().height();
        int y = Math.round(sh * 0.215f) + yOff;
        if (!ensureAdded(y, types)) return;
        view.setOptions(hello, widgets, batt, weather, steps);
        if (!shown) {
            shown = true;
            view.setVisibility(View.VISIBLE);
            view.replay();
            view.fadeTo(1f, 260, null);
            startData();
        }
    }

    void replay() {
        if (shown && view != null) view.replay();
    }

    private void hide() {
        shown = false;
        stopData();
        final LockView v = view;
        if (v == null) return;
        v.fadeTo(0f, 220, new Runnable() {
            @Override
            public void run() {
                if (!shown) v.setVisibility(View.GONE);
            }
        });
    }

    // ------------------------------------------------------------------ data

    private SensorManager sm;
    private boolean listening = false;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            if (!shown) return;
            readBattery();
            readWeather();
            handler.postDelayed(this, 60000);
        }
    };

    private final SensorEventListener stepListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent e) {
            try {
                if (e.values != null && e.values.length > 0) onSteps((long) e.values[0]);
            } catch (Throwable ignored) { }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) { }
    };

    private void startData() {
        readBattery();
        handler.removeCallbacks(refresh);
        handler.postDelayed(refresh, 1000);
        readWeather();
        try {
            SharedPreferences sp = ctx.getSharedPreferences("dp_steps", Context.MODE_PRIVATE);
            if (dayKey().equals(sp.getString("day", ""))) view.setSteps(sp.getLong("last", -1L));
            else view.setSteps(-1L);
        } catch (Throwable ignored) { }
        try {
            if (sm == null) sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
            Sensor s = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            if (s != null && !listening) {
                listening = sm.registerListener(stepListener, s, SensorManager.SENSOR_DELAY_NORMAL, handler);
            }
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: step sensor failed: " + t);
        }
    }

    private void stopData() {
        handler.removeCallbacks(refresh);
        try {
            if (sm != null && listening) sm.unregisterListener(stepListener);
        } catch (Throwable ignored) { }
        listening = false;
    }

    private static String dayKey() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) + "-" + c.get(Calendar.DAY_OF_YEAR);
    }

    /** The step counter is the total since boot: today's steps = total - the value at the start of the day. */
    private void onSteps(long total) {
        SharedPreferences sp = ctx.getSharedPreferences("dp_steps", Context.MODE_PRIVATE);
        String day = dayKey();
        long base = sp.getLong("base", -1L);
        if (!day.equals(sp.getString("day", "")) || base < 0 || total < base) {
            base = total;
            sp.edit().putString("day", day).putLong("base", base).apply();
        }
        long steps = Math.max(0L, total - base);
        sp.edit().putLong("last", steps).apply();
        if (view != null) view.setSteps(steps);
    }

    private void readBattery() {
        try {
            Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null || view == null) return;
            int lv = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
            int sc = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
            boolean plugged = i.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) != 0;
            if (lv >= 0 && sc > 0) view.setBattery(Math.round(lv * 100f / sc), plugged);
        } catch (Throwable ignored) { }
    }

    /** Weather comes from the system weather provider (MIUI / HyperOS weather app), read in the background. */
    private void readWeather() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String temp = null, cond = null;
                int type = -1;
                String[] uris = {"content://weather/actualWeatherData/1", "content://weather/weather"};
                for (String u : uris) {
                    android.database.Cursor cur = null;
                    try {
                        cur = ctx.getContentResolver().query(android.net.Uri.parse(u), null, null, null, null);
                        if (cur == null || !cur.moveToFirst()) continue;
                        for (int i = 0; i < cur.getColumnCount(); i++) {
                            String n = cur.getColumnName(i).toLowerCase(Locale.US);
                            String v;
                            try { v = cur.getString(i); } catch (Throwable t) { continue; }
                            if (v == null) continue;
                            if (temp == null && n.contains("temp") && !n.contains("high") && !n.contains("low")
                                    && !n.contains("highs") && !n.contains("lows") && v.matches(".*\\d.*")) {
                                temp = v.replaceAll("[^0-9\\-]", "");
                            } else if (cond == null && (n.equals("description") || n.equals("weather_desc")
                                    || n.equals("weather_name") || n.equals("condition"))) {
                                cond = v;
                            } else if (type < 0 && (n.equals("weather_type") || n.equals("weathertype"))) {
                                try { type = Integer.parseInt(v.trim()); } catch (Throwable ignored) { }
                            }
                        }
                        if (temp != null) break;
                    } catch (Throwable t) {
                        // provider missing or not readable: try the next one
                    } finally {
                        if (cur != null) cur.close();
                    }
                }
                final String ft = temp, fc = cond;
                final int kind = LockView.weatherKind(cond, type);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (view != null) view.setWeather(ft, fc, kind);
                    }
                });
            }
        }).start();
    }

    // ------------------------------------------------------------------ the view

    static final class LockView extends View {
        private static final String HELLO_PTS =
            "2.0,64.0,2.1,63.9,2.5,63.8,3.0,63.5,3.6,63.2,4.3,62.8,5.1,62.3,5.9,61.8,6.7,61.2,7.4,60.6,8.0,60.0,8.7,59.1," +
            "9.4,58.1,10.0,57.1,10.7,55.9,11.3,54.7,11.8,53.4,12.4,52.1,13.0,50.8,13.5,49.4,14.0,48.0,14.6,46.2,15.2,44.3," +
            "15.7,42.4,16.2,40.4,16.7,38.3,17.2,36.2,17.6,34.1,18.1,32.0,18.5,30.0,19.0,28.0,19.4,26.1,19.8,24.2,20.2,22.3," +
            "20.5,20.3,20.9,18.4,21.3,16.5,21.6,14.7,22.1,13.0,22.5,11.4,23.0,10.0,23.4,9.1,23.7,8.2,24.1,7.2,24.5,6.3," +
            "24.9,5.5,25.3,4.7,25.7,4.1,26.1,3.6,26.5,3.2,27.0,3.0,27.4,3.0,27.8,3.1,28.3,3.2,28.7,3.5,29.2,3.8,29.6,4.2," +
            "30.0,4.6,30.4,5.0,30.7,5.5,31.0,6.0,31.3,6.9,31.4,8.0,31.4,9.3,31.4,10.6,31.2,12.1,31.0,13.6,30.7,15.2,30.4," +
            "16.8,30.2,18.4,30.0,20.0,29.8,22.0,29.5,24.1,29.2,26.3,28.9,28.5,28.6,30.8,28.3,33.0,28.0,35.3,27.6,37.6,27.3," +
            "39.8,27.0,42.0,26.7,44.1,26.4,46.2,26.1,48.4,25.7,50.5,25.4,52.6,25.1,54.7,24.8,56.7,24.5,58.6,24.2,60.4,24.0," +
            "62.0,23.9,63.0,23.7,64.1,23.6,65.2,23.4,66.2,23.3,67.2,23.2,68.1,23.1,68.9,23.0,69.5,23.0,69.9,23.0,70.0,23.1," +
            "69.8,23.1,69.3,23.3,68.5,23.4,67.4,23.6,66.3,23.8,65.0,24.1,63.6,24.3,62.3,24.7,61.1,25.0,60.0,25.4,58.9,25.9," +
            "57.7,26.4,56.5,27.0,55.3,27.6,54.1,28.2,52.9,28.9,51.8,29.5,50.8,30.3,49.8,31.0,49.0,31.6,48.4,32.3,47.8,33.0," +
            "47.2,33.7,46.7,34.4,46.2,35.2,45.7,35.9,45.4,36.6,45.1,37.3,45.0,38.0,45.0,38.7,45.1,39.3,45.4,40.0,45.7,40.7," +
            "46.2,41.4,46.7,42.0,47.3,42.6,48.0,43.1,48.6,43.6,49.3,44.0,50.0,44.3,50.8,44.6,51.7,44.7,52.7,44.8,53.7,44.9," +
            "54.8,44.9,55.9,44.9,56.9,44.9,58.0,44.9,59.0,45.0,60.0,45.1,60.9,45.1,61.8,45.1,62.7,45.2,63.6,45.2,64.4,45.2," +
            "65.3,45.3,66.1,45.5,66.8,45.7,67.5,46.0,68.0,46.3,68.4,46.6,68.7,47.0,69.0,47.4,69.3,47.9,69.6,48.3,69.8,48.8," +
            "69.9,49.2,70.0,49.6,70.1,50.0,70.0,50.5,69.8,50.9,69.4,51.3,69.0,51.7,68.4,52.1,67.7,52.5,67.0,52.9,66.2,53.3," +
            "65.5,53.6,64.7,54.0,64.0,54.4,63.1,54.8,62.1,55.2,61.1,55.5,60.1,55.9,59.0,56.2,57.9,56.6,56.9,57.0,55.9,57.5," +
            "54.9,58.0,54.0,58.6,53.2,59.2,52.3,59.8,51.5,60.5,50.7,61.2,49.9,61.9,49.1,62.7,48.5,63.5,47.9,64.2,47.4,65.0," +
            "47.0,65.7,46.8,66.4,46.6,67.2,46.4,67.9,46.3,68.7,46.3,69.4,46.3,70.2,46.4,70.8,46.5,71.5,46.7,72.0,47.0,72.5," +
            "47.4,73.0,47.8,73.4,48.4,73.8,49.0,74.2,49.7,74.5,50.3,74.8,51.0,74.9,51.7,75.0,52.4,75.0,53.0,74.9,53.6,74.6," +
            "54.3,74.2,55.0,73.8,55.7,73.2,56.3,72.6,57.0,72.0,57.6,71.3,58.1,70.7,58.6,70.0,59.0,69.2,59.3,68.4,59.5,67.5," +
            "59.6,66.5,59.6,65.5,59.5,64.5,59.5,63.6,59.5,62.6,59.6,61.8,59.7,61.0,60.0,60.3,60.3,59.7,60.7,59.0,61.2,58.4," +
            "61.7,57.8,62.2,57.2,62.8,56.8,63.3,56.4,63.9,56.1,64.5,56.0,65.0,56.0,65.5,56.1,66.0,56.3,66.6,56.5,67.2,56.8," +
            "67.8,57.2,68.3,57.6,68.8,58.1,69.3,58.5,69.7,59.0,70.0,59.6,70.3,60.3,70.5,61.1,70.6,61.9,70.7,62.8,70.7,63.6," +
            "70.7,64.5,70.6,65.4,70.5,66.2,70.3,67.0,70.0,67.9,69.6,68.7,69.2,69.6,68.6,70.4,68.0,71.3,67.3,72.1,66.5,72.8," +
            "65.7,73.6,64.8,74.3,63.9,75.0,63.0,75.8,61.8,76.5,60.5,77.2,59.1,77.8,57.7,78.4,56.1,78.9,54.6,79.5,53.0,80.0," +
            "51.3,80.5,49.7,81.0,48.0,81.6,46.0,82.2,43.9,82.7,41.7,83.2,39.4,83.7,37.1,84.1,34.8,84.6,32.5,85.1,30.3,85.5," +
            "28.1,86.0,26.0,86.4,24.2,86.8,22.3,87.1,20.4,87.5,18.6,87.9,16.8,88.2,15.0,88.6,13.3,89.0,11.8,89.5,10.3,90.0," +
            "9.0,90.4,8.2,90.7,7.4,91.1,6.5,91.6,5.7,92.0,5.0,92.4,4.3,92.8,3.8,93.2,3.4,93.6,3.1,94.0,3.0,94.3,3.1,94.7," +
            "3.3,95.0,3.7,95.4,4.1,95.7,4.7,96.1,5.3,96.3,5.9,96.6,6.6,96.8,7.3,97.0,8.0,97.2,9.2,97.2,10.5,97.1,12.0,96.9," +
            "13.6,96.6,15.2,96.3,17.0,95.9,18.7,95.6,20.5,95.3,22.3,95.0,24.0,94.7,26.1,94.4,28.2,94.1,30.5,93.8,32.7,93.5," +
            "35.0,93.2,37.3,92.9,39.5,92.6,41.8,92.3,43.9,92.0,46.0,91.8,47.7,91.5,49.4,91.2,51.2,91.0,52.8,90.7,54.5,90.5," +
            "56.1,90.3,57.7,90.1,59.2,90.0,60.6,90.0,62.0,90.0,63.0,90.0,63.9,90.0,64.9,90.0,65.9,90.0,66.8,90.0,67.6,90.2," +
            "68.4,90.4,69.1,90.6,69.6,91.0,70.0,91.4,70.2,91.9,70.3,92.5,70.4,93.1,70.3,93.8,70.2,94.4,70.1,95.1,69.8,95.8," +
            "69.6,96.4,69.3,97.0,69.0,97.7,68.6,98.3,68.1,99.0,67.5,99.6,66.9,100.2,66.2,100.8,65.4,101.4,64.6,101.9,63.8," +
            "102.5,62.9,103.0,62.0,103.6,60.7,104.2,59.3,104.8,57.8,105.3,56.2,105.8,54.6,106.2,52.9,106.6,51.2,107.1,49.4," +
            "107.5,47.7,108.0,46.0,108.5,44.1,109.0,42.1,109.6,40.1,110.1,38.1,110.6,36.0,111.1,34.0,111.6,32.0,112.1,29.9," +
            "112.5,27.9,113.0,26.0,113.4,24.2,113.8,22.4,114.2,20.5,114.5,18.7,114.9,16.8,115.2,15.1,115.6,13.4,116.0,11.8," +
            "116.5,10.3,117.0,9.0,117.4,8.2,117.7,7.4,118.1,6.5,118.6,5.7,119.0,5.0,119.4,4.3,119.8,3.8,120.2,3.4,120.6," +
            "3.1,121.0,3.0,121.3,3.1,121.7,3.3,122.0,3.7,122.4,4.1,122.7,4.7,123.1,5.3,123.3,5.9,123.6,6.6,123.8,7.3,124.0," +
            "8.0,124.2,9.2,124.2,10.5,124.1,12.0,123.9,13.6,123.6,15.2,123.3,17.0,122.9,18.7,122.6,20.5,122.3,22.3,122.0," +
            "24.0,121.7,26.1,121.4,28.2,121.1,30.5,120.8,32.7,120.5,35.0,120.2,37.3,119.9,39.5,119.6,41.8,119.3,43.9,119.0," +
            "46.0,118.8,47.7,118.5,49.4,118.2,51.2,118.0,52.8,117.7,54.5,117.5,56.1,117.3,57.7,117.1,59.2,117.0,60.6,117.0," +
            "62.0,117.0,63.0,117.0,63.9,117.0,64.9,117.0,65.9,117.0,66.8,117.0,67.6,117.2,68.4,117.4,69.1,117.6,69.6,118.0," +
            "70.0,118.4,70.2,118.9,70.3,119.5,70.4,120.1,70.4,120.8,70.2,121.5,70.1,122.1,69.9,122.8,69.6,123.4,69.3,124.0," +
            "69.0,124.7,68.5,125.4,67.9,126.0,67.2,126.6,66.4,127.2,65.5,127.8,64.6,128.4,63.7,129.0,62.8,129.5,61.9,130.0," +
            "61.0,130.5,60.1,130.9,59.2,131.2,58.3,131.6,57.3,131.9,56.4,132.3,55.4,132.6,54.5,133.0,53.6,133.5,52.8,134.0," +
            "52.0,134.6,51.2,135.2,50.5,135.9,49.7,136.6,48.9,137.3,48.2,138.0,47.5,138.8,46.9,139.5,46.5,140.3,46.2,141.0," +
            "46.0,141.7,46.0,142.5,46.1,143.2,46.4,144.0,46.7,144.8,47.1,145.6,47.6,146.3,48.2,147.0,48.8,147.5,49.4,148.0," +
            "50.0,148.4,50.8,148.8,51.7,149.0,52.6,149.3,53.7,149.4,54.8,149.5,55.9,149.4,57.0,149.4,58.0,149.2,59.1,149.0," +
            "60.0,148.7,60.9,148.3,61.9,147.8,62.8,147.3,63.7,146.6,64.7,146.0,65.5,145.2,66.3,144.5,67.0,143.8,67.6,143.0," +
            "68.0,142.3,68.3,141.5,68.6,140.7,68.7,139.8,68.8,138.9,68.9,138.0,68.9,137.2,68.8,136.4,68.6,135.6,68.3,135.0," +
            "68.0,134.4,67.5,133.8,66.9,133.2,66.2,132.7,65.4,132.3,64.6,131.9,63.6,131.6,62.7,131.3,61.8,131.1,60.9,131.0," +
            "60.0,131.0,59.1,131.1,58.2,131.2,57.2,131.5,56.2,131.7,55.2,132.1,54.3,132.5,53.4,133.0,52.5,133.5,51.7,134.0," +
            "51.0,134.5,50.4,135.1,49.9,135.8,49.5,136.4,49.0,137.2,48.7,137.9,48.3,138.7,48.0,139.5,47.7,140.2,47.3,141.0," +
            "47.0,141.8,46.6,142.7,46.3,143.6,46.0,144.5,45.7,145.4,45.4,146.4,45.1,147.3,44.9,148.2,44.6,149.1,44.3,150.0," +
            "44.0,150.8,43.7,151.6,43.3,152.5,43.0,153.3,42.6,154.1,42.2,154.9,41.9,155.7,41.6,156.5,41.3,157.2,41.1,158.0," +
            "41.0,158.7,41.0,159.4,41.0,160.2,41.1,161.0,41.3,161.8,41.4,162.5,41.6,163.1,41.7,163.6,41.9,163.9,42.0,164.0," +
            "42.0";
        private static float[] pts;

        private static final float PW = 168f;      // width of the hello path in its own units
        private static final long T_WRITE = 1800, T_HOLD_END = 3400, T_ERASE_END = 4600;

        private boolean optHello = true, optWidgets = true, optBatt = true, optWeather = true, optSteps = true;
        private float fade = 0f;
        private ValueAnimator fadeAnim;
        private long t0 = 0;

        private int battPct = 50;
        private boolean battPlugged = false;
        private String temp = null, cond = null;
        private int wKind = 0;
        private long steps = -1L;

        // hello
        private final Path full = new Path();
        private final Path seg = new Path();
        private PathMeasure pm;
        private float pathLen = 0f;
        private int builtW = -1;
        private float helloK, helloX0, helloY0;
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tip = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] pos = new float[2];

        // glass cards
        private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final Path tmp = new Path();
        private final float dp;

        LockView(Context c) {
            super(c);
            dp = c.getResources().getDisplayMetrics().density;
            setVisibility(View.GONE);
            setWillNotDraw(false);
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeCap(Paint.Cap.ROUND);
            glow.setStrokeJoin(Paint.Join.ROUND);
            ink.setStyle(Paint.Style.STROKE);
            ink.setStrokeCap(Paint.Cap.ROUND);
            ink.setStrokeJoin(Paint.Join.ROUND);
            hi.setStyle(Paint.Style.STROKE);
            hi.setStrokeCap(Paint.Cap.ROUND);
            hi.setStrokeJoin(Paint.Join.ROUND);
            border.setStyle(Paint.Style.STROKE);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            text.setTextAlign(Paint.Align.CENTER);
        }

        // ---- state from the owner

        void setOptions(boolean hello, boolean widgets, boolean b, boolean w, boolean s) {
            optHello = hello; optWidgets = widgets; optBatt = b; optWeather = w; optSteps = s;
        }

        void setBattery(int pct, boolean plugged) { battPct = pct; battPlugged = plugged; invalidate(); }

        void setWeather(String t, String c, int kind) { temp = t; cond = c; wKind = kind < 0 ? 0 : kind; invalidate(); }

        void setSteps(long s) { steps = s; invalidate(); }

        static int weatherKind(String cond, int type) {
            if (cond != null) {
                String s = cond.toLowerCase(Locale.US);
                if (s.contains("snow")) return 4;
                if (s.contains("rain") || s.contains("shower") || s.contains("storm") || s.contains("drizzle")) return 3;
                if (s.contains("overcast") || s.contains("cloudy") && !s.contains("partly")) return 2;
                if (s.contains("partly") || s.contains("cloud")) return 1;
                if (s.contains("sun") || s.contains("clear") || s.contains("fair")) return 0;
            }
            switch (type) {      // typical MIUI weather type numbers
                case 0: return 0;
                case 1: return 1;
                case 2: return 2;
                case 3: case 4: case 5: case 6: case 7: case 8: case 9: return 3;
                case 13: case 14: case 15: case 16: case 17: return 4;
                default: return 0;
            }
        }

        void replay() {
            t0 = SystemClock.uptimeMillis();
            invalidate();
        }

        void fadeTo(final float to, long ms, final Runnable end) {
            if (fadeAnim != null) fadeAnim.cancel();
            fadeAnim = ValueAnimator.ofFloat(fade, to);
            fadeAnim.setDuration(ms);
            fadeAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    fade = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            if (end != null) {
                fadeAnim.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(android.animation.Animator a) {
                        if (fade == to) end.run();
                    }
                });
            }
            fadeAnim.start();
        }

        // ---- helpers

        private static int argb(float a, int rgb) {
            int al = Math.max(0, Math.min(255, Math.round(a)));
            return (al << 24) | (rgb & 0xFFFFFF);
        }

        private static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

        private static float easeIO(float p) {
            p = clamp01(p);
            return 0.5f - 0.5f * (float) Math.cos(Math.PI * p);
        }

        private static float easeOut(float p) {
            p = clamp01(p);
            return 1f - (1f - p) * (1f - p) * (1f - p);
        }

        // ---- drawing

        @Override
        protected void onDraw(Canvas c) {
            float f = fade;
            if (f <= 0.003f) return;
            float w = getWidth();
            if (w <= 0f) return;
            long now = SystemClock.uptimeMillis();
            boolean again = fadeAnim != null && fadeAnim.isRunning();
            if (optHello) again |= drawHello(c, w, f, now);
            if (optWidgets) again |= drawWidgets(c, w, f, now);
            if (again) postInvalidateOnAnimation();
        }

        private void buildHello(float w) {
            if (pts == null) {
                String[] p = HELLO_PTS.split(",");
                float[] a = new float[p.length];
                for (int i = 0; i < p.length; i++) a[i] = Float.parseFloat(p[i]);
                pts = a;
            }
            helloK = w * 0.42f / PW;
            helloX0 = (w - PW * helloK) / 2f;
            helloY0 = w * 0.015f;
            full.reset();
            for (int i = 0; i + 1 < pts.length; i += 2) {
                float x = helloX0 + pts[i] * helloK, y = helloY0 + pts[i + 1] * helloK;
                if (i == 0) full.moveTo(x, y);
                else full.lineTo(x, y);
            }
            pm = new PathMeasure(full, false);
            pathLen = pm.getLength();
            float core = Math.max(2.4f * dp, 2.9f * helloK);
            glow.setStrokeWidth(core * 3.2f);
            glow.setMaskFilter(new BlurMaskFilter(core * 1.8f, BlurMaskFilter.Blur.NORMAL));
            ink.setStrokeWidth(core * 1.5f);
            ink.setShader(new LinearGradient(helloX0, 0f, helloX0 + PW * helloK, 0f,
                    new int[]{0xFFFFB04D, 0xFFFF5E98, 0xFF69C3AE, 0xFF3F83E8},
                    new float[]{0f, 0.25f, 0.58f, 1f}, Shader.TileMode.CLAMP));
            hi.setStrokeWidth(core * 0.42f);
            tip.setMaskFilter(new BlurMaskFilter(core * 1.2f, BlurMaskFilter.Blur.NORMAL));
            builtW = Math.round(w);
        }

        /** Writes "hello" stroke by stroke, holds it, then erases it from the left. Returns true while running. */
        private boolean drawHello(Canvas c, float w, float f, long now) {
            long t = now - t0;
            if (t < 0 || t > T_ERASE_END) return false;
            if (builtW != Math.round(w)) buildHello(w);
            float writeP = easeIO(t / (float) T_WRITE);
            float eraseP = t > T_HOLD_END ? easeIO((t - T_HOLD_END) / (float) (T_ERASE_END - T_HOLD_END)) : 0f;
            float s = eraseP * pathLen, e = writeP * pathLen;
            if (e - s < 0.5f) return true;
            seg.reset();
            pm.getSegment(s, e, seg, true);
            float core = Math.max(2.4f * dp, 2.9f * helloK);

            glow.setColor(argb(70f * f, 0xFFFFFF));
            c.drawPath(seg, glow);                                  // frosted halo around the stroke
            ink.setAlpha(Math.round(245f * f));
            c.drawPath(seg, ink);                                   // colour core
            hi.setColor(argb(190f * f, 0xFFFFFF));
            c.save();
            c.translate(-core * 0.28f, -core * 0.34f);
            c.drawPath(seg, hi);                                    // glassy specular line
            c.restore();

            if (eraseP == 0f && writeP < 0.999f) {                  // glowing pen tip
                pm.getPosTan(e, pos, null);
                tip.setColor(argb(230f * f, 0xFFFFFF));
                c.drawCircle(pos[0], pos[1], core * 1.1f, tip);
            }
            return true;
        }

        private void drawGlass(Canvas c, float x, float y, float s, float a) {
            float r = s * 0.24f;
            rect.set(x, y, x + s, y + s);
            shadow.setColor(argb(70f * a, 0x000000));
            shadow.setMaskFilter(new BlurMaskFilter(s * 0.10f, BlurMaskFilter.Blur.NORMAL));
            c.drawRoundRect(x, y + s * 0.05f, x + s, y + s * 1.05f, r, r, shadow);

            body.setShader(new LinearGradient(x, y, x, y + s,
                    new int[]{argb(88f * a, 0xFFFFFF), argb(34f * a, 0xFFFFFF)}, null, Shader.TileMode.CLAMP));
            c.drawRoundRect(rect, r, r, body);

            c.save();
            tmp.reset();
            tmp.addRoundRect(rect, r, r, Path.Direction.CW);
            c.clipPath(tmp);
            sheen.setShader(new LinearGradient(x, y, x + s * 0.55f, y + s * 0.75f,
                    new int[]{argb(95f * a, 0xFFFFFF), argb(0f, 0xFFFFFF)}, null, Shader.TileMode.CLAMP));
            c.drawRect(x, y, x + s, y + s * 0.75f, sheen);          // light refracting across the glass
            c.restore();

            border.setStrokeWidth(1.4f * dp);
            border.setShader(new LinearGradient(x, y, x + s, y + s,
                    new int[]{argb(230f * a, 0xFFFFFF), argb(40f * a, 0xFFFFFF), argb(150f * a, 0xFFFFFF)},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawRoundRect(x + 0.7f * dp, y + 0.7f * dp, x + s - 0.7f * dp, y + s - 0.7f * dp, r, r, border);
        }

        private boolean drawWidgets(Canvas c, float w, float f, long now) {
            int n = (optBatt ? 1 : 0) + (optWeather ? 1 : 0) + (optSteps ? 1 : 0);
            if (n == 0) return false;
            float s = w * 0.80f / 3f;
            float gap = w * 0.03f;
            float total = n * s + (n - 1) * gap;
            float x = (w - total) / 2f;
            float top = w * 0.20f + w * 0.035f;
            long t = now - t0;
            boolean again = false;
            int idx = 0;
            for (int k = 0; k < 3; k++) {
                boolean on = k == 0 ? optBatt : (k == 1 ? optWeather : optSteps);
                if (!on) continue;
                float p = easeOut((t - 250 - idx * 130) / 520f);
                if (p < 1f) again = true;
                float a = f * p;
                if (a > 0.003f) {
                    float y = top + (1f - p) * 14f * dp;
                    drawGlass(c, x, y, s, a);
                    if (k == 0) drawBattery(c, x, y, s, a);
                    else if (k == 1) drawWeather(c, x, y, s, a);
                    else drawSteps(c, x, y, s, a);
                }
                x += s + gap;
                idx++;
            }
            return again;
        }

        private void label(Canvas c, String value, String lab, float x, float y, float s, float a) {
            text.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            text.setColor(argb(255f * a, 0xFFFFFF));
            text.setTextSize(s * 0.20f);
            float maxW = s * 0.86f;
            while (text.measureText(value) > maxW && text.getTextSize() > s * 0.10f) text.setTextSize(text.getTextSize() - 1f);
            c.drawText(value, x + s / 2f, y + s * 0.80f, text);
            text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            text.setColor(argb(205f * a, 0xFFFFFF));
            text.setTextSize(s * 0.105f);
            String l = lab;
            while (text.measureText(l) > maxW && l.length() > 3) l = l.substring(0, l.length() - 2) + "\u2026";
            c.drawText(l, x + s / 2f, y + s * 0.93f, text);
        }

        private void ring(Canvas c, float cx, float cy, float r, float sw, float prog, int color, float a) {
            rect.set(cx - r, cy - r, cx + r, cy + r);
            stroke.setStrokeWidth(sw);
            stroke.setColor(argb(70f * a, 0xFFFFFF));
            c.drawArc(rect, 0f, 360f, false, stroke);
            stroke.setColor(argb(255f * a, color));
            if (prog > 0.004f) c.drawArc(rect, -90f, 360f * clamp01(prog), false, stroke);
        }

        private void drawBattery(Canvas c, float x, float y, float s, float a) {
            float cx = x + s / 2f, cy = y + s * 0.40f;
            int col = battPct <= 10 && !battPlugged ? 0xFFFF3B30 : (battPct <= 20 && !battPlugged ? 0xFFFFCC00 : 0xFF34C759);
            ring(c, cx, cy, s * 0.25f, s * 0.075f, battPct / 100f, col, a);
            if (battPlugged) {                                       // bolt
                fill.setColor(argb(255f * a, 0xFFFFFF));
                tmp.reset();
                tmp.moveTo(cx + 0.03f * s, cy - 0.15f * s);
                tmp.lineTo(cx - 0.07f * s, cy + 0.02f * s);
                tmp.lineTo(cx - 0.005f * s, cy + 0.02f * s);
                tmp.lineTo(cx - 0.03f * s, cy + 0.15f * s);
                tmp.lineTo(cx + 0.07f * s, cy - 0.03f * s);
                tmp.lineTo(cx + 0.005f * s, cy - 0.03f * s);
                tmp.close();
                c.drawPath(tmp, fill);
            } else {                                                 // phone glyph
                stroke.setStrokeWidth(s * 0.028f);
                stroke.setColor(argb(235f * a, 0xFFFFFF));
                rect.set(cx - 0.065f * s, cy - 0.12f * s, cx + 0.065f * s, cy + 0.12f * s);
                c.drawRoundRect(rect, s * 0.03f, s * 0.03f, stroke);
            }
            label(c, battPct + "%", "Battery", x, y, s, a);
        }

        private void cloud(Canvas c, float cx, float cy, float w, int color, float a) {
            fill.setColor(argb(255f * a, color));
            tmp.reset();
            tmp.addRoundRect(cx - 0.36f * w, cy, cx + 0.36f * w, cy + 0.24f * w, 0.12f * w, 0.12f * w, Path.Direction.CW);
            tmp.addCircle(cx - 0.12f * w, cy + 0.02f * w, 0.18f * w, Path.Direction.CW);
            tmp.addCircle(cx + 0.13f * w, cy + 0.05f * w, 0.14f * w, Path.Direction.CW);
            c.drawPath(tmp, fill);
        }

        private void sun(Canvas c, float cx, float cy, float r, float a) {
            fill.setColor(argb(255f * a, 0xFFC83D));
            c.drawCircle(cx, cy, r, fill);
            stroke.setStrokeWidth(r * 0.30f);
            stroke.setColor(argb(255f * a, 0xFFC83D));
            for (int i = 0; i < 8; i++) {
                double an = Math.PI / 4.0 * i;
                float c0 = (float) Math.cos(an), s0 = (float) Math.sin(an);
                c.drawLine(cx + c0 * r * 1.45f, cy + s0 * r * 1.45f, cx + c0 * r * 1.9f, cy + s0 * r * 1.9f, stroke);
            }
        }

        private void drawWeather(Canvas c, float x, float y, float s, float a) {
            float cx = x + s / 2f, cy = y + s * 0.40f;
            switch (wKind) {
                case 1:
                    sun(c, cx - 0.07f * s, cy - 0.07f * s, 0.085f * s, a);
                    cloud(c, cx + 0.03f * s, cy - 0.02f * s, 0.46f * s, 0xFFFFFF, a);
                    break;
                case 2:
                    cloud(c, cx, cy - 0.07f * s, 0.54f * s, 0xFFE9EEF5, a);
                    break;
                case 3:
                case 4:
                    cloud(c, cx, cy - 0.12f * s, 0.50f * s, 0xFFE9EEF5, a);
                    stroke.setStrokeWidth(s * 0.032f);
                    stroke.setColor(argb(255f * a, wKind == 3 ? 0x5AC8FA : 0xFFFFFF));
                    for (int i = -1; i <= 1; i++) {
                        float px = cx + i * 0.11f * s;
                        if (wKind == 3) c.drawLine(px + 0.02f * s, cy + 0.15f * s, px - 0.02f * s, cy + 0.25f * s, stroke);
                        else c.drawPoint(px, cy + 0.20f * s, stroke);
                    }
                    break;
                default:
                    sun(c, cx, cy, 0.115f * s, a);
                    break;
            }
            String v = (temp != null && temp.length() > 0) ? temp + "\u00B0" : "--\u00B0";
            label(c, v, (cond != null && cond.length() > 0) ? cond : "Weather", x, y, s, a);
        }

        private void foot(Canvas c, float cx, float cy, float s, float rot, float a) {
            c.save();
            c.rotate(rot, cx, cy);
            fill.setColor(argb(255f * a, 0xFFFFFF));
            rect.set(cx - 0.034f * s, cy - 0.005f * s, cx + 0.034f * s, cy + 0.09f * s);
            c.drawOval(rect, fill);                                  // sole
            rect.set(cx - 0.030f * s, cy - 0.095f * s, cx + 0.030f * s, cy - 0.025f * s);
            c.drawOval(rect, fill);                                  // heel / toe block
            c.restore();
        }

        private void drawSteps(Canvas c, float x, float y, float s, float a) {
            float cx = x + s / 2f, cy = y + s * 0.40f;
            ring(c, cx, cy, s * 0.25f, s * 0.075f, steps < 0 ? 0f : steps / (float) STEP_GOAL, 0xFF30D158, a);
            foot(c, cx - 0.05f * s, cy + 0.02f * s, s, -10f, a);
            foot(c, cx + 0.05f * s, cy - 0.02f * s, s, 10f, a);
            String v = steps < 0 ? "--" : String.format(Locale.US, "%,d", steps);
            label(c, v, "Steps", x, y, s, a);
        }
    }
}

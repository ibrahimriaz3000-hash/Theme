package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.PowerManager;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/**
 * Control Center header info line, placed right above the date (left side):
 *     "57% UNTIL 1:30 ●"      (● = green dot, blinks the whole time the Control Center is open)
 * The text is a floating overlay (no layout space, no fade effect): it simply moves / fades together with the
 * header. The battery % next to the battery icon is NOT added by this module any more.
 */
final class CcBattery {
    private CcBattery() { }

    static final String K_CC_BATT = "cc_batt_pct";
    private static final int DOT_GREEN = 0xFF8CE600;

    private static XSharedPreferences xsp;
    private static long lastReload = 0;

    static synchronized boolean flag(String key, boolean def) {
        try {
            if (xsp == null) {
                xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                xsp.makeWorldReadable();
            }
            long now = System.currentTimeMillis();
            if (now - lastReload > 1000) {
                lastReload = now;
                if (xsp.hasFileChanged()) xsp.reload();
            }
            return xsp.getBoolean(key, def);
        } catch (Throwable t) {
            return def;
        }
    }

    static synchronized boolean enabled() {
        try {
            if (xsp == null) {
                xsp = new XSharedPreferences(PillController.MODULE_PKG, PillController.PREF_FILE);
                xsp.makeWorldReadable();
            }
            long now = System.currentTimeMillis();
            if (now - lastReload > 1000) {
                lastReload = now;
                if (xsp.hasFileChanged()) xsp.reload();
            }
            return xsp.getBoolean(K_CC_BATT, true);
        } catch (Throwable t) {
            return true;
        }
    }

    // ---- "the Control Center header is really on screen" signal, read by PillController (hides the line, keeps pill on top)
    private static volatile float hdrAlpha = 0f;
    private static volatile long hdrStamp = 0L;

    /** 0 = Control Center header not on screen, otherwise its effective opacity (0..1). Fresh within 160 ms. */
    static float headerSignal() {
        return (android.os.SystemClock.uptimeMillis() - hdrStamp < 160L) ? hdrAlpha : 0f;
    }

    private static int dumps = 0;

    private static final java.util.WeakHashMap<View, InfoView> ATTACHED = new java.util.WeakHashMap<>();

    /** Called for every BatteryMeterView that attaches; does nothing outside the Control Center. */
    static void attach(View battery, boolean inControlCenter) {
        try {
            if (!inControlCenter) return;
            ViewGroup host = MainHook.ccRoot(battery);
            if (host == null) {
                XposedBridge.log("DynamicPill: CC root not found, skipped");
                return;
            }
            InfoView old = ATTACHED.get(battery);
            if (old != null) {
                if (old.host == host && old.getParent() != null) return;
                old.dispose();
            }
            InfoView v = new InfoView(battery.getContext(), battery, host);
            host.getOverlay().add(v);
            ATTACHED.put(battery, v);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: CC info attach failed: " + t);
        }
    }

    static final class InfoView extends View {
        final ViewGroup host;
        private final View battery;
        private final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dotP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float dp;
        private final int[] loc = new int[2];
        private final int[] hloc = new int[2];

        private String text = "";
        private float blink = 1f;
        private ValueAnimator blinkAnim;
        private View anchor;                  // the date text view
        private long lastFind = 0;
        private float lastSize = -1f;
        private int lastL = Integer.MIN_VALUE, lastT = Integer.MIN_VALUE, lastW = -1, lastH = -1;
        private boolean registered = false;
        private android.view.ViewTreeObserver obs;

        // ---- battery state / estimate
        private int level = -1;
        private boolean charging = false;
        private final ArrayDeque<long[]> samples = new ArrayDeque<>();   // {time, level} while discharging
        private double emaCurrent = -1;                                  // smoothed |current_now| in uA
        private int emaCount = 0;

        private final BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) { read(i); refresh(); }
        };

        private final android.view.ViewTreeObserver.OnPreDrawListener pre =
                new android.view.ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() { update(); return true; }
        };

        private final android.database.ContentObserver styleObs =
                new android.database.ContentObserver(new android.os.Handler(android.os.Looper.getMainLooper())) {
            @Override
            public void onChange(boolean selfChange) { refresh(); }
        };

        // reports every 40 ms whether the Control Center header is really visible (any way it was opened)
        private final android.graphics.Rect vr = new android.graphics.Rect();
        private final Runnable sig = new Runnable() {
            @Override
            public void run() {
                try {
                    float a = 0f;
                    if (battery.isShown() && battery.getWidth() > 0 && battery.getWindowVisibility() == View.VISIBLE) {
                        battery.getLocationOnScreen(loc);
                        int sh = battery.getResources().getDisplayMetrics().heightPixels;
                        if (loc[1] >= 0 && loc[1] < sh / 2 && battery.getGlobalVisibleRect(vr)) a = effAlpha(battery);
                    }
                    if (a > 0.05f) { hdrAlpha = Math.min(1f, a); hdrStamp = android.os.SystemClock.uptimeMillis(); }
                    CcPager.tick(host, battery, anchor, a);
                } catch (Throwable ignored) { }
                if (isAttachedToWindow()) postDelayed(this, 40);
            }
        };

        private float effAlpha(View v) {
            float a = 1f;
            View c = v;
            for (int i = 0; i < 16 && c != null; i++) {
                a *= c.getAlpha();
                c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
            }
            return a;
        }

        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                try {
                    if (battery.isShown()) refresh();
                    else stopBlink();
                } catch (Throwable ignored) { }
                if (isAttachedToWindow()) postDelayed(this, battery.isShown() ? 15000 : 1500);
            }
        };

        InfoView(Context ctx, View battery, ViewGroup host) {
            super(ctx);
            this.battery = battery;
            this.host = host;
            dp = ctx.getResources().getDisplayMetrics().density;
            textP.setColor(Color.WHITE);
            textP.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 14,
                    ctx.getResources().getDisplayMetrics()));
            textP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            dotP.setColor(DOT_GREEN);
            setVisibility(View.GONE);
        }

        void dispose() {
            try { removeCallbacks(loop); removeCallbacks(sig); } catch (Throwable ignored) { }
            stopBlink();
            try { host.getOverlay().remove(this); } catch (Throwable ignored) { }
        }

        // ------------------------------------------------------------------ battery estimate

        private void read(Intent i) {
            if (i == null) return;
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int pl = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING
                    || st == BatteryManager.BATTERY_STATUS_FULL || pl > 0;
            if (ch != charging) { samples.clear(); emaCurrent = -1; emaCount = 0; }
            charging = ch;
            if (!charging && level >= 0) {
                long now = System.currentTimeMillis();
                long[] last = samples.peekLast();
                if (last == null || last[1] != level) samples.addLast(new long[]{now, level});
                while (!samples.isEmpty() && now - samples.peekFirst()[0] > 3L * 3600000L) samples.pollFirst();
            }
        }

        /** Best estimate of the remaining runtime (ms) while discharging, or -1. */
        private long dischargeMs(BatteryManager bm) {
            long ms = -1;
            // 1) the system's own prediction (same engine as the system battery screen), Android 12+
            try {
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
                    java.time.Duration d = pm.getBatteryDischargePrediction();
                    if (d != null) ms = d.toMillis();
                }
            } catch (Throwable ignored) { }
            if (ok(ms)) return ms;
            // 2) remaining charge / smoothed current draw
            try {
                long cur = Math.abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW));
                long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
                if (cur > 0) {
                    emaCurrent = emaCurrent < 0 ? cur : emaCurrent * 0.8 + cur * 0.2;
                    emaCount++;
                }
                if (emaCount >= 3 && cc > 0 && emaCurrent > 0) ms = (long) (cc / emaCurrent * 3600000.0);
            } catch (Throwable ignored) { }
            if (ok(ms)) return ms;
            // 3) observed % drop rate
            try {
                long[] first = samples.peekFirst();
                long now = System.currentTimeMillis();
                if (first != null && level > 0 && now - first[0] >= 15 * 60000L && first[1] > level) {
                    double perMs = (first[1] - level) / (double) (now - first[0]);
                    ms = (long) (level / perMs);
                }
            } catch (Throwable ignored) { }
            return ok(ms) ? ms : -1;
        }

        private boolean ok(long ms) { return ms >= 60000L && ms <= 200L * 3600000L; }

        private String clock(long atMs) {
            String s = new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(atMs));
            Calendar a = Calendar.getInstance(), b = Calendar.getInstance();
            b.setTimeInMillis(atMs);
            if (a.get(Calendar.DAY_OF_YEAR) != b.get(Calendar.DAY_OF_YEAR) || a.get(Calendar.YEAR) != b.get(Calendar.YEAR))
                s += " " + new SimpleDateFormat("EEE", Locale.getDefault()).format(new Date(atMs));
            return s;
        }

        /**
         * System "Battery indicator" (Settings -> Notifications & status bar):
         * 0 = icon only, 1 = number inside the icon, 2 = number next to the icon.
         */
        private int indicatorStyle() {
            int style = -1;
            try {
                style = android.provider.Settings.System.getInt(getContext().getContentResolver(),
                        "battery_indicator_style", -1);
            } catch (Throwable ignored) { }
            if (style >= 0) return style;
            try {
                return android.provider.Settings.System.getInt(getContext().getContentResolver(),
                        "status_bar_show_battery_percent", 0) == 1 ? 2 : 0;
            } catch (Throwable t) {
                return 0;
            }
        }

        private void refresh() {
            try {
                if (level < 0) return;
                BatteryManager bm = (BatteryManager) getContext().getSystemService(Context.BATTERY_SERVICE);
                // style 0 (icon only): the % is nowhere else, so it is part of this line.
                // style 1 / 2 (% inside / next to the icon): the system already shows it, so only "UNTIL <time>".
                boolean withPct = indicatorStyle() == 0;
                String pct = withPct ? level + "%" : "";
                String part;                       // e.g. "UNTIL 1:30 PM" / "FULL AT 2:15 PM" / ""
                if (charging) {
                    if (level >= 100) part = "CHARGED";
                    else {
                        long ms = -1;
                        try { ms = bm.computeChargeTimeRemaining(); } catch (Throwable ignored) { }
                        part = ok(ms) ? "FULL AT " + clock(System.currentTimeMillis() + ms) : "";
                    }
                } else {
                    long ms = dischargeMs(bm);
                    part = ms > 0 ? "UNTIL " + clock(System.currentTimeMillis() + ms) : "";
                }
                String t = (pct + (pct.isEmpty() || part.isEmpty() ? "" : " ") + part).toUpperCase(Locale.getDefault());
                if (!t.equals(text)) { text = t; lastW = -1; }
            } catch (Throwable ignored) { }
        }

        // ------------------------------------------------------------------ finding the date view

        private String idName(View v) {
            try {
                if (v.getId() != View.NO_ID) return v.getResources().getResourceEntryName(v.getId()).toLowerCase();
            } catch (Throwable ignored) { }
            return "";
        }

        private void scanDate(View v, int battTop, View[] best, int[] cnt, boolean strict) {
            if (best[0] != null || cnt[0]++ > 4000 || v == this) return;
            if (v instanceof TextView && v.isShown() && v.getWidth() > 0) {
                CharSequence t = ((TextView) v).getText();
                if (t != null && t.length() > 0) {
                    String cn = v.getClass().getName().toLowerCase(), id = idName(v);
                    boolean byName = (cn.contains("date") || id.contains("date")) && !cn.contains("update");
                    boolean byShape = false;
                    if (!strict) {
                        String s = t.toString();
                        boolean dg = false, lt = false;
                        for (int i = 0; i < s.length(); i++) {
                            if (Character.isDigit(s.charAt(i))) dg = true;
                            else if (Character.isLetter(s.charAt(i))) lt = true;
                        }
                        v.getLocationOnScreen(hloc);
                        byShape = dg && lt && !s.contains("%") && Math.abs(hloc[1] - battTop) < 60 * dp
                                && hloc[0] < battTop + 10000 && hloc[0] + v.getWidth() < loc[0] + 4;
                    }
                    if (byName || byShape) { best[0] = v; return; }
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    scanDate(g.getChildAt(i), battTop, best, cnt, strict);
                    if (best[0] != null) return;
                }
            }
        }

        private void findAnchor() {
            long now = android.os.SystemClock.uptimeMillis();
            if (anchor != null && anchor.isShown()) return;
            if (now - lastFind < 500) return;
            lastFind = now;
            anchor = null;
            try {
                battery.getLocationOnScreen(loc);
                int battTop = loc[1];
                View[] best = new View[1];
                scanDate(host, battTop, best, new int[]{0}, true);
                if (best[0] == null) scanDate(host, battTop, best, new int[]{0}, false);
                anchor = best[0];
            } catch (Throwable ignored) { }
        }

        private float relAlpha(View v) {
            float a = 1f;
            View c = v;
            for (int i = 0; i < 16 && c != null && c != host; i++) {
                a *= c.getAlpha();
                c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
            }
            return a;
        }

        // ------------------------------------------------------------------ layout every frame

        private void update() {
            try {
                if (!enabled() || !battery.isShown() || text.isEmpty()) { hideNow(); return; }
                findAnchor();
                float a;
                int left, bottom;
                host.getLocationOnScreen(hloc);
                int hx = hloc[0], hy = hloc[1];
                if (anchor != null && anchor.isShown()) {
                    a = relAlpha(anchor);
                    anchor.getLocationOnScreen(loc);
                    left = loc[0];
                    bottom = loc[1] - Math.round(dp * 2f);
                    float sz = ((TextView) anchor).getTextSize();
                    if (sz != lastSize) {
                        lastSize = sz;
                        textP.setTextSize(sz);
                        try { textP.setTypeface(((TextView) anchor).getTypeface()); } catch (Throwable ignored) { }
                        lastW = -1;
                    }
                } else {
                    a = relAlpha(battery);
                    battery.getLocationOnScreen(loc);
                    left = Math.round(dp * 24f);
                    bottom = loc[1] - Math.round(dp * 24f);
                }
                if (a < 0.02f) { hideNow(); return; }
                Paint.FontMetrics fm = textP.getFontMetrics();
                int th = (int) Math.ceil(fm.descent - fm.ascent);
                float tw = textP.measureText(text);
                float r = th * 0.13f, gap = th * 0.35f;
                int w = (int) Math.ceil(tw + gap + r * 2f) + 2;
                int l = left - hx, t = bottom - th - hy;
                if (l != lastL || t != lastT || w != lastW || th != lastH) {
                    lastL = l; lastT = t; lastW = w; lastH = th;
                    layout(l, t, l + w, t + th);
                }
                if (getVisibility() != View.VISIBLE) setVisibility(View.VISIBLE);
                if (getAlpha() != a) setAlpha(a);
                startBlink();
                scheduleDump(a);
            } catch (Throwable ignored) { }
        }

        // ---- one-time dump of the Control Center view tree into the LSPosed log (lines start with "DP-TREE")
        private boolean dumpScheduled = false;

        private void scheduleDump(float a) {
            if (dumpScheduled || a < 0.95f || dumps >= 2) return;
            dumpScheduled = true;
            postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (dumps >= 2 || !battery.isShown()) { dumpScheduled = false; return; }
                        dumps++;
                        XposedBridge.log("DP-TREE ---- Control Center view tree #" + dumps + " ----");
                        walk(host, 0, new int[]{0});
                        XposedBridge.log("DP-TREE ---- end ----");
                    } catch (Throwable t) {
                        XposedBridge.log("DP-TREE failed: " + t);
                    }
                    dumpScheduled = false;
                }
            }, 700);
        }

        private void walk(View v, int depth, int[] n) {
            if (n[0]++ > 700 || depth > 16) return;
            StringBuilder sb = new StringBuilder("DP-TREE ");
            for (int i = 0; i < depth; i++) sb.append(' ');
            sb.append(v.getClass().getName());
            String id = idName(v);
            if (!id.isEmpty()) sb.append(" #").append(id);
            int[] l = new int[2];
            v.getLocationOnScreen(l);
            sb.append(" [").append(l[0]).append(',').append(l[1]).append(' ')
              .append(v.getWidth()).append('x').append(v.getHeight()).append(']');
            if (v.getVisibility() != View.VISIBLE) sb.append(" vis=").append(v.getVisibility());
            if (v.getAlpha() < 0.99f) sb.append(" a=").append(v.getAlpha());
            if (v instanceof TextView) {
                CharSequence t = ((TextView) v).getText();
                if (t != null && t.length() > 0) sb.append(" \"").append(t.length() > 24 ? t.subSequence(0, 24) : t).append('"');
            }
            XposedBridge.log(sb.toString());
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), depth + 1, n);
            }
        }

        private void hideNow() {
            if (getVisibility() != View.GONE) setVisibility(View.GONE);
            stopBlink();
        }

        // ------------------------------------------------------------------ green dot blink (all the time while open)

        private void startBlink() {
            if (blinkAnim != null && blinkAnim.isRunning()) return;
            blinkAnim = ValueAnimator.ofFloat(0f, 1f);
            blinkAnim.setDuration(1100);
            blinkAnim.setRepeatCount(ValueAnimator.INFINITE);
            blinkAnim.setInterpolator(new android.view.animation.LinearInterpolator());
            blinkAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator va) {
                    float t = (Float) va.getAnimatedValue();
                    blink = 0.12f + 0.88f * (0.5f + 0.5f * (float) Math.cos(t * 2f * Math.PI));
                    invalidate();
                }
            });
            blinkAnim.start();
        }

        private void stopBlink() {
            if (blinkAnim != null) { blinkAnim.cancel(); blinkAnim = null; }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (text.isEmpty()) return;
            Paint.FontMetrics fm = textP.getFontMetrics();
            float base = -fm.ascent;
            canvas.drawText(text, 0f, base, textP);
            int th = getHeight();
            float r = th * 0.13f, gap = th * 0.35f;
            float cx = textP.measureText(text) + gap + r;
            // centre the dot on the capital letters, not on the full line box
            float cy = base - (textP.getTextSize() * 0.36f);
            dotP.setAlpha(Math.round(255f * blink));
            canvas.drawCircle(cx, cy, r, dotP);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            try {
                if (!registered) {
                    read(getContext().registerReceiver(rcv, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
                    registered = true;
                }
            } catch (Throwable ignored) { }
            try {
                obs = battery.getViewTreeObserver();
                if (obs.isAlive()) obs.addOnPreDrawListener(pre);
            } catch (Throwable ignored) { }
            try {
                getContext().getContentResolver().registerContentObserver(
                        android.provider.Settings.System.getUriFor("battery_indicator_style"), false, styleObs);
            } catch (Throwable ignored) { }
            refresh();
            removeCallbacks(loop);
            postDelayed(loop, 1500);
            removeCallbacks(sig);
            post(sig);
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            removeCallbacks(loop);
            removeCallbacks(sig);
            stopBlink();
            try { if (obs != null && obs.isAlive()) obs.removeOnPreDrawListener(pre); } catch (Throwable ignored) { }
            obs = null;
            try { getContext().getContentResolver().unregisterContentObserver(styleObs); } catch (Throwable ignored) { }
            try { if (registered) getContext().unregisterReceiver(rcv); } catch (Throwable ignored) { }
            registered = false;
        }
    }
}

package com.dynamicpill.module;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.MaskFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;

import java.util.HashMap;
import java.util.Locale;

/**
 * Black capsule with an indicator dot (right) and a small charging bolt (left).
 * It can also expand into "scenes" (charging, silent / vibrate / ring, call, lock, unlock) like the
 * iOS Dynamic Island: the capsule grows, the content blurs in, stays, then everything shrinks back.
 * A neon outline can glow around it (WhatsApp).
 */
public class PillView extends View {
    public static final int SC_NONE = 0, SC_CHARGE = 1, SC_SILENT = 2, SC_VIBRATE = 3,
            SC_RING = 4, SC_CALL = 5, SC_LOCK = 6, SC_UNLOCK = 7;

    private static final ArgbEvaluator ARGB = new ArgbEvaluator();

    private static final int BOLT_GREEN = 0xFF34C759;
    /** One full blink (dim and back) takes this long. */
    private static final long BLINK_PERIOD_MS = 1000;
    /** Fade time for colour / thickness / icon changes. */
    private static final long FADE_MS = 350;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bolt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);     // scene text
    private final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG);     // scene fills
    private final Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);     // scene strokes
    private final Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);     // glow strokes
    private final RectF rect = new RectF();
    private final RectF rect2 = new RectF();
    private final Path boltPath = new Path();
    private final Path shape = new Path();
    private final Path edgeShape = new Path();
    private final Path neonShape = new Path();
    private final Path tmpPath = new Path();
    private final Path clipPath = new Path();
    private final Path unitBell = new Path();
    private final Path unitHandset = new Path();
    private final Path unitShackle = new Path();
    private final Matrix tmpM = new Matrix();
    private final HashMap<Integer, BlurMaskFilter> blurCache = new HashMap<>();
    private float smoothN = 2f;                 // 2 = plain circular capsule, > 2 = iOS style continuous curve
    private float shapeW = -1, shapeH = -1, shapeIn = -1, shapeNKey = -1;
    private float edgeW = -1, edgeH = -1, edgeIn = -1, edgeNKey = -1;

    // geometry (pixels): normal capsule, expanded capsule, glow padding inside the window
    private float baseW = 0, capH = 0, expW = 0, padPx = 0;

    // outline: thickness and colour fade to their target values
    private float borderTarget = 0f, borderCur = 0f;
    private int strokeTarget = 0xFFFFFFFF, strokeCur = 0xFFFFFFFF;
    private ValueAnimator borderAnim, strokeAnim;

    // dot: colour fades, blink fades
    private boolean dotOn = true;
    private int dotTarget = 0xFFFFCC00, dotCur = 0xFFFFCC00; // yellow
    private ValueAnimator dotColorAnim;

    // charging bolt fades in and out
    private boolean charging = false;
    private float boltFactor = 0f;
    private ValueAnimator boltAnim;

    private float dotBlink = 1f;     // dot blink (new notification)
    private float strokeBlink = 1f;  // outline blink (call)
    private ValueAnimator dotBlinkAnim, strokeBlinkAnim, dotRestoreAnim;

    // ---- scenes
    private int scene = SC_NONE;       // wanted scene
    private int drawScene = SC_NONE;   // scene whose content is drawn right now
    private float expand = 0f;         // 0 = normal capsule, 1 = expanded
    private float content = 0f;        // 0..1 content visibility (alpha + blur)
    private float wfCur = 1f;          // current width factor of the scene (1 = full expanded width)
    private long sceneT0 = 0;
    private ValueAnimator expandAnim, contentAnim, widthAnim;
    private int battLevel = 50;
    private long callStart = 0;
    private boolean callRinging = false;

    // ---- neon outline
    private boolean neonTarget = false;
    private float neonF = 0f;
    private int neonColor = 0xFF32FF6A;
    private ValueAnimator neonAnim;

    public PillView(Context context) {
        super(context);
        setLayerType(LAYER_TYPE_SOFTWARE, null);   // needed for blur / glow mask filters
        paint.setDither(true);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(0xFF000000); // pure dark black, full alpha
        paint.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        dot.setStyle(Paint.Style.FILL);
        bolt.setStyle(Paint.Style.FILL);
        bolt.setColor(BOLT_GREEN);

        tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        ip.setStyle(Paint.Style.FILL);
        sp.setStyle(Paint.Style.STROKE);
        sp.setStrokeCap(Paint.Cap.ROUND);
        sp.setStrokeJoin(Paint.Join.ROUND);
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeCap(Paint.Cap.ROUND);
        gp.setStrokeJoin(Paint.Join.ROUND);

        // unit shapes, centred on (0,0), about 1 unit tall
        unitBell.moveTo(-0.42f, 0.24f);
        unitBell.cubicTo(-0.30f, 0.14f, -0.28f, -0.02f, -0.26f, -0.12f);
        unitBell.cubicTo(-0.24f, -0.30f, -0.12f, -0.38f, 0f, -0.38f);
        unitBell.cubicTo(0.12f, -0.38f, 0.24f, -0.30f, 0.26f, -0.12f);
        unitBell.cubicTo(0.28f, -0.02f, 0.30f, 0.14f, 0.42f, 0.24f);
        unitBell.close();
        unitBell.addCircle(0f, -0.42f, 0.05f, Path.Direction.CW);
        unitBell.addCircle(0f, 0.34f, 0.09f, Path.Direction.CW);

        unitHandset.moveTo(-0.28f, -0.28f);
        unitHandset.cubicTo(-0.38f, 0.10f, -0.08f, 0.38f, 0.28f, 0.28f);

        unitShackle.moveTo(-0.17f, -0.03f);
        unitShackle.lineTo(-0.17f, -0.16f);
        unitShackle.arcTo(new RectF(-0.17f, -0.33f, 0.17f, 0.01f), 180f, 180f, false);
        unitShackle.lineTo(0.17f, -0.03f);
    }

    // ------------------------------------------------------------------ public setters

    /** Normal capsule size, expanded capsule width and glow padding, all in pixels. */
    public void setGeometry(int baseWidth, int capHeight, int expandedWidth, int pad) {
        if (baseW == baseWidth && capH == capHeight && expW == expandedWidth && padPx == pad) return;
        baseW = baseWidth;
        capH = capHeight;
        expW = expandedWidth;
        padPx = pad;
        invalidate();
    }

    public void setBattery(int pct) {
        pct = Math.max(0, Math.min(100, pct));
        if (pct != battLevel) {
            battLevel = pct;
            invalidate();
        }
    }

    public void setCall(long startUptime, boolean ringing) {
        callStart = startUptime;
        callRinging = ringing;
    }

    /** Neon glow around the capsule (WhatsApp is open). Fades in and out. */
    public void setNeon(boolean on, int color) {
        neonColor = color;
        if (on == neonTarget) return;
        neonTarget = on;
        if (neonAnim != null) neonAnim.cancel();
        neonAnim = ValueAnimator.ofFloat(neonF, on ? 1f : 0f);
        neonAnim.setDuration(380);
        neonAnim.addUpdateListener(a -> {
            neonF = (Float) a.getAnimatedValue();
            invalidate();
        });
        neonAnim.start();
    }

    private static float widthFactor(int s) {
        return (s == SC_LOCK || s == SC_UNLOCK) ? 0.66f : 1f;
    }

    /** Expands the pill into a scene (SC_*), or collapses it again with SC_NONE. */
    public void setScene(int s) {
        if (s == scene) return;
        int old = scene;
        scene = s;
        if (s == SC_NONE) {
            runContent(0f, 130, 0, null);
            runExpand(0f, 420, 80, new PathInterpolator(0.32f, 0.72f, 0f, 1f));
        } else if (old == SC_NONE || expand < 0.02f || drawScene == SC_NONE) {
            drawScene = s;
            sceneT0 = SystemClock.uptimeMillis();
            wfCur = widthFactor(s);
            runExpand(1f, 480, 0, new OvershootInterpolator(0.85f));
            runContent(1f, 380, 140, null);
        } else {
            // switching while already expanded: content blurs out, width changes, new content blurs in
            if (expand < 0.98f) runExpand(1f, 300, 0, new DecelerateInterpolator());
            runContent(0f, 110, 0, new Runnable() {
                @Override
                public void run() {
                    if (scene == SC_NONE) return;
                    drawScene = scene;
                    sceneT0 = SystemClock.uptimeMillis();
                    runWidth(widthFactor(scene), 280);
                    runContent(1f, 300, 0, null);
                }
            });
        }
    }

    private void runExpand(float to, long dur, long delay, TimeInterpolator ti) {
        if (expandAnim != null) expandAnim.cancel();
        ValueAnimator a = ValueAnimator.ofFloat(expand, to);
        a.setDuration(dur);
        a.setStartDelay(delay);
        a.setInterpolator(ti);
        a.addUpdateListener(v -> {
            expand = (Float) v.getAnimatedValue();
            invalidate();
        });
        final boolean[] canc = {false};
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator an) {
                canc[0] = true;
            }

            @Override
            public void onAnimationEnd(Animator an) {
                if (!canc[0] && scene == SC_NONE) {
                    expand = 0f;
                    content = 0f;
                    drawScene = SC_NONE;
                    invalidate();
                }
            }
        });
        expandAnim = a;
        a.start();
    }

    private void runContent(float to, long dur, long delay, final Runnable onEnd) {
        if (contentAnim != null) contentAnim.cancel();
        ValueAnimator a = ValueAnimator.ofFloat(content, to);
        a.setDuration(dur);
        a.setStartDelay(delay);
        a.setInterpolator(new DecelerateInterpolator());
        a.addUpdateListener(v -> {
            content = (Float) v.getAnimatedValue();
            invalidate();
        });
        final boolean[] canc = {false};
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator an) {
                canc[0] = true;
            }

            @Override
            public void onAnimationEnd(Animator an) {
                if (!canc[0] && onEnd != null) onEnd.run();
            }
        });
        contentAnim = a;
        a.start();
    }

    private void runWidth(float to, long dur) {
        if (widthAnim != null) widthAnim.cancel();
        ValueAnimator a = ValueAnimator.ofFloat(wfCur, to);
        a.setDuration(dur);
        a.setInterpolator(new DecelerateInterpolator());
        a.addUpdateListener(v -> {
            wfCur = (Float) v.getAnimatedValue();
            invalidate();
        });
        widthAnim = a;
        a.start();
    }

    // ------------------------------------------------------------------ existing setters

    /** Corner smoothness 0..100. 0 = circular ends, higher = softer, continuous (iOS style) curvature. */
    public void setSmooth(int percent) {
        float n = 2f + 0.6f * Math.max(0, Math.min(100, percent)) / 100f;
        if (n != smoothN) {
            smoothN = n;
            invalidate();
        }
    }

    /**
     * Capsule whose end caps are superellipse arcs: the curvature changes gradually into the straight
     * edges (no visible "where the circle starts" line), which looks smoother than a plain round rect.
     */
    private static void buildCapsule(Path p, float w, float h, float inset, float n) {
        p.reset();
        float r = h / 2f - inset;
        if (r <= 0f || w <= h) { p.addRoundRect(new RectF(inset, inset, w - inset, h - inset), h / 2f, h / 2f, Path.Direction.CW); return; }
        float e = 2f / n;
        float cy = h / 2f, cxR = w - h / 2f, cxL = h / 2f;
        final int N = 40;
        for (int i = 0; i <= N; i++) {                       // right cap, top -> bottom
            double u = -Math.PI / 2 + Math.PI * i / N;
            float c = (float) Math.pow(Math.max(0.0, Math.cos(u)), e);
            float sn = (float) (Math.signum(Math.sin(u)) * Math.pow(Math.abs(Math.sin(u)), e));
            float x = cxR + r * c, y = cy + r * sn;
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        for (int i = 0; i <= N; i++) {                       // left cap, bottom -> top
            double u = -Math.PI / 2 + Math.PI * i / N;
            float c = (float) Math.pow(Math.max(0.0, Math.cos(u)), e);
            float sn = (float) (Math.signum(Math.sin(u)) * Math.pow(Math.abs(Math.sin(u)), e));
            p.lineTo(cxL - r * c, cy - r * sn);
        }
        p.close();
    }

    /** Border thickness in pixels; 0 = no border. Fades to the new thickness. */
    public void setBorder(float px) {
        px = Math.max(0f, px);
        if (px == borderTarget) return;
        borderTarget = px;
        if (borderAnim != null) borderAnim.cancel();
        final float from = borderCur, to = px;
        borderAnim = ValueAnimator.ofFloat(0f, 1f);
        borderAnim.setDuration(FADE_MS);
        borderAnim.addUpdateListener(a -> {
            borderCur = from + (to - from) * (Float) a.getAnimatedValue();
            invalidate();
        });
        borderAnim.start();
    }

    /** Border colour (white normally, green while charging or in a call). Cross-fades. */
    public void setStrokeColor(int color) {
        if (color == strokeTarget) return;
        strokeTarget = color;
        if (strokeAnim != null) strokeAnim.cancel();
        final int from = strokeCur, to = color;
        strokeAnim = ValueAnimator.ofFloat(0f, 1f);
        strokeAnim.setDuration(FADE_MS);
        strokeAnim.addUpdateListener(a -> {
            strokeCur = (Integer) ARGB.evaluate((Float) a.getAnimatedValue(), from, to);
            invalidate();
        });
        strokeAnim.start();
    }

    /** 0..100 percent; 100 = fully solid black. */
    public void setPillAlpha(int percent) {
        int a = Math.round(255f * Math.max(0, Math.min(100, percent)) / 100f);
        if (paint.getAlpha() != a) {
            paint.setAlpha(a);
            invalidate();
        }
    }

    /** Indicator dot inside the pill: shown or not, and its colour (cross-fades). */
    public void setDot(boolean on, int color) {
        if (on != dotOn) {
            dotOn = on;
            invalidate();
        }
        if (color == dotTarget) return;
        dotTarget = color;
        if (dotColorAnim != null) dotColorAnim.cancel();
        final int from = dotCur, to = color;
        dotColorAnim = ValueAnimator.ofFloat(0f, 1f);
        dotColorAnim.setDuration(FADE_MS);
        dotColorAnim.addUpdateListener(a -> {
            dotCur = (Integer) ARGB.evaluate((Float) a.getAnimatedValue(), from, to);
            invalidate();
        });
        dotColorAnim.start();
    }

    /** Small green lightning bolt on the left side while the phone is charging. Fades in and out. */
    public void setBolt(boolean on) {
        if (on == charging) return;
        charging = on;
        if (boltAnim != null) boltAnim.cancel();
        boltAnim = ValueAnimator.ofFloat(boltFactor, on ? 1f : 0f);
        boltAnim.setDuration(FADE_MS);
        boltAnim.addUpdateListener(a -> {
            boltFactor = (Float) a.getAnimatedValue();
            invalidate();
        });
        boltAnim.start();
    }

    private ValueAnimator startBlink(final boolean forDot) {
        ValueAnimator a = ValueAnimator.ofFloat(1f, 0.1f);
        a.setDuration(BLINK_PERIOD_MS / 2);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.addUpdateListener(v -> {
            if (forDot) dotBlink = (Float) v.getAnimatedValue();
            else strokeBlink = (Float) v.getAnimatedValue();
            invalidate();
        });
        a.start();
        return a;
    }

    /** Makes the dot fade out and in once per second. Stopping fades it back to full smoothly. */
    public void setBlink(boolean on) {
        if (on) {
            if (dotRestoreAnim != null) {
                dotRestoreAnim.cancel();
                dotRestoreAnim = null;
            }
            if (dotBlinkAnim == null) dotBlinkAnim = startBlink(true);
        } else if (dotBlinkAnim != null) {
            dotBlinkAnim.cancel();
            dotBlinkAnim = null;
            final float from = dotBlink;
            if (from >= 0.99f) {
                dotBlink = 1f;
                invalidate();
            } else {
                dotRestoreAnim = ValueAnimator.ofFloat(from, 1f);
                dotRestoreAnim.setDuration(250);
                dotRestoreAnim.addUpdateListener(a -> {
                    dotBlink = (Float) a.getAnimatedValue();
                    invalidate();
                });
                dotRestoreAnim.start();
            }
        }
    }

    /** Makes the outline fade out and in once per second (call). */
    public void setStrokeBlink(boolean on) {
        if (on) {
            if (strokeBlinkAnim == null) strokeBlinkAnim = startBlink(false);
        } else if (strokeBlinkAnim != null) {
            strokeBlinkAnim.cancel();
            strokeBlinkAnim = null;
            strokeBlink = 1f;
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ValueAnimator[] all = {borderAnim, strokeAnim, dotColorAnim, boltAnim, dotBlinkAnim, strokeBlinkAnim,
                dotRestoreAnim, expandAnim, contentAnim, widthAnim, neonAnim};
        for (ValueAnimator a : all) if (a != null) a.cancel();
        borderAnim = strokeAnim = dotColorAnim = boltAnim = dotBlinkAnim = strokeBlinkAnim = dotRestoreAnim = null;
        expandAnim = contentAnim = widthAnim = neonAnim = null;
        // snap to the final values so nothing stays half faded
        borderCur = borderTarget;
        strokeCur = strokeTarget;
        dotCur = dotTarget;
        boltFactor = charging ? 1f : 0f;
        dotBlink = 1f;
        strokeBlink = 1f;
        expand = scene == SC_NONE ? 0f : 1f;
        content = scene == SC_NONE ? 0f : 1f;
        neonF = neonTarget ? 1f : 0f;
    }

    // ------------------------------------------------------------------ drawing helpers

    private BlurMaskFilter mkBlur(float radius) {
        int key = Math.max(1, Math.round(radius * 2f));
        BlurMaskFilter f = blurCache.get(key);
        if (f == null) {
            f = new BlurMaskFilter(key / 2f, BlurMaskFilter.Blur.NORMAL);
            blurCache.put(key, f);
        }
        return f;
    }

    private static float clamp01(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float ease(float x) {
        float t = 1f - clamp01(x);
        return 1f - t * t * t;
    }

    /** Sets colour (its own alpha kept), extra alpha and mask filter; removes any shader. */
    private static void prep(Paint p, int color, float alpha, MaskFilter mf) {
        p.setShader(null);
        p.setColor(color);
        p.setAlpha(Math.round(Color.alpha(color) * clamp01(alpha)));
        p.setMaskFilter(mf);
    }

    private void drawUnit(Canvas c, Path unit, float cx, float cy, float s, Paint p) {
        tmpM.setScale(s, s);
        tmpM.postTranslate(cx, cy);
        unit.transform(tmpM, tmpPath);
        c.drawPath(tmpPath, p);
    }

    private void fillCapsule(Path p, float w, float h, float inset) {
        if (smoothN <= 2.001f) {
            p.reset();
            float r = Math.max(0f, h / 2f - inset);
            p.addRoundRect(new RectF(inset, inset, w - inset, h - inset), r, r, Path.Direction.CW);
        } else {
            buildCapsule(p, w, h, inset, smoothN);
        }
    }

    // ------------------------------------------------------------------ onDraw

    @Override
    protected void onDraw(Canvas canvas) {
        float W = getWidth(), H = getHeight();
        float h = capH > 0 ? capH : H;
        float bw = baseW > 0 ? baseW : W;
        float ew = Math.max(bw, expW);
        float sceneW = Math.max(bw, ew * wfCur);
        float w = Math.min(W, Math.max(h, bw + (sceneW - bw) * expand));
        float left = (W - w) / 2f, top = (H - h) / 2f;

        canvas.save();
        canvas.translate(left, top);

        boolean plain = smoothN <= 2.001f;
        if (plain) {
            rect.set(0, 0, w, h);
            canvas.drawRoundRect(rect, h / 2f, h / 2f, paint);
        } else {
            if (shapeW != w || shapeH != h || shapeNKey != smoothN || shapeIn != 0f) {
                buildCapsule(shape, w, h, 0f, smoothN);
                shapeW = w; shapeH = h; shapeNKey = smoothN; shapeIn = 0f;
            }
            canvas.drawPath(shape, paint);
        }

        if (neonF > 0.01f) drawNeon(canvas, w, h);

        if (borderCur > 0.05f) {
            stroke.setColor(strokeCur);
            stroke.setAlpha(Math.round(255f * strokeBlink * Math.min(1f, borderCur)));
            stroke.setStrokeWidth(borderCur);
            float in = borderCur / 2f;
            if (plain) {
                rect.set(in, in, w - in, h - in);
                float rr = Math.max(0f, h / 2f - in);
                canvas.drawRoundRect(rect, rr, rr, stroke);
            } else {
                if (edgeW != w || edgeH != h || edgeNKey != smoothN || edgeIn != in) {
                    buildCapsule(edgeShape, w, h, in, smoothN);
                    edgeW = w; edgeH = h; edgeNKey = smoothN; edgeIn = in;
                }
                canvas.drawPath(edgeShape, stroke);
            }
        }

        float idle = 1f - Math.min(1f, expand * 1.8f);   // dot and bolt fade away while a scene is shown
        if (dotOn && idle > 0.01f) {
            dot.setColor(dotCur);
            dot.setAlpha(Math.round(255f * dotBlink * idle));
            canvas.drawCircle(w - h * 0.5f, h / 2f, h * 0.16f, dot);
        }

        if (boltFactor > 0.01f && idle > 0.01f) drawBolt(canvas, h, boltFactor * idle);

        if (drawScene != SC_NONE && content > 0.01f) {
            try {
                drawSceneContent(canvas, w, h);
            } catch (Throwable ignored) { }
        }

        canvas.restore();

        boolean sceneActive = expand > 0.01f || content > 0.01f;
        if (sceneActive) {
            boolean moving = (expandAnim != null && expandAnim.isRunning())
                    || (contentAnim != null && contentAnim.isRunning())
                    || (widthAnim != null && widthAnim.isRunning());
            postInvalidateDelayed(moving ? 16 : 33);
        } else if (neonF > 0.01f) {
            postInvalidateDelayed(50);
        }
    }

    /** Small lightning bolt, centred in the left cap of the pill. */
    private void drawBolt(Canvas canvas, float h, float factor) {
        float bh = h * 0.46f;
        float bw = bh * 0.7f;
        float x0 = h * 0.5f - bw / 2f;
        float y0 = h * 0.5f - bh / 2f;
        boltPath.reset();
        boltPath.moveTo(x0 + 0.62f * bw, y0);
        boltPath.lineTo(x0 + 0.08f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.46f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.34f * bw, y0 + bh);
        boltPath.lineTo(x0 + 0.92f * bw, y0 + 0.42f * bh);
        boltPath.lineTo(x0 + 0.54f * bw, y0 + 0.42f * bh);
        boltPath.close();
        bolt.setAlpha(Math.round(255f * factor));
        canvas.drawPath(boltPath, bolt);
    }

    // ------------------------------------------------------------------ neon outline

    private void drawNeon(Canvas c, float w, float h) {
        long now = SystemClock.uptimeMillis();
        float pulse = 0.82f + 0.18f * (float) Math.sin(now / 380.0);
        float f = neonF;
        fillCapsule(neonShape, w, h, h * 0.03f);
        gp.setShader(null);
        gp.setColor(neonColor);
        gp.setStrokeWidth(h * 0.22f);
        gp.setAlpha(Math.round(255f * 0.55f * pulse * f));
        gp.setMaskFilter(mkBlur(h * 0.30f));
        c.drawPath(neonShape, gp);
        gp.setStrokeWidth(h * 0.10f);
        gp.setAlpha(Math.round(255f * 0.85f * pulse * f));
        gp.setMaskFilter(mkBlur(h * 0.07f));
        c.drawPath(neonShape, gp);
        gp.setMaskFilter(null);
        gp.setStrokeWidth(h * 0.045f);
        gp.setColor(0xFFC8FFD6);
        gp.setAlpha(Math.round(255f * f));
        c.drawPath(neonShape, gp);
    }

    // ------------------------------------------------------------------ scene content

    private void drawSceneContent(Canvas c, float w, float h) {
        float a = clamp01(content);
        int level = Math.round((1f - a) * 6f);                  // 0 (sharp) .. 6 (very blurred)
        MaskFilter bf = level == 0 ? null : mkBlur(h * 0.30f * level / 6f);
        long now = SystemClock.uptimeMillis();
        long t = now - sceneT0;
        switch (drawScene) {
            case SC_CHARGE: drawCharge(c, w, h, a, bf); break;
            case SC_SILENT:
            case SC_VIBRATE:
            case SC_RING: drawRinger(c, w, h, a, bf, t); break;
            case SC_CALL: drawCall(c, w, h, a, bf, now); break;
            case SC_LOCK: drawLockScene(c, w, h, a, bf, t, false); break;
            case SC_UNLOCK: drawLockScene(c, w, h, a, bf, t, true); break;
            default: break;
        }
    }

    private float textBase(float h) {
        return h / 2f - (tp.ascent() + tp.descent()) / 2f;
    }

    private void drawCharge(Canvas c, float w, float h, float a, MaskFilter bf) {
        float padX = h * 0.52f;
        tp.setTextSize(h * 0.40f);
        tp.setTextAlign(Paint.Align.LEFT);
        prep(tp, 0xFFFFFFFF, a, bf);
        c.drawText("Charging", padX, textBase(h), tp);

        float bodyW = h * 0.92f, bodyH = h * 0.44f, nubW = h * 0.06f, nubH = h * 0.16f;
        float nubRight = w - padX;
        float bodyRight = nubRight - nubW - h * 0.025f;
        float bodyLeft = bodyRight - bodyW;
        float by = h / 2f - bodyH / 2f;
        float rad = bodyH * 0.32f;

        // percentage text
        tp.setTextAlign(Paint.Align.RIGHT);
        prep(tp, 0xFF34C759, a, bf);
        c.drawText(battLevel + "%", bodyLeft - h * 0.20f, textBase(h), tp);

        // battery: dark track, gradient fill up to the level
        rect.set(bodyLeft, by, bodyRight, by + bodyH);
        prep(ip, 0xFF2F6B40, a, bf);
        c.drawRoundRect(rect, rad, rad, ip);
        clipPath.reset();
        clipPath.addRoundRect(rect, rad, rad, Path.Direction.CW);
        c.save();
        c.clipPath(clipPath);
        float fillRight = bodyLeft + bodyW * battLevel / 100f;
        rect2.set(bodyLeft, by, fillRight, by + bodyH);
        prep(ip, 0xFFFFFFFF, a, bf);
        ip.setShader(new LinearGradient(bodyLeft, 0f, bodyRight, 0f, 0xFF15C5A8, 0xFF34C759, Shader.TileMode.CLAMP));
        c.drawRect(rect2, ip);
        ip.setShader(null);
        c.restore();
        // nub
        rect2.set(bodyRight + h * 0.025f, h / 2f - nubH / 2f, bodyRight + h * 0.025f + nubW, h / 2f + nubH / 2f);
        prep(ip, 0xFF2F6B40, a, bf);
        c.drawRoundRect(rect2, nubW / 2f, nubW / 2f, ip);
    }

    private void drawRinger(Canvas c, float w, float h, float a, MaskFilter bf, long t) {
        int accent;
        String label;
        int textColor;
        if (drawScene == SC_SILENT) {
            accent = 0xFFFF3B30; label = "Silent"; textColor = 0xFFFF3B30;
        } else if (drawScene == SC_VIBRATE) {
            accent = 0xFFFF9500; label = "Vibrate"; textColor = 0xFFFF9500;
        } else {
            accent = 0xFF48484A; label = "Ring"; textColor = 0xFFFFFFFF;
        }
        float ih = h * 0.64f, iw = ih * 2.1f, il = h * 0.18f, it = (h - ih) / 2f;
        rect.set(il, it, il + iw, it + ih);
        prep(ip, accent, a, bf);
        c.drawRoundRect(rect, ih / 2f, ih / 2f, ip);

        float cx = il + iw / 2f, cy = h / 2f, s = ih * 0.62f;
        if (drawScene == SC_VIBRATE) {
            float dx = (float) (Math.sin(t / 22.0) * s * 0.04 * (t < 1400 ? 1.0 : 0.4));
            c.save();
            c.translate(dx, 0f);
            prep(sp, 0xFFFFFFFF, a, bf);
            sp.setStrokeWidth(s * 0.075f);
            rect2.set(cx - 0.16f * s, cy - 0.30f * s, cx + 0.16f * s, cy + 0.30f * s);
            c.drawRoundRect(rect2, 0.07f * s, 0.07f * s, sp);
            float[] radii = {0.30f, 0.44f};
            for (float rr : radii) {
                rect2.set(cx - rr * s, cy - rr * s, cx + rr * s, cy + rr * s);
                c.drawArc(rect2, -38f, 76f, false, sp);
                c.drawArc(rect2, 142f, 76f, false, sp);
            }
            c.restore();
        } else {
            boolean slashed = drawScene == SC_SILENT;
            float ang = (float) (Math.sin(t / 55.0) * 16.0 * Math.max(0.0, 1.0 - t / 1100.0));
            c.save();
            c.rotate(slashed ? 0f : ang, cx, cy - s * 0.4f);
            prep(ip, 0xFFFFFFFF, a, bf);
            drawUnit(c, unitBell, cx, cy, s, ip);
            c.restore();
            if (slashed) {
                prep(sp, accent, a, bf);
                sp.setStrokeWidth(s * 0.17f);
                c.drawLine(cx - 0.40f * s, cy - 0.38f * s, cx + 0.40f * s, cy + 0.40f * s, sp);
                prep(sp, 0xFFFFFFFF, a, bf);
                sp.setStrokeWidth(s * 0.07f);
                c.drawLine(cx - 0.40f * s, cy - 0.38f * s, cx + 0.40f * s, cy + 0.40f * s, sp);
            }
        }

        tp.setTextSize(h * 0.40f);
        tp.setTextAlign(Paint.Align.RIGHT);
        prep(tp, textColor, a, bf);
        c.drawText(label, w - h * 0.52f, textBase(h), tp);
    }

    private void drawCall(Canvas c, float w, float h, float a, MaskFilter bf, long now) {
        float padX = h * 0.52f;
        int green = 0xFF34C759;
        float ics = h * 0.46f;
        float cx = padX + ics / 2f, cy = h / 2f;

        // handset
        prep(sp, green, a, bf);
        sp.setStrokeWidth(ics * 0.20f);
        drawUnit(c, unitHandset, cx, cy, ics * 1.1f, sp);
        prep(ip, green, a, bf);
        float s = ics * 1.1f;
        c.drawCircle(cx - 0.28f * s, cy - 0.28f * s, 0.15f * s, ip);
        c.drawCircle(cx + 0.28f * s, cy + 0.28f * s, 0.15f * s, ip);

        // timer
        String label;
        if (callRinging) {
            label = "Ringing";
        } else {
            long sec = Math.max(0L, (now - callStart) / 1000L);
            label = String.format(Locale.US, "%d:%02d", sec / 60L, sec % 60L);
        }
        tp.setTextSize(h * 0.40f);
        tp.setTextAlign(Paint.Align.LEFT);
        prep(tp, green, a, bf);
        c.drawText(label, padX + ics + h * 0.20f, textBase(h), tp);

        // live waveform, green fading to light yellow on the right
        int n = 17;
        float barW = h * 0.05f, gap = h * 0.062f;
        float total = n * barW + (n - 1) * gap;
        float x0 = w - padX - total;
        for (int i = 0; i < n; i++) {
            float f = i / (float) (n - 1);
            float env = 0.30f + 0.70f * (float) Math.sin(Math.PI * (0.08 + 0.84 * f));
            double omega = 0.0055 + 0.0013 * ((i * 7) % 5);
            float amp = 0.22f + 0.78f * (float) Math.abs(Math.sin(now * omega + i * 1.7));
            float bh = Math.max(barW, h * 0.62f * env * amp);
            int col = f < 0.55f ? green
                    : (Integer) ARGB.evaluate((f - 0.55f) / 0.45f, green, 0xFFFFF1B8);
            prep(ip, col, a, bf);
            float bx = x0 + i * (barW + gap);
            rect.set(bx, h / 2f - bh / 2f, bx + barW, h / 2f + bh / 2f);
            c.drawRoundRect(rect, barW / 2f, barW / 2f, ip);
        }
    }

    private void drawLockScene(Canvas c, float w, float h, float a, MaskFilter bf, long t, boolean unlock) {
        float padX = h * 0.52f;
        float s = h * 0.50f;
        float cx = padX * 0.9f + s / 2f, cy = h / 2f;
        float open;
        if (unlock) open = ease((t - 250) / 400f);
        else open = 1f - ease(t / 350f);
        int col = 0xFFE5E5EA;

        // shackle (swings open around its left foot)
        c.save();
        c.translate(0f, -0.05f * s * open);
        c.rotate(-34f * open, cx - 0.17f * s, cy - 0.03f * s);
        prep(sp, col, a, bf);
        sp.setStrokeWidth(0.10f * s);
        drawUnit(c, unitShackle, cx, cy, s, sp);
        c.restore();
        // body + keyhole
        rect.set(cx - 0.31f * s, cy - 0.06f * s, cx + 0.31f * s, cy + 0.40f * s);
        prep(ip, col, a, bf);
        c.drawRoundRect(rect, 0.09f * s, 0.09f * s, ip);
        prep(ip, 0xFF000000, a, bf);
        c.drawCircle(cx, cy + 0.15f * s, 0.05f * s, ip);

        if (unlock) {
            float r = h * 0.27f;
            drawRing(c, w - padX * 0.95f - r, h / 2f, r, t, a, bf);
        }
    }

    /** Cyan neon ring (Face ID style): a bright arc sweeps round, then settles into a glowing full ring. */
    private void drawRing(Canvas c, float cx, float cy, float r, long t, float a, MaskFilter bf) {
        float sw = r * 0.30f;
        float sweep = Math.max(1f, 360f * ease((t - 100) / 650f));
        float rot = -90f + t * 0.35f;
        float uni = ease((t - 780) / 300f);
        float pulse = 0.85f + 0.15f * (float) Math.sin(t / 160.0);
        rect2.set(cx - r, cy - r, cx + r, cy + r);

        if (sweep >= 8f && uni < 0.999f) {
            float s = Math.min(1f, sweep / 360f);
            int[] colors = {0x005AC8FA, 0xFF5AC8FA, 0xFFC4F4FF, 0xFFC4F4FF};
            float[] pos = {0f, 0.6f * s, Math.min(s, 0.999f), 1f};
            SweepGradient sg = new SweepGradient(cx, cy, colors, pos);
            tmpM.setRotate(rot, cx, cy);
            sg.setLocalMatrix(tmpM);
            gp.setShader(sg);
            gp.setMaskFilter(mkBlur(r * 0.55f));
            gp.setStrokeWidth(sw * 1.9f);
            gp.setAlpha(Math.round(255f * 0.55f * a * (1f - uni)));
            c.drawArc(rect2, rot, sweep, false, gp);
            gp.setShader(null);

            prep(sp, 0xFFFFFFFF, a * (1f - uni), bf);
            sp.setShader(sg);
            sp.setAlpha(Math.round(255f * a * (1f - uni)));
            sp.setStrokeWidth(sw);
            c.drawArc(rect2, rot, sweep, false, sp);
            sp.setShader(null);
        }
        if (uni > 0.01f) {
            gp.setShader(null);
            gp.setColor(0xFF5AC8FA);
            gp.setMaskFilter(mkBlur(r * 0.55f));
            gp.setStrokeWidth(sw * 1.9f);
            gp.setAlpha(Math.round(255f * 0.65f * a * uni * pulse));
            c.drawArc(rect2, 0f, 360f, false, gp);
            gp.setMaskFilter(null);

            prep(sp, 0xFFB5EEFF, a * uni, bf);
            sp.setStrokeWidth(sw);
            c.drawArc(rect2, 0f, 360f, false, sp);
        }
        gp.setMaskFilter(null);
    }
}

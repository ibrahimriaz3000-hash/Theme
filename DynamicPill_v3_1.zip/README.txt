Dynamic Pill (LSPosed module) v3.1
1. Upload this zip's contents to a GitHub repo (the .github/workflows/build.yml is included).
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot. Open settings from the "Dynamic Pill" Control Center tile (long press) or from LSPosed.

Changes in 2.2
- Status Bar Padding (Left / Right / Top) removed completely: settings section, status bar height hook,
  content insets hook, keyguard/status bar view tracking. System UI status bar is left untouched.
- Pill is centred on the real camera cutout / status bar height again (no padding offset).
- Slider no longer gets stuck capturing touches when the gesture is cancelled.

Changes in 2.3
- New switch "Battery % in Control Center (iOS style)" (settings -> CONTROL CENTER, on by default).
  Shows "66%" before the battery icon in the Control Center header. The status bar is untouched, so with
  Settings -> Notifications & status bar -> Battery indicator = icon only, the status bar has no percentage
  and only the Control Center shows it. If the system already shows a percentage text there, ours hides itself.

Changes in 2.4  (smooth pull-down, no glitch)
- Grabber line now fades out frame by frame while you pull the status bar / Control Center down
  (before it waited for a 400 ms poll, then popped), and fades back in when it closes.
- Pill fades in / out (enable switch, lock screen switch, first start) instead of popping.
- Control Center battery % is laid out before the first frame (no pop-in while the panel opens),
  changes are debounced (no flicker) and fade in/out; no work is done while the panel is closed.
- build.yml replaced with a stronger workflow (debug + release APK, checksums, cache, retry, auto release on tag).

Changes in 2.5
- Fixed double battery percentage in the Control Center: with Settings -> Battery indicator = "Percentage (in the icon)"
  or "Percentage outside", our extra "63%" now stays hidden at once (read from the system setting; the in-icon
  number is canvas-drawn so it could not be detected from the view). It re-checks the moment you change that option.
  Only with "icon only" does the Control Center show the iOS style percentage.

Changes in 2.6  (status bar icons jerk while pulling down)
- The Control Center battery "63%" no longer takes any layout space while the panel is being pulled. Before, it widened
  the header the moment it appeared, so the status bar icons (signal / wifi) that morph into the Control Center header
  jumped and vanished. Now the header moves exactly like stock, and the % expands in smoothly (width + fade) only after
  the Control Center is open, and collapses as soon as you start closing it.

Changes in 2.7  (icons glitch while closing the Control Center)
- 2.6 used a threshold that was reached early while pulling, so the % still changed the header layout in the middle of
  the icon morph (opening and closing). Now the % is only revealed after the panel has stopped moving fully open
  (settled for 160 ms), and it collapses the moment the panel starts to close, before the status bar icons
  (signal / wifi) morph back. Nothing changes the header layout while it is moving.

Changes in 2.8  (icons wrong while the Control Center is closing)
- The screenshots show the Control Center header icons (wifi + 62% + battery, signal clipped) while the panel is
  fading / blurring away. HyperOS closes it with a fade, so height alone could not detect the closing.
  Now the % follows the header itself: it is revealed only after the header has stopped moving and is fully opaque,
  and collapses (70 ms) the instant the header moves or fades, before the icons morph back into the status bar.
  When the Control Center is hidden the % is reset, so the next opening always starts clean.

Changes in 2.9
- Pill shape: new setting PILL -> "Corner smoothness (0 = circle)", default 30.
  The corners were already fully round (radius = half the height), so they cannot get rounder; instead the ends now
  use an iOS style continuous curve (superellipse) so the curve blends into the straight edges without a visible
  seam. 0 = old plain circular capsule, 100 = softest / squarest curve. The white border follows the same shape.

Changes in 3.0  (GoodLooks Color Guard built in)
- New settings section GOODLOOKS COLOR GUARD (ROOT): Contrast, Saturation, Red, Green, Blue sliders, Responsive Mode,
  Dedup Apply, SurfaceFlinger Guard, Adaptive Debounce, Boost Keepalive, Ultimate Black Almond - Auto switches and
  Black Almond Intensity slider (same iOS style sliders / switches as the pill settings).
- The unmodified Color Guard Magisk / KernelSU module (assets/colorguard) is installed by this app through root the
  first time you open settings (grant root to Dynamic Pill). It then runs at every boot on its own; your slider values
  are kept on updates. Changes apply live, no reboot.
- Only this zip has to be uploaded to GitHub; .github/workflows/build.yml is included and unchanged.

Changes in 3.1  (iOS style expanding pill animations)
- The pill now expands like the iOS Dynamic Island: it grows wider, the content blurs in, stays for "Show time"
  and then shrinks back. New settings sections ANIMATIONS and PREVIEW (tap "Play" to test every animation).
- Charging: "Charging" + percentage + green battery icon (when the charger is plugged in).
- Silent / Vibrate / Ring: red bell-slash pill + "Silent", orange vibrate icon + "Vibrate", bell + "Ring" (ringer switch).
- Call: green handset, running call timer ("Ringing" while it rings) and a live green waveform for the whole call.
- Lock: padlock closes when the screen wakes on the lock screen.
- Unlock: after fingerprint / pattern / PIN the padlock opens and a cyan neon ring sweeps around on the right.
- WhatsApp: green neon glowing outline around the pill for as long as WhatsApp is open.
- Android cannot draw anything once the screen is off, so the lock animation plays when the screen wakes locked.
- Settings: Expanded width, Show time, and a switch for every animation (+ master switch).
